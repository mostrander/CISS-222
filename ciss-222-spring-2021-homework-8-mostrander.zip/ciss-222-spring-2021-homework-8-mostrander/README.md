# CISS222 Spring 2021 - Homework 8

## Purpose
The purpose of this assignment is to understand the role that loops play in programming.

## Objective
Write a program that displays each of the following four asterisk patterns on the console, one pattern after the other with a blank line after each of the first three patterns.

![](asterisks.jpg)


### Implementation Details and Additional Notes
 * The code is to be implemented in the `GenerateAsterisks()` static method of the `Asterisks` static class, including the loops and the display logic. No changes are required to the `Main()` method or the `Program` class.
 * Use ONLY the following statements to generate the patterns (**NOTE**: single quotes are used in this case and not double quotes for the parameter):
   * `Console.WriteLine();`
   * `Console.Write('*');`
   * `Console.Write(' ');`
 * You will need to use nested for-loops to generate each pattern.
 * You must use a combination of the above commands and loops to accomplish this assignment. If you simply put the asterisk patterns in line without loop logic, you will not get credit for this assignment.

## Expectations and Grading
1. (2 pts) The first pattern of asterisks display properly with only the above output statements used
1. (2 pts) The second pattern of asterisks display properly with only the above output statements used
1. (2 pts) The third pattern of asterisks display properly with only the above output statements used
1. (2 pts) The fourth pattern of asterisks display properly with only the above output statements used
1. (2 pt) A space exists between each of the first three patterns, with only the above output statements used.

## Assignment Retrieval, Testing, and Submission
1. Pull down this repository from GitHub to your local machine and open the solution in Visual Studio.
1. You can check in your work, as well as push to GitHub, as infrequently or as often as you wish. However, you must ensure that your work is checked in and pushed, as that will be how your assignment is turned in. The code as of the due date and time will be the version that will be graded.
