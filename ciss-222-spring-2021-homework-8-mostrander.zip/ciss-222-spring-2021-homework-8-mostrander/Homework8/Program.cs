﻿using System;

namespace Homework8
{
    class Program
    {
        static void Main(string[] args)
        {
            // You will put your code in the GenerateAsterisks() static method
            Asterisks.GenerateAsterisks();
        }
    }
}
