﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework8
{
    public static class Asterisks
    {
        public static void GenerateAsterisks()
        {
            // In this method, output the four patterns based on the requirements
            //number of stars total 10

            //For pattern 1; GOOD
            for (int i = 1; i <= 10; i++)
            {
               for (int star = 1; star <= i; star++)
               {
                  Console.Write('*');
               }
               Console.WriteLine();
            }

            Console.WriteLine();

            //For pattern 2, inverted version of 1. Starts with 10 stars, then goes down to 1 with each line; GOOD
            for(int i = 10; i >= 0; i--)
            {
               for (int star = 1; star <= i; star++)
               {
                  Console.Write('*');
               }
               Console.WriteLine();
            }

            //For pattern 3, requires spaces at the beginning of each pattern line as number of stars decrease to 1. GOOD
            for(int i = 10; i >= 0; i--)
            {
               for(int space = 10; space > i; space--)
               {
                  Console.Write(' ');
               }
               for(int star = 1; star <= i; star++)
               {
                  Console.Write('*');
               }
               Console.WriteLine();
            }

            //For final pattern, similar to 3rd pattern but start with 1 star and go to 10.
            for(int i = 1; i <= 10; i++)
            {
               for (int space = 10; space > i; space--)
               {
                  Console.Write(' ');
               }
               for (int star = 1; star <= i; star++)
               {
                  Console.Write('*');
               }
               Console.WriteLine();
            }

         }

    }
}
