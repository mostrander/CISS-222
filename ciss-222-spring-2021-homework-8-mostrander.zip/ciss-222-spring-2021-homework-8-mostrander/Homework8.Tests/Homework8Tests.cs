using System;
using System.IO;
using System.Text;
using Xunit;

namespace Homework8.Tests
{
    public class Homework8Tests
    {
        [Fact]
        public void Homework8_ValidTestPattern()
        {
            using StringWriter actual = new StringWriter();
            Console.SetOut(actual);

            StringBuilder expected = new StringBuilder();

            expected.Append($"*{Environment.NewLine}");
            expected.Append($"**{Environment.NewLine}");
            expected.Append($"***{Environment.NewLine}");
            expected.Append($"****{Environment.NewLine}");
            expected.Append($"*****{Environment.NewLine}");
            expected.Append($"******{Environment.NewLine}");
            expected.Append($"*******{Environment.NewLine}");
            expected.Append($"********{Environment.NewLine}");
            expected.Append($"*********{Environment.NewLine}");
            expected.Append(Environment.NewLine);
            expected.Append($"**********{Environment.NewLine}");
            expected.Append($"*********{Environment.NewLine}");
            expected.Append($"********{Environment.NewLine}");
            expected.Append($"*******{Environment.NewLine}");
            expected.Append($"******{Environment.NewLine}");
            expected.Append($"*****{Environment.NewLine}");
            expected.Append($"****{Environment.NewLine}");
            expected.Append($"***{Environment.NewLine}");
            expected.Append($"**{Environment.NewLine}");
            expected.Append($"*{Environment.NewLine}");
            expected.Append(Environment.NewLine);
            expected.Append($"**********{Environment.NewLine}");
            expected.Append($" *********{Environment.NewLine}");
            expected.Append($"  ********{Environment.NewLine}");
            expected.Append($"   *******{Environment.NewLine}");
            expected.Append($"    ******{Environment.NewLine}");
            expected.Append($"     *****{Environment.NewLine}");
            expected.Append($"      ****{Environment.NewLine}");
            expected.Append($"       ***{Environment.NewLine}");
            expected.Append($"        **{Environment.NewLine}");
            expected.Append($"         *{Environment.NewLine}");
            expected.Append(Environment.NewLine);
            expected.Append($"         *{Environment.NewLine}");
            expected.Append($"        **{Environment.NewLine}");
            expected.Append($"       ***{Environment.NewLine}");
            expected.Append($"      ****{Environment.NewLine}");
            expected.Append($"     *****{Environment.NewLine}");
            expected.Append($"    ******{Environment.NewLine}");
            expected.Append($"   *******{Environment.NewLine}");
            expected.Append($"  ********{Environment.NewLine}");
            expected.Append($" *********{Environment.NewLine}");
            expected.Append($"**********{Environment.NewLine}");

            Asterisks.GenerateAsterisks();
            Assert.Equal(expected.ToString(), actual.ToString());
        }
    }
}
