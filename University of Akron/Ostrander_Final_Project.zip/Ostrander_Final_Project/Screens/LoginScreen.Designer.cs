﻿namespace Ostrander_Final_Project.Screens
{
    partial class LoginScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UsernameLoginBox = new System.Windows.Forms.TextBox();
            this.PasswordLoginLabel = new System.Windows.Forms.Label();
            this.UsernameLoginLabel = new System.Windows.Forms.Label();
            this.LoginScreenLabel = new System.Windows.Forms.Label();
            this.LoginButton = new System.Windows.Forms.Button();
            this.LoginErrorLabel = new System.Windows.Forms.Label();
            this.PasswordLoginBox = new System.Windows.Forms.MaskedTextBox();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // UsernameLoginBox
            // 
            this.UsernameLoginBox.BackColor = System.Drawing.SystemColors.Window;
            this.UsernameLoginBox.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UsernameLoginBox.Location = new System.Drawing.Point(127, 137);
            this.UsernameLoginBox.Name = "UsernameLoginBox";
            this.UsernameLoginBox.Size = new System.Drawing.Size(226, 30);
            this.UsernameLoginBox.TabIndex = 10;
            // 
            // PasswordLoginLabel
            // 
            this.PasswordLoginLabel.AutoSize = true;
            this.PasswordLoginLabel.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordLoginLabel.Location = new System.Drawing.Point(128, 190);
            this.PasswordLoginLabel.Name = "PasswordLoginLabel";
            this.PasswordLoginLabel.Size = new System.Drawing.Size(87, 24);
            this.PasswordLoginLabel.TabIndex = 9;
            this.PasswordLoginLabel.Text = "Password:";
            // 
            // UsernameLoginLabel
            // 
            this.UsernameLoginLabel.AutoSize = true;
            this.UsernameLoginLabel.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.UsernameLoginLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.UsernameLoginLabel.Location = new System.Drawing.Point(127, 109);
            this.UsernameLoginLabel.Name = "UsernameLoginLabel";
            this.UsernameLoginLabel.Size = new System.Drawing.Size(111, 24);
            this.UsernameLoginLabel.TabIndex = 8;
            this.UsernameLoginLabel.Text = "Employee ID:";
            // 
            // LoginScreenLabel
            // 
            this.LoginScreenLabel.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LoginScreenLabel.Location = new System.Drawing.Point(12, 34);
            this.LoginScreenLabel.Name = "LoginScreenLabel";
            this.LoginScreenLabel.Size = new System.Drawing.Size(458, 44);
            this.LoginScreenLabel.TabIndex = 7;
            this.LoginScreenLabel.Text = "Please Login Below";
            this.LoginScreenLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LoginButton
            // 
            this.LoginButton.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.LoginButton.Location = new System.Drawing.Point(186, 297);
            this.LoginButton.Name = "LoginButton";
            this.LoginButton.Size = new System.Drawing.Size(107, 35);
            this.LoginButton.TabIndex = 6;
            this.LoginButton.Text = "Login";
            this.LoginButton.UseVisualStyleBackColor = true;
            this.LoginButton.Click += new System.EventHandler(this.LoginButton_Click);
            // 
            // LoginErrorLabel
            // 
            this.LoginErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.LoginErrorLabel.Location = new System.Drawing.Point(5, 255);
            this.LoginErrorLabel.Name = "LoginErrorLabel";
            this.LoginErrorLabel.Size = new System.Drawing.Size(465, 39);
            this.LoginErrorLabel.TabIndex = 12;
            this.LoginErrorLabel.Text = "Error:";
            this.LoginErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PasswordLoginBox
            // 
            this.PasswordLoginBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.PasswordLoginBox.Location = new System.Drawing.Point(127, 217);
            this.PasswordLoginBox.Name = "PasswordLoginBox";
            this.PasswordLoginBox.PasswordChar = '*';
            this.PasswordLoginBox.Size = new System.Drawing.Size(226, 34);
            this.PasswordLoginBox.TabIndex = 13;
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ExitButton.Location = new System.Drawing.Point(186, 347);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(107, 35);
            this.ExitButton.TabIndex = 14;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // LoginScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 398);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.PasswordLoginBox);
            this.Controls.Add(this.LoginErrorLabel);
            this.Controls.Add(this.UsernameLoginBox);
            this.Controls.Add(this.PasswordLoginLabel);
            this.Controls.Add(this.UsernameLoginLabel);
            this.Controls.Add(this.LoginScreenLabel);
            this.Controls.Add(this.LoginButton);
            this.Name = "LoginScreen";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private TextBox UsernameLoginBox;
        private Label PasswordLoginLabel;
        private Label UsernameLoginLabel;
        private Label LoginScreenLabel;
        private Button LoginButton;
        private Label LoginErrorLabel;
        private MaskedTextBox PasswordLoginBox;
        private Button ExitButton;
    }
}