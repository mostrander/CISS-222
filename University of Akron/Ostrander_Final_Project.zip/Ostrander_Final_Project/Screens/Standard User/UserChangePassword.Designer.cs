﻿namespace Ostrander_Final_Project.Screens
{
    partial class UserChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label_OldPassword = new System.Windows.Forms.Label();
            this.Label_NewPassword1 = new System.Windows.Forms.Label();
            this.Label_NewPassword2 = new System.Windows.Forms.Label();
            this.Old_Password_Box = new System.Windows.Forms.MaskedTextBox();
            this.New_Password_Box1 = new System.Windows.Forms.MaskedTextBox();
            this.New_Password_Box2 = new System.Windows.Forms.MaskedTextBox();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.NameLabel = new System.Windows.Forms.Label();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Label_OldPassword
            // 
            this.Label_OldPassword.AutoSize = true;
            this.Label_OldPassword.Location = new System.Drawing.Point(30, 83);
            this.Label_OldPassword.Name = "Label_OldPassword";
            this.Label_OldPassword.Size = new System.Drawing.Size(101, 20);
            this.Label_OldPassword.TabIndex = 3;
            this.Label_OldPassword.Text = "Old Password:";
            // 
            // Label_NewPassword1
            // 
            this.Label_NewPassword1.AutoSize = true;
            this.Label_NewPassword1.Location = new System.Drawing.Point(24, 127);
            this.Label_NewPassword1.Name = "Label_NewPassword1";
            this.Label_NewPassword1.Size = new System.Drawing.Size(107, 20);
            this.Label_NewPassword1.TabIndex = 4;
            this.Label_NewPassword1.Text = "New Password:";
            // 
            // Label_NewPassword2
            // 
            this.Label_NewPassword2.AutoSize = true;
            this.Label_NewPassword2.Location = new System.Drawing.Point(36, 172);
            this.Label_NewPassword2.Name = "Label_NewPassword2";
            this.Label_NewPassword2.Size = new System.Drawing.Size(89, 20);
            this.Label_NewPassword2.TabIndex = 5;
            this.Label_NewPassword2.Text = "Enter Again:";
            // 
            // Old_Password_Box
            // 
            this.Old_Password_Box.Location = new System.Drawing.Point(142, 80);
            this.Old_Password_Box.Name = "Old_Password_Box";
            this.Old_Password_Box.PasswordChar = '*';
            this.Old_Password_Box.Size = new System.Drawing.Size(218, 27);
            this.Old_Password_Box.TabIndex = 6;
            // 
            // New_Password_Box1
            // 
            this.New_Password_Box1.Location = new System.Drawing.Point(142, 124);
            this.New_Password_Box1.Name = "New_Password_Box1";
            this.New_Password_Box1.PasswordChar = '*';
            this.New_Password_Box1.Size = new System.Drawing.Size(218, 27);
            this.New_Password_Box1.TabIndex = 7;
            // 
            // New_Password_Box2
            // 
            this.New_Password_Box2.Location = new System.Drawing.Point(142, 169);
            this.New_Password_Box2.Name = "New_Password_Box2";
            this.New_Password_Box2.PasswordChar = '*';
            this.New_Password_Box2.Size = new System.Drawing.Size(218, 27);
            this.New_Password_Box2.TabIndex = 8;
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(82, 317);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(94, 29);
            this.SubmitButton.TabIndex = 9;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(210, 317);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(94, 29);
            this.CancelButton.TabIndex = 10;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // NameLabel
            // 
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 9);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(366, 51);
            this.NameLabel.TabIndex = 11;
            this.NameLabel.Text = "Name Here";
            this.NameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.BackColor = System.Drawing.SystemColors.Control;
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(12, 209);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(366, 99);
            this.ErrorLabel.TabIndex = 12;
            this.ErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // UserChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(390, 368);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.New_Password_Box2);
            this.Controls.Add(this.New_Password_Box1);
            this.Controls.Add(this.Old_Password_Box);
            this.Controls.Add(this.Label_NewPassword2);
            this.Controls.Add(this.Label_NewPassword1);
            this.Controls.Add(this.Label_OldPassword);
            this.Name = "UserChangePassword";
            this.Text = "Change Password Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Label_OldPassword;
        private Label Label_NewPassword1;
        private Label Label_NewPassword2;
        private MaskedTextBox Old_Password_Box;
        private MaskedTextBox New_Password_Box1;
        private MaskedTextBox New_Password_Box2;
        private Button SubmitButton;
        private Button CancelButton;
        private Label NameLabel;
        private Label ErrorLabel;
    }
}