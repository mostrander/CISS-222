﻿using Ostrander_Final_Project.Classes;
using Ostrander_Final_Project.Screens.Standard_User;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens
{
    public partial class StandardUserMenu1 : Form
    {
        private List<Faculty> staff = new List<Faculty>();
        private string currentUser = LoginScreen.userAccountID; //Stores logged in user's employee id info from login screen form

        public StandardUserMenu1()
        {
            InitializeComponent();

            //Add custom welcome to the Admin launch screen. (Admin Menu 1) 
            //For now, it will assume that the individual is actually the right person. 
            //Might try crashing the entire program if user information changes.... try that LATER for now get program functional
            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();

                var account =
                from faculty in staff
                where faculty.GetID() == currentUser
                select faculty;

                //If there are any results found, display user's name
                if (account.Any())
                {
                    string name = "";
                    foreach (Faculty faculty in account)
                    {
                        name = faculty.GetName();
                    }

                    WelcomeLabel.Text = $"Welcome {name}!";
                }
                else
                {
                    throw new Exception();
                }

            }
            catch
            {
                Environment.Exit(0);
            }
        }

        private void ChangePasswordButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserChangePassword changePassword = new UserChangePassword();
            changePassword.ShowDialog();

            this.Show();
        }

        private void UserExitButton1_Click(object sender, EventArgs e)
        {
            this.Close(); //Return to login screen
        }

        private void UserClassViewButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserViewClassInfo classInfo = new UserViewClassInfo();
            classInfo.ShowDialog();

            this.Show();
        }

        private void CourseAssignmentsButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserCourseAssignments gradebook = new UserCourseAssignments();
            gradebook.ShowDialog();

            this.Show();
        }

        private void GradeBookButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserGradeBook gradebook = new UserGradeBook();
            gradebook.ShowDialog();

            this.Show();
        }
    }
}
