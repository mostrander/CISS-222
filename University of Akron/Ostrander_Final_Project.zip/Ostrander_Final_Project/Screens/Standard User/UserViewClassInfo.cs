﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens
{
    public partial class UserViewClassInfo : Form
    {
        private Faculty employee; //Holds information specific to employee
        private List<Courses>? myCourses; //Holds users list of courses they teach
        private List<Student> myStudents; //List of ALL students instructor is currently teaching
        List<Assignment> assignmentsList; //Holds assignments currently listed for course

        public UserViewClassInfo()
        {
            InitializeComponent();
            try
            {
                List<Courses> currentCourses = new List<Courses>(); //full list of courses available
                List<Faculty> staff = new List<Faculty>();
                string currentUser = LoginScreen.userAccountID; //Stores logged in user's employee id info from login screen form

                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }
                
                fileInput = new FileStream("ClassList.txt", FileMode.OpenOrCreate, FileAccess.Read);
                
                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            currentCourses.Add(new Courses(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                            words[4].ToString(), words[5].ToString(), words[6].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();

                myStudents = new List<Student>();

                //Add the courses for the teachers accordingly, based on matching instructor ID, which SHOULD be unique
                foreach (Faculty facultyMember in staff)
                {

                    if (facultyMember.HasCourseList() == true)
                    {
                        foreach (Courses course in currentCourses)
                        {
                            if (course.GetTeacherID() == facultyMember.GetID())
                            {
                                facultyMember.AddCourse(course);
                            }

                            //If the course has known students, add them now

                        }

                        if (facultyMember.GetID() == currentUser)
                        {
                            employee = facultyMember;
                            myCourses = facultyMember.GetCourses();

                            foreach(Courses course in myCourses)
                            {
                                foreach(Student student in course.GetEnrollment())
                                {
                                    myStudents.Add(student);
                                }

                            }
                        }

                    }
                }

                ErrorLabel.Text = "";

            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error occurred while loading data.";
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ViewAllButton_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (employee.HasCourseList()) //if true, do following
                {
                    DisplayCourseList(myCourses); 
                }
                else
                {
                    ErrorLabel.Text = "Error: You do not have any classes to display.";
                }

            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred";
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            try
            {
                string search = SearchBox.Text;

                if (string.IsNullOrWhiteSpace(search))
                {
                    ErrorLabel.Text = "Error: Nothing was entered in the search box. Please try again.";
                }
                else if (employee.HasCourseList())
                {
                    //Search for exact match, as well as partial matches.
                    IEnumerable<Courses>? searchResult =
                    from courses in myCourses
                    where courses.GetDeptCode() == search || courses.GetName() == search 
                          || courses.GetName().Contains(search, StringComparison.OrdinalIgnoreCase) 
                          || courses.GetDeptCode().Contains(search,StringComparison.OrdinalIgnoreCase)
                    orderby courses
                    select courses;

                    if(searchResult == null || !searchResult.Any())
                    {
                        ErrorLabel.Text = "No results found.";
                    }
                    else
                    {
                        DisplayCourseList(searchResult);
                    }
                }
                else
                {
                    ErrorLabel.Text = "Error: You do not have any classes to display.";
                }
                
            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred";
            }
        }

        private void DisplayCourseList(IEnumerable<Courses> listOfMyCourses)
        {
            //Clear items and columns so duplicates do not appear
            ClassList.Items.Clear();
            ClassList.Columns.Clear();

            //Clear the error label & search box
            ErrorLabel.Text = "";

            //List Columns for making viewing easier; -2 is for autosizing
            ClassList.Columns.Add("Course", 175, HorizontalAlignment.Center);
            ClassList.Columns.Add("ID", 150, HorizontalAlignment.Center);
            ClassList.Columns.Add("Description", 300, HorizontalAlignment.Center);
            ClassList.Columns.Add("Students", 70, HorizontalAlignment.Center);
            ClassList.Columns.Add("Capacity", 70, HorizontalAlignment.Center);

            //Show details of the items and allow columns to be reordered
            ClassList.View = View.Details;
            ClassList.AllowColumnReorder = true;
            ClassList.AllowDrop = false; //Do not accept anything dragged and dropped onto the control


            try
            {
                ListViewItem[] listResults;//creates array to pass to AddRange() later
                ListViewItem item;//Will be used for creating each item individually

                //Determine number of entries in user's course list and creat listResults array
                int size = listOfMyCourses.Count();
                int added = 0; //tracks how many have been added, easier to use when entering into array
                listResults = new ListViewItem[size];

                foreach (var course in listOfMyCourses)
                {
                    item = new ListViewItem(course.GetName(), 0); //Course name
                    item.SubItems.Add(course.GetDeptCode()); //Course ID
                    item.SubItems.Add(course.GetDescription()); //Course Description
                    item.SubItems.Add(course.GetCurrentCapacity()); //Students enrolled
                    item.SubItems.Add(course.GetMaxCapacity()); //Capacity

                    listResults[added] = item;

                    added++;
                }

                ClassList.Items.AddRange(listResults); //Output to the ListItem box control

            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred";
            }
        }

    }
}
