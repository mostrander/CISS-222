﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens.Standard_User
{
    public partial class UserGradeBook : Form
    {
        private string currentUser = LoginScreen.userAccountID; //Stores logged in user's employee id info from login screen form
        List<Courses> courseList; //List of teacher's OWN classes
        List<Student> studentList; //List of students in all of teacher's courses 
        List<Assignment> assignmentsList; //Holds assignments currently listed for course

        List<string> assignmentGradeChanges = new List<string>(); //Holds changes to the assignment grades
        List<string> courseGrades = new List<string>(); //Used for importing grades

        public UserGradeBook()
        {
            InitializeComponent();


            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;
                List<Faculty> staff = new List<Faculty>();
                List<Courses> currentCourses = new List<Courses>();

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                //Read in the courses offered currently
                fileInput = new FileStream("ClassList.txt", FileMode.OpenOrCreate, FileAccess.Read);

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            currentCourses.Add(new Courses(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                //Add the courses for the teachers accordingly, based on matching instructor ID, which SHOULD be unique
                foreach (Faculty member in staff)
                {
                    bool courseListExists = member.HasCourseList();

                    if (courseListExists == true)
                    {
                        foreach (Courses course in currentCourses)
                        {
                            if (course.GetTeacherID() == member.GetID())
                            {
                                member.AddCourse(course);
                            }
                        }
                    }
                }

                //Find current instructor who is logged in - it SHOULD find the person
                IEnumerable<Faculty>? instructorFound =
                    from faculty in staff
                    where faculty.GetID() == currentUser
                    select faculty;

                if (instructorFound.Any() && instructorFound != null)
                {
                    Faculty teacher = instructorFound.First();
                    studentList = new List<Student>();

                    if (teacher.HasCourseList())
                    {
                        courseList = teacher.GetCourses();

                        foreach (Courses course in courseList)
                        {
                            CourseSearchBox.Items.Add(course.GetDeptCode() + "  " + course.GetName());

                            //If students are enrolled in course, then add them to the overall student list and search list
                            foreach(Student student in course.GetEnrollment())
                            {
                                studentList.Add(student);
                                StudentSearchBox.Items.Add( student.GetName() + "  - " + student.GetStudentID() );
                            }
                        }
                    }
                }
                else
                {
                    ErrorLabel.Text = "Error: Unable to find you in the system.";
                }


                //Import instructor's list of assignments for all courses into each respective course assignment list
                fileInput = new FileStream(currentUser + "CourseAssignmentLists.txt", FileMode.OpenOrCreate, FileAccess.Read);
                assignmentsList = new List<Assignment>();

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            assignmentsList.Add(new Assignment(words[0].ToString(), words[1].ToString(), words[2].ToString(),
                                int.Parse(words[3].ToString())));
                        }
                    }

                    fileReader.Close();
                }

                //Foreach assignment, match the courseID and add to courses respectively
                foreach(Courses course in courseList)
                {
                    foreach(Assignment assignment in assignmentsList)
                    {
                        if(assignment.GetCourseID() == course.GetDeptCode())
                        {
                            course.AddAssignment(assignment);

                            //Add assignment for each student
                            foreach(Student student in course.GetEnrollment())
                            {
                                student.AddAssignment(assignment);
                            }
                        }
                    }
                }


                //DisplayGrades(assignmentsList, studentList);

                ErrorLabel.Text = ""; //so error label placement text does not show
            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred while importing the data." +
                    " Please ask your administrator for assistance.";
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Reset the error message
                ErrorLabel.Text = "";
                ErrorLabel.ForeColor = Color.Red;

                courseGrades.Clear();

                if(string.IsNullOrWhiteSpace(CourseSearchBox.Text) && string.IsNullOrWhiteSpace(StudentSearchBox.Text))
                {
                    ErrorLabel.Text = "Error: Neither course nor student was selected for the search. " +
                        "You must select the course to perform ANY searches.";
                }
                else if (string.IsNullOrWhiteSpace(CourseSearchBox.Text))
                {
                    ErrorLabel.Text = "Error: You must select the course to perform ANY searches.";
                }
                else if (!string.IsNullOrWhiteSpace(CourseSearchBox.Text))
                {
                    //Get the respective assignment list for specific course
                    IEnumerable<Assignment> assignmentsFound =
                        from assignment in assignmentsList
                        where CourseSearchBox.Text.Contains(assignment.GetCourseID(), StringComparison.OrdinalIgnoreCase)
                        select assignment;

                    List<Assignment> assignments = new List<Assignment>();

                    foreach(Assignment assignment in assignmentsFound)
                    {
                        assignments.Add(assignment);
                    }


                    //Get list of students for specific course
                    IEnumerable<Courses> courseFound =
                        from course in courseList
                        where CourseSearchBox.Text.Contains(course.GetDeptCode(), StringComparison.OrdinalIgnoreCase)
                        select course;

                    IEnumerable<Student> courseStudentsEnrolled =
                        from student in courseFound.First().GetEnrollment()
                        select student;

                    List<Student> students = new List<Student>();
                    //List<Student> chosenStudent = new List<Student>();

                    foreach(Student student in courseStudentsEnrolled)
                    {
                        //If student was selected for search, then only add them.
                        //Otherwise, if the search box is empty add all students for the course.
                        if (!string.IsNullOrWhiteSpace(StudentSearchBox.Text) && 
                            StudentSearchBox.Text.Contains(student.GetStudentID(), StringComparison.OrdinalIgnoreCase))
                        {
                            students.Add(student);
                        }
                        else if (string.IsNullOrWhiteSpace(StudentSearchBox.Text))
                        {
                            students.Add(student);
                        }
                    }


                    //Determine if there is a file for the course and import any data from it.
                    //Need to replace : symbol with - in the course dept code
                    string deptCodeString = courseFound.First().GetDeptCode();
                    deptCodeString = deptCodeString.Replace(':', '-');

                    //Output to text file for storage
                    string fileName = $"{deptCodeString} AssignmentGrades.txt";

                    var fileInput = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Read);
                    string line;

                    using (StreamReader fileReader = new StreamReader(fileInput))
                    {
                        while ((line = fileReader.ReadLine()) != null)
                        {
                            //Holds the necessary information pulled from file so information can be entered into accounts
                            string[] words = line.Split(',');

                            if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                            {
                                courseGrades.Add(line);
                            }
                        }

                        fileReader.Close();
                    }

                    if(courseGrades != null && courseGrades.Count > 0)
                    {
                        //Display the gradebook for course
                        DisplayGrades(assignments, students, courseGrades);
                    }
                    else
                    {
                        //Display the gradebook for course
                        DisplayGrades(assignments, students);
                    }


                }
            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error occurred while searching the gradebook.";
            }
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                ErrorLabel.Text = "";
                ErrorLabel.ForeColor = Color.Red;

                if (string.IsNullOrEmpty(CourseSearchBox.Text))
                {
                    ErrorLabel.Text = "Error: Cannot save changes. " +
                        "Please ensure you entered a course in the field below and left the student field empty. " +
                        "Then click search and make the desired changes.";
                }
                else
                {
                    bool emptyField = false; //Assumes user entered information correctly (no blank entries)

                    foreach(DataGridViewRow row in GradeBookGrid.Rows)
                    {

                        for(int i = 0; i < row.Cells.Count; i++)
                        {
                            //If cell is blank, then color and set the emptyField variable to true. 
                            //If value entered is less than zero, color and error
                            if(row.Cells[i].Value == null || string.IsNullOrWhiteSpace(row.Cells[i].Value.ToString()) ||
                                (i > 1 && !row.Cells[i].Value.ToString().All(char.IsDigit)) ||
                                (i > 1 && int.Parse(row.Cells[i].Value.ToString()) < 0) )
                            {
                                row.Cells[i].Style.BackColor = Color.DeepPink;
                                emptyField = true;
                            }

                            //Add check for values above the assignment possible points

                        }
                    }

                    //If an error was discovered, then tell user to fix it.
                    if (emptyField)
                    {
                        ErrorLabel.Text = "Error: Unable to save changes. " +
                            "Please check that the colored cells have a numberic value between zero and " +
                            "the possible points listed in column name.";
                    }
                    else
                    {
                        printGradesFile();
                    }

                }
            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error occurred while saving the changes.";
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        //Requires list of assignments for column creation, optional course chosen and optional pre-existing grades
        //Optional for studentSearch as well (when user wants to look up student specifically)
        private void DisplayGrades(List<Assignment> listOfAssignments, List<Student> listOfStudents = null, 
            List<string> assignmentGrades = null)
        {
            try
            {
                ErrorLabel.Text = ""; //Reset error label
                ErrorLabel.ForeColor = Color.Red;

                //Reset table view
                GradeBookGrid.Rows.Clear();
                GradeBookGrid.Columns.Clear();

                //Add default columns
                GradeBookGrid.Columns.Add("Students", "Student");
                GradeBookGrid.Columns.Add("StudentID", "ID");

                //Settings for first two columns.
                GradeBookGrid.Columns[0].Frozen = true; //Allows name column to move when scrolling horizonatially
                GradeBookGrid.Columns[0].ReadOnly = true;
                GradeBookGrid.Columns[1].ReadOnly = true;


                //If there are assignments for the courses, then display them
                if (listOfAssignments.Count > 0 && listOfAssignments != null && listOfAssignments.Any())
                {
                    //For each assignment, create a column for that assignment for inputting grades
                    foreach (Assignment assignment in listOfAssignments)
                    {
                        //Column(Name, Display Text)
                        GradeBookGrid.Columns.Add(assignment.GetName() + " (" + assignment.GetType() + " - " +
                            assignment.GetPossiblePoints() + ")", 
                            assignment.GetName() + " (" + assignment.GetType() + " - " + 
                            assignment.GetPossiblePoints() + ")");
                    }

                }
                else
                {
                    ErrorLabel.Text = "Error: No assignments are currently assigned to the course(s) you teach.";
                }

                int rowID; //tracks current row number

                string[] studentGrades; //Used for storing student grades
                string studentGradesRaw = ""; //The raw version of the import
                string entry;
                IEnumerable<string> entryFound;


                //Add values to the datagridview control
                if (listOfStudents == null || listOfStudents.Count == 0)
                {
                    ErrorLabel.Text = "There are no students currently enrolled in this course.";
                }
                else
                {
                    //For each student, display name and ID number by default, followed by grades for each assignment
                    foreach(Student student in listOfStudents)
                    {
                        //Add row for student
                        rowID = GradeBookGrid.Rows.Add();
                        DataGridViewRow row = GradeBookGrid.Rows[rowID]; //Grab the new row

                        //Grab student information by default
                        row.Cells["Students"].Value = student.GetName();
                        row.Cells["StudentID"].Value = student.GetStudentID();

                        entryFound = 
                            from rawEntry in courseGrades
                            where rawEntry.Contains(student.GetStudentID(),StringComparison.OrdinalIgnoreCase)
                            select rawEntry;

                        studentGradesRaw = entryFound.First().ToString();
                        studentGrades = studentGradesRaw.Split(','); //Separate out each entry respectively


                        int col = 2;

                        //For each assignment listed
                        while(col < (listOfAssignments.Count + 2))
                        {
                            //Go through and add the information for each column

                            string value = studentGrades[col].ToString();
                            string colName = GradeBookGrid.Columns[col].Name;

                            if (value.Contains(colName, StringComparison.OrdinalIgnoreCase))
                            {
                                //The split the information on the / symbol to get the proper values.
                                entry = studentGrades[col].ToString();
                                //Should only have 2 values: the column name & value for cell entry
                                string[] valuesFoundSplit = entry.Split('/');

                                row.Cells[colName].Value = valuesFoundSplit[1].ToString();
                            }
                            else
                            {
                                //Default to zero
                                row.Cells[colName].Value = "0";
                            }

                            col++;
                        }
                    }

                } //End of else


            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred while displaying the data.";
            }

        }


        private void printGradesFile()
        {
            try
            {
                assignmentGradeChanges.Clear();

                //Grab the course ID information
                IEnumerable<Courses> courseMatch =
                    from course in courseList
                    where CourseSearchBox.Text.Contains(course.GetDeptCode(),StringComparison.OrdinalIgnoreCase)
                    select course;

                string entry = "";

                //Store changes into the assignmentGradeChanges list
                foreach(DataGridViewRow row in GradeBookGrid.Rows)
                {
                    entry = "";

                    for(int i = 0; i < row.Cells.Count; i++)
                    {
                        if( (i + 1) < row.Cells.Count)
                        {
                            entry += " " + row.Cells[i].OwningColumn.Name + " /" + row.Cells[i].Value.ToString() + ",";
                        }
                        else
                        {
                            entry += " " + row.Cells[i].OwningColumn.Name + " /" + row.Cells[i].Value.ToString();
                        }
                        
                    }

                    assignmentGradeChanges.Add(entry);
                }

                //Need to replace : symbol in the course dept code because it is not creating file correctly as result
                string deptCodeString = courseMatch.First().GetDeptCode();
                deptCodeString = deptCodeString.Replace(':', '-');

                //Output to text file for storage
                string fileName = $"{deptCodeString} AssignmentGrades.txt";
                using (StreamWriter fileWriter = new StreamWriter(fileName, false))
                {
                    foreach (string entered in assignmentGradeChanges)
                    {
                        fileWriter.WriteLine(entered);
                    }

                    fileWriter.Close();
                }

                ErrorLabel.Text = "Success. Changes saved.";
                ErrorLabel.ForeColor = Color.Green;

            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error occurred during saving the changed to file.";
            }
        }


    }
}
