﻿namespace Ostrander_Final_Project.Screens
{
    partial class StandardUserMenu1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeLabel = new System.Windows.Forms.Label();
            this.ChangePasswordButton = new System.Windows.Forms.Button();
            this.UserExitButton1 = new System.Windows.Forms.Button();
            this.UserClassViewButton1 = new System.Windows.Forms.Button();
            this.CourseAssignmentsButton = new System.Windows.Forms.Button();
            this.GradeBookButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WelcomeLabel
            // 
            this.WelcomeLabel.AutoSize = true;
            this.WelcomeLabel.Font = new System.Drawing.Font("Segoe UI", 40F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.WelcomeLabel.Location = new System.Drawing.Point(29, 21);
            this.WelcomeLabel.Name = "WelcomeLabel";
            this.WelcomeLabel.Size = new System.Drawing.Size(759, 89);
            this.WelcomeLabel.TabIndex = 0;
            this.WelcomeLabel.Text = "HELLO STANDARD USER";
            // 
            // ChangePasswordButton
            // 
            this.ChangePasswordButton.Location = new System.Drawing.Point(308, 142);
            this.ChangePasswordButton.Name = "ChangePasswordButton";
            this.ChangePasswordButton.Size = new System.Drawing.Size(188, 29);
            this.ChangePasswordButton.TabIndex = 1;
            this.ChangePasswordButton.Text = "Change Password";
            this.ChangePasswordButton.UseVisualStyleBackColor = true;
            this.ChangePasswordButton.Click += new System.EventHandler(this.ChangePasswordButton_Click);
            // 
            // UserExitButton1
            // 
            this.UserExitButton1.Location = new System.Drawing.Point(308, 302);
            this.UserExitButton1.Name = "UserExitButton1";
            this.UserExitButton1.Size = new System.Drawing.Size(188, 29);
            this.UserExitButton1.TabIndex = 2;
            this.UserExitButton1.Text = "Log Off";
            this.UserExitButton1.UseVisualStyleBackColor = true;
            this.UserExitButton1.Click += new System.EventHandler(this.UserExitButton1_Click);
            // 
            // UserClassViewButton1
            // 
            this.UserClassViewButton1.Location = new System.Drawing.Point(308, 181);
            this.UserClassViewButton1.Name = "UserClassViewButton1";
            this.UserClassViewButton1.Size = new System.Drawing.Size(188, 29);
            this.UserClassViewButton1.TabIndex = 3;
            this.UserClassViewButton1.Text = "View Classes";
            this.UserClassViewButton1.UseVisualStyleBackColor = true;
            this.UserClassViewButton1.Click += new System.EventHandler(this.UserClassViewButton1_Click);
            // 
            // CourseAssignmentsButton
            // 
            this.CourseAssignmentsButton.Location = new System.Drawing.Point(308, 220);
            this.CourseAssignmentsButton.Name = "CourseAssignmentsButton";
            this.CourseAssignmentsButton.Size = new System.Drawing.Size(188, 29);
            this.CourseAssignmentsButton.TabIndex = 4;
            this.CourseAssignmentsButton.Text = "Course Assignments";
            this.CourseAssignmentsButton.UseVisualStyleBackColor = true;
            this.CourseAssignmentsButton.Click += new System.EventHandler(this.CourseAssignmentsButton_Click);
            // 
            // GradeBookButton
            // 
            this.GradeBookButton.Location = new System.Drawing.Point(308, 261);
            this.GradeBookButton.Name = "GradeBookButton";
            this.GradeBookButton.Size = new System.Drawing.Size(188, 29);
            this.GradeBookButton.TabIndex = 5;
            this.GradeBookButton.Text = "Gradebook";
            this.GradeBookButton.UseVisualStyleBackColor = true;
            this.GradeBookButton.Click += new System.EventHandler(this.GradeBookButton_Click);
            // 
            // StandardUserMenu1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 358);
            this.Controls.Add(this.GradeBookButton);
            this.Controls.Add(this.CourseAssignmentsButton);
            this.Controls.Add(this.UserClassViewButton1);
            this.Controls.Add(this.UserExitButton1);
            this.Controls.Add(this.ChangePasswordButton);
            this.Controls.Add(this.WelcomeLabel);
            this.Name = "StandardUserMenu1";
            this.Text = "Main Menu";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label WelcomeLabel;
        private Button ChangePasswordButton;
        private Button UserExitButton1;
        private Button UserClassViewButton1;
        private Button CourseAssignmentsButton;
        private Button GradeBookButton;
    }
}