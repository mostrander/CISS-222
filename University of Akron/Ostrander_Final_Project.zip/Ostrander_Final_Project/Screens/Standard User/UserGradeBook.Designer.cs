﻿namespace Ostrander_Final_Project.Screens.Standard_User
{
    partial class UserGradeBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GradeBookGrid = new System.Windows.Forms.DataGridView();
            this.SaveButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.StudentSearchBox = new System.Windows.Forms.ComboBox();
            this.CourseSearchBox = new System.Windows.Forms.ComboBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.CourseLabel = new System.Windows.Forms.Label();
            this.StudentLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.GradeBookGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // GradeBookGrid
            // 
            this.GradeBookGrid.AllowUserToAddRows = false;
            this.GradeBookGrid.AllowUserToDeleteRows = false;
            this.GradeBookGrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.GradeBookGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GradeBookGrid.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.GradeBookGrid.Location = new System.Drawing.Point(12, 66);
            this.GradeBookGrid.Name = "GradeBookGrid";
            this.GradeBookGrid.RowHeadersWidth = 51;
            this.GradeBookGrid.RowTemplate.Height = 29;
            this.GradeBookGrid.Size = new System.Drawing.Size(1024, 556);
            this.GradeBookGrid.TabIndex = 0;
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(895, 628);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(141, 29);
            this.SaveButton.TabIndex = 1;
            this.SaveButton.Text = "Save Changes";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(732, 656);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(94, 29);
            this.SearchButton.TabIndex = 2;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // StudentSearchBox
            // 
            this.StudentSearchBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.StudentSearchBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.StudentSearchBox.FormattingEnabled = true;
            this.StudentSearchBox.Items.AddRange(new object[] {
            " "});
            this.StudentSearchBox.Location = new System.Drawing.Point(467, 657);
            this.StudentSearchBox.Name = "StudentSearchBox";
            this.StudentSearchBox.Size = new System.Drawing.Size(259, 28);
            this.StudentSearchBox.Sorted = true;
            this.StudentSearchBox.TabIndex = 3;
            // 
            // CourseSearchBox
            // 
            this.CourseSearchBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.CourseSearchBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.CourseSearchBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CourseSearchBox.FormattingEnabled = true;
            this.CourseSearchBox.Items.AddRange(new object[] {
            " "});
            this.CourseSearchBox.Location = new System.Drawing.Point(177, 657);
            this.CourseSearchBox.Name = "CourseSearchBox";
            this.CourseSearchBox.Size = new System.Drawing.Size(284, 28);
            this.CourseSearchBox.Sorted = true;
            this.CourseSearchBox.TabIndex = 4;
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(942, 663);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(94, 29);
            this.BackButton.TabIndex = 5;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(12, 9);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(1024, 54);
            this.ErrorLabel.TabIndex = 6;
            this.ErrorLabel.Text = "Error:";
            this.ErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CourseLabel
            // 
            this.CourseLabel.AutoSize = true;
            this.CourseLabel.Location = new System.Drawing.Point(298, 632);
            this.CourseLabel.Name = "CourseLabel";
            this.CourseLabel.Size = new System.Drawing.Size(54, 20);
            this.CourseLabel.TabIndex = 7;
            this.CourseLabel.Text = "Course";
            // 
            // StudentLabel
            // 
            this.StudentLabel.AutoSize = true;
            this.StudentLabel.Location = new System.Drawing.Point(567, 632);
            this.StudentLabel.Name = "StudentLabel";
            this.StudentLabel.Size = new System.Drawing.Size(60, 20);
            this.StudentLabel.TabIndex = 8;
            this.StudentLabel.Text = "Student";
            // 
            // UserGradeBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1048, 704);
            this.Controls.Add(this.StudentLabel);
            this.Controls.Add(this.CourseLabel);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.CourseSearchBox);
            this.Controls.Add(this.StudentSearchBox);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.GradeBookGrid);
            this.Name = "UserGradeBook";
            this.Text = "Gradebook";
            ((System.ComponentModel.ISupportInitialize)(this.GradeBookGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView GradeBookGrid;
        private Button SaveButton;
        private Button SearchButton;
        private ComboBox StudentSearchBox;
        private ComboBox CourseSearchBox;
        private Button BackButton;
        private Label ErrorLabel;
        private Label CourseLabel;
        private Label StudentLabel;
    }
}