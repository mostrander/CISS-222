﻿namespace Ostrander_Final_Project.Screens
{
    partial class UserViewClassInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ClassList = new System.Windows.Forms.ListView();
            this.BackButton = new System.Windows.Forms.Button();
            this.ViewAllButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // ClassList
            // 
            this.ClassList.FullRowSelect = true;
            this.ClassList.GridLines = true;
            this.ClassList.Location = new System.Drawing.Point(12, 47);
            this.ClassList.Name = "ClassList";
            this.ClassList.Size = new System.Drawing.Size(1012, 446);
            this.ClassList.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.ClassList.TabIndex = 0;
            this.ClassList.UseCompatibleStateImageBehavior = false;
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(930, 538);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(94, 29);
            this.BackButton.TabIndex = 1;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ViewAllButton
            // 
            this.ViewAllButton.Location = new System.Drawing.Point(414, 12);
            this.ViewAllButton.Name = "ViewAllButton";
            this.ViewAllButton.Size = new System.Drawing.Size(123, 29);
            this.ViewAllButton.TabIndex = 2;
            this.ViewAllButton.Text = "All Classes";
            this.ViewAllButton.UseVisualStyleBackColor = true;
            this.ViewAllButton.Click += new System.EventHandler(this.ViewAllButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(12, 496);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(1012, 25);
            this.ErrorLabel.TabIndex = 3;
            this.ErrorLabel.Text = "Error:";
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(307, 12);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(94, 29);
            this.SearchButton.TabIndex = 4;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SearchBox
            // 
            this.SearchBox.Location = new System.Drawing.Point(12, 12);
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.PlaceholderText = "Enter Class ID or Name";
            this.SearchBox.Size = new System.Drawing.Size(283, 27);
            this.SearchBox.TabIndex = 5;
            // 
            // UserViewClassInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 588);
            this.Controls.Add(this.SearchBox);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.ViewAllButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.ClassList);
            this.Name = "UserViewClassInfo";
            this.Text = "View My Classes";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListView ClassList;
        private Button BackButton;
        private Button ViewAllButton;
        private Label ErrorLabel;
        private Button SearchButton;
        private TextBox SearchBox;
    }
}