﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens.Standard_User
{
    public partial class UserCourseAssignments : Form
    {
        Faculty teacher;
        List<Courses> courseList; //List of teacher's OWN classes
        List<Assignment> assignmentList; //List of Assignments for teacher's courses (all) starting
        List<Assignment> assignmentListChanges; //Holds changes
        private string currentUser = LoginScreen.userAccountID; //Stores logged in user's employee id info from login screen form

        public UserCourseAssignments()
        {
            InitializeComponent();

            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;
                List<Faculty> staff = new List<Faculty>();
                List<Courses> currentCourses = new List<Courses>();

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                //Read in the courses offered currently
                fileInput = new FileStream("ClassList.txt", FileMode.OpenOrCreate, FileAccess.Read);

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            currentCourses.Add(new Courses(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                //Add the courses for the teachers accordingly, based on matching instructor ID, which SHOULD be unique
                foreach (Faculty member in staff)
                {
                    bool courseListExists = member.HasCourseList();

                    if (courseListExists == true)
                    {
                        foreach (Courses course in currentCourses)
                        {
                            if (course.GetTeacherID() == member.GetID())
                            {
                                member.AddCourse(course);
                            }
                        }
                    }
                }

                //Find current instructor who is logged in - it SHOULD find the person
                IEnumerable<Faculty>? instructorFound =
                    from faculty in staff
                    where faculty.GetID() == currentUser
                    select faculty;

                if (instructorFound.Any() && instructorFound != null)
                {
                    teacher = instructorFound.First();
                    if (teacher.HasCourseList())
                    {
                        courseList = teacher.GetCourses();
                    
                        foreach(Courses course in courseList)
                        {
                            ListOfCoursesBox.Items.Add(course.GetDeptCode() + "  " + course.GetName());
                        }
                    }
                }
                else
                {
                    ErrorLabel.Text = "Error: Unable to find you in the system.";
                }

                //Import instructor's list of assignments for all courses into the assignmentList object
                fileInput = new FileStream(currentUser + "CourseAssignmentLists.txt", FileMode.OpenOrCreate, FileAccess.Read);
                assignmentList = new List<Assignment>();
                assignmentListChanges = new List<Assignment>();

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            assignmentList.Add(new Assignment(words[0].ToString(), words[1].ToString(), words[2].ToString(), 
                                int.Parse(words[3].ToString()) ));
                        }
                    }

                    fileReader.Close();
                }

                if(assignmentList.Count > 0 && assignmentList != null && assignmentList.Any())
                {
                    foreach(Assignment assignment in assignmentList)
                    {
                        assignmentListChanges.Add(assignment);
                    }
                    DisplayAssignments(assignmentList);
                }

                //import list of assignment types
                fileInput = new FileStream("AssignmentTypeList.txt", FileMode.OpenOrCreate, FileAccess.Read);

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                         AssignmentTypeDropDown.Items.Add(line);
                    }

                    fileReader.Close();
                }


                ErrorLabel.Text = ""; //so error label placement text does not show
            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred while importing the data." +
                    " Please ask your administrator for assistance.";
            }
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Determine if any of the following three fields are filled out.
                string name, type, course;
                name = type = course = "";
                ErrorLabel.Text = "";
                ErrorLabel.ForeColor = Color.Red;

                //Following lists used to store search results
                IEnumerable<Assignment> resultsName;
                IEnumerable<Assignment> resultsCourse;
                IEnumerable<Assignment> resultsType;
                IEnumerable<Assignment> ultimateResults; //Holds final outcome of searches

                if(string.IsNullOrWhiteSpace(AssignmentNameBox.Text) && string.IsNullOrWhiteSpace(AssignmentTypeDropDown.Text) &&
                    string.IsNullOrWhiteSpace(ListOfCoursesBox.Text))
                {
                    DisplayAssignments(assignmentListChanges); //Just show the entire List
                    ErrorLabel.Text = "Displaying all Courses. No search criteria was entered.";
                }
                else
                {
                    if (!string.IsNullOrWhiteSpace(AssignmentNameBox.Text))
                    {
                        name = AssignmentNameBox.Text;

                        resultsName =
                        from assignment in assignmentListChanges
                        where assignment.GetName().Contains(name, StringComparison.OrdinalIgnoreCase)
                        select assignment;

                        if (!string.IsNullOrWhiteSpace(AssignmentTypeDropDown.Text))
                        {
                            type = AssignmentTypeDropDown.Text;

                            resultsType =
                            from assignment in resultsName
                            where assignment.GetType() == type
                            select assignment;

                            if (!string.IsNullOrWhiteSpace(ListOfCoursesBox.Text))
                            {
                                course = ListOfCoursesBox.Text;

                                ultimateResults =
                                from assignment in resultsType
                                where course.Contains(assignment.GetCourseID(), StringComparison.OrdinalIgnoreCase)
                                select assignment;

                                DisplayAssignments(ultimateResults);
                            }
                            else
                            {
                                ultimateResults = resultsType;
                                DisplayAssignments(ultimateResults);
                            }
                        }
                        else if (!string.IsNullOrWhiteSpace(ListOfCoursesBox.Text))
                        {
                            course = ListOfCoursesBox.Text;

                            ultimateResults =
                            from assignment in resultsName
                            where course.Contains(assignment.GetCourseID(), StringComparison.OrdinalIgnoreCase)
                            select assignment;

                            DisplayAssignments(ultimateResults);
                        }
                        else
                        {
                            ultimateResults = resultsName;
                            DisplayAssignments(ultimateResults);
                        }
                    }
                    else if (!string.IsNullOrWhiteSpace(AssignmentTypeDropDown.Text))
                    {
                        type = AssignmentTypeDropDown.Text;

                        resultsType =
                        from assignment in assignmentListChanges
                        where assignment.GetType() == type
                        select assignment;

                        if (!string.IsNullOrWhiteSpace(ListOfCoursesBox.Text))
                        {
                            course = ListOfCoursesBox.Text;

                            ultimateResults =
                            from assignment in resultsType
                            where course.Contains(assignment.GetCourseID(), StringComparison.OrdinalIgnoreCase)
                            select assignment;

                            DisplayAssignments(ultimateResults);
                        }
                        else
                        {
                            ultimateResults= resultsType;
                            DisplayAssignments(ultimateResults);
                        }
                    }
                    else if (!string.IsNullOrWhiteSpace(ListOfCoursesBox.Text))
                    {
                        course = ListOfCoursesBox.Text;

                        ultimateResults =
                        from assignment in assignmentListChanges
                        where course.Contains(assignment.GetCourseID(),StringComparison.OrdinalIgnoreCase)
                        select assignment;

                        DisplayAssignments(ultimateResults);
                    }

                }

            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred while bringing up the assignments for the specified course.";
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void DisplayAssignments(IEnumerable<Assignment> assignedList)
        {
            //Display courses offered in DataGridView as default.
            string[] row = new string [4];

            AssignmentGrid.Rows.Clear(); //Clear rows shown to refresh view properly

            foreach (Assignment assignment in assignedList)
            {
                //first entry is checkbox (default to not checked)
                //2nd entry is courseID for assignment, 3rd entry assignment name, 4th type of assignment, 5th points possible
                row = new string[] {"false", assignment.GetCourseID(), assignment.GetName(), assignment.GetType(),
                    assignment.GetPossiblePoints().ToString()};

                AssignmentGrid.Rows.Add(row);
            }

        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {
                ErrorLabel.ForeColor = Color.Red; //Reset to red
                ErrorLabel.Text = ""; //Clear error messages each attempt
                bool typeAcceptable = false; //Type must be one of the predefined options
                int errorsFound = 0;
                IEnumerable<Assignment> nameMatch;

                if(AssignmentGrid.Rows.Count != assignmentListChanges.Count())
                {
                    ErrorLabel.Text = "Error: Unable to save changes to search results. " +
                        "Please clear the list search before applying changes.";
                }
                else
                {
                    foreach (DataGridViewRow row in AssignmentGrid.Rows)
                    {
                        //Reset the BackColor for all cells
                        row.Cells[2].Style.BackColor = Color.White;
                        row.Cells[3].Style.BackColor = Color.White;
                        row.Cells[4].Style.BackColor = Color.White;

                        //nameMatch =
                        //    from assignment in assignmentListChanges
                        //    where assignment.GetName() == row.Cells[2].Value.ToString()
                        //    select assignment;

                        switch (row.Cells[3].Value.ToString())
                        {
                            case "Extra Credit":
                            case "Homework":
                            case "Practice":
                            case "Project":
                            case "Quiz":
                            case "Test":
                                typeAcceptable = true;
                                break;
                            default:
                                typeAcceptable = false;
                                break;
                        }

                        if (typeAcceptable == false)
                        {
                            row.Cells[3].Style.BackColor = Color.DeepPink;
                            errorsFound++;
                        }
                        //If name is left blank OR name already exists for another assignment in same course
                        if (string.IsNullOrWhiteSpace(row.Cells[2].Value.ToString()) || row.Cells[2] == null)
                        {
                            row.Cells[2].Style.BackColor = Color.DeepPink;
                            errorsFound++;
                        }
                        //If possible points is not entered as digits OR is negative, color the cell
                        if (!row.Cells[4].Value.ToString().All(char.IsDigit) || int.Parse(row.Cells[4].Value.ToString()) < 0)
                        {
                            row.Cells[4].Style.BackColor = Color.DeepPink;
                            errorsFound++;
                        }

                    }

                    if(errorsFound > 0)
                    {
                        ErrorLabel.Text = "Error: The altered information does not meet data specifications. Please revise any colored cells. " +
                            "All cells must be filled, with Possible Points entries being numberical values above zero and Assignment Type" +
                            " must match the predefined list shown in the drop down menu for adding assignments (including capitalization).";
                    }
                    else
                    {
                        SaveChanges();
                    }
                }

            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error occurred while saving the changes.";
            }
        }

        private void AddAssignmentButton_Click(object sender, EventArgs e)
        {
            IEnumerable<Courses> courseMatch;
            IEnumerable<Assignment> assignmentNameFound;
            string courseID;

            //Reset the error label
            ErrorLabel.Text = "";
            ErrorLabel.ForeColor = Color.Red;

            try
            {
                //Student name field is not used in this process.
                //Assignment will be assigned to all students in the respective course automatically.
                if (string.IsNullOrWhiteSpace(AssignmentNameBox.Text))
                {
                    ErrorLabel.Text = "Error: The assignment name field cannot be left empty.";
                }
                else if (string.IsNullOrWhiteSpace(AssignmentTypeDropDown.Text))
                {
                    ErrorLabel.Text = "Error: Please select the type of assignment you are trying to add.";
                }
                else if (string.IsNullOrWhiteSpace(ListOfCoursesBox.Text))
                {
                    ErrorLabel.Text = "Error: You must select the course that you are creating the assignment for.";
                }
                else if (string.IsNullOrWhiteSpace(PossiblePointsBox.Text) || !PossiblePointsBox.Text.All(char.IsDigit) || 
                         int.Parse(PossiblePointsBox.Text) < 0)
                {
                    ErrorLabel.Text = "Error: Points possible for new assignment must be a numeric entry equal or greater than zero.";
                }
                else
                {
                    //Ensure user is not making essentially the exact same assignment (checks name, type, and course selected)
                    assignmentNameFound =
                        from assignment in assignmentListChanges
                        where assignment.GetName() == AssignmentNameBox.Text && 
                        ListOfCoursesBox.Text.Contains(assignment.GetCourseID(), StringComparison.OrdinalIgnoreCase) &&
                        assignment.GetType() == AssignmentTypeDropDown.Text
                        select assignment;

                    if (assignmentNameFound.Any() && assignmentNameFound != null)
                    {
                        ErrorLabel.Text = "Error: An assignment for the selected course already has the chosen assignment name." +
                            " Please enter another assignment name.";
                    }
                    else
                    {
                        courseMatch =
                            from course in courseList
                            where ListOfCoursesBox.Text.Contains(course.GetDeptCode(), StringComparison.OrdinalIgnoreCase)
                            select course;

                        courseID = courseMatch.First().GetDeptCode();

                        assignmentListChanges.Add(new Assignment(courseID, AssignmentNameBox.Text, AssignmentTypeDropDown.Text, int.Parse(PossiblePointsBox.Text) ) );
                        DisplayAssignments(assignmentListChanges);

                        ErrorLabel.Text = "Success.";
                        ErrorLabel.ForeColor = Color.Green;
                    }

                }

            }
            catch
            {
                ErrorLabel.Text = "Error: Something went wrong while adding the new assignment. Please try again.";
            }
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            try
            {
                ErrorLabel.Text = "";
                ErrorLabel.ForeColor= Color.Red;

                string saveName, saveCourse, savePoints, saveType;
                saveName = saveCourse = savePoints = saveType = "";
                string rowDeletion = "false"; //Default value
                bool aRowIsSelected = false; //default value. At least one row must be deleted for deletion

                foreach(DataGridViewRow row in AssignmentGrid.Rows)
                {
                    //If a row is set for deletion, then proceed with rest of method commands
                    //rowDeletion = row.Cells[0].Value.Equals("True");

                    rowDeletion = row.Cells[0].Value.ToString();
                    if (rowDeletion == "true" || rowDeletion.Contains("true", StringComparison.OrdinalIgnoreCase))
                    {
                        aRowIsSelected = true;
                    }
                }

                //If no rows are selected for deletion, end method call.
                if (aRowIsSelected == false)
                {
                    throw new Exception();
                }
                else if (AssignmentGrid.Rows.Count != assignmentListChanges.Count)
                {
                    ErrorLabel.Text = "Error: Unable to save changes to search results. " +
                                "Please clear the list search before applying changes.";
                }
                else
                {
                    assignmentListChanges.Clear(); 

                    //While the AssignmentGrid has rows, for each cell in said row copy to assignmentInfo if not checked for deletion
                    for(int i = 0; i < AssignmentGrid.Rows.Count; i++)
                    {
                        //If row is not to be deleted, save to string and add to list.
                        rowDeletion = AssignmentGrid.Rows[i].Cells[0].Value.ToString();
                        if (rowDeletion == "false" || rowDeletion.Contains("false", StringComparison.OrdinalIgnoreCase))
                        {
                            saveCourse = AssignmentGrid.Rows[i].Cells[1].Value.ToString();
                            saveName = AssignmentGrid.Rows[i].Cells[2].Value.ToString();
                            saveType = AssignmentGrid.Rows[i].Cells[3].Value.ToString();
                            savePoints = AssignmentGrid.Rows[i].Cells[4].Value.ToString();

                            assignmentListChanges.Add(new Assignment(saveCourse,saveName,saveType,int.Parse(savePoints)));
                        }
                    }

                    DisplayAssignments(assignmentListChanges);
                }

            }
            catch
            {
                ErrorLabel.Text = "Error: Unable to complete the deletion request. " +
                    "Please ensure you checked the boxes next the assignments you wish to delete.";
            }
        }

        private void ClearFields()
        {
            AssignmentNameBox.Text = "";
            PossiblePointsBox.Text = "";
            ErrorLabel.Text = "";
            AssignmentTypeDropDown.SelectedIndex = 0;
            ListOfCoursesBox.SelectedIndex = 0;

            DisplayAssignments(assignmentListChanges);
        }

        private void SaveChanges()
        {
            string saveCourse, saveName, saveType, savePoints;
            assignmentListChanges.Clear(); //Empty list so no repeats are entered into the list

            //Copy all contents to assignmentListChanges before storing in text file
            //While the AssignmentGrid has rows, for each cell in said row copy to assignmentInfo if not checked for deletion
            for (int i = 0; i < AssignmentGrid.Rows.Count; i++)
            {

                saveCourse = AssignmentGrid.Rows[i].Cells[1].Value.ToString();
                saveName = AssignmentGrid.Rows[i].Cells[2].Value.ToString();
                saveType = AssignmentGrid.Rows[i].Cells[3].Value.ToString();
                savePoints = AssignmentGrid.Rows[i].Cells[4].Value.ToString();

                assignmentListChanges.Add(new Assignment(saveCourse, saveName, saveType, int.Parse(savePoints)));
            }

            //Output to text file for storage
            string fileName = currentUser + "CourseAssignmentLists.txt";
            using (StreamWriter fileWriter = new StreamWriter(fileName, false))
            {
                foreach (Assignment assigned in assignmentListChanges)
                {
                    fileWriter.WriteLine(assigned.PrintToFile());
                }

                fileWriter.Close();
            }

            ErrorLabel.Text = "Success. Changes saved.";
            ErrorLabel.ForeColor = Color.Green;
        }

        private void ClearSearchButton_Click(object sender, EventArgs e)
        {
            ClearFields();
        }
    }
}
