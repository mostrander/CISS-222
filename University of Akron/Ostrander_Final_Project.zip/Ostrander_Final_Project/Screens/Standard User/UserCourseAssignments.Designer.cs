﻿namespace Ostrander_Final_Project.Screens.Standard_User
{
    partial class UserCourseAssignments
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AssignmentGrid = new System.Windows.Forms.DataGridView();
            this.CheckBoxDelete = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.CourseNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignmentName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AssignmentType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PossiblePoints = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BackButton = new System.Windows.Forms.Button();
            this.SearchButton = new System.Windows.Forms.Button();
            this.ListOfCoursesBox = new System.Windows.Forms.ComboBox();
            this.CoursePickLabel = new System.Windows.Forms.Label();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.SaveButton = new System.Windows.Forms.Button();
            this.AddAssignmentButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.TypeLabel = new System.Windows.Forms.Label();
            this.AssignmentTypeDropDown = new System.Windows.Forms.ComboBox();
            this.AssignmentNameBox = new System.Windows.Forms.TextBox();
            this.DeleteButton = new System.Windows.Forms.Button();
            this.PossiblePointsBox = new System.Windows.Forms.TextBox();
            this.PointsLabel = new System.Windows.Forms.Label();
            this.ClearSearchButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.AssignmentGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // AssignmentGrid
            // 
            this.AssignmentGrid.AllowUserToAddRows = false;
            this.AssignmentGrid.AllowUserToDeleteRows = false;
            this.AssignmentGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AssignmentGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CheckBoxDelete,
            this.CourseNumber,
            this.AssignmentName,
            this.AssignmentType,
            this.PossiblePoints});
            this.AssignmentGrid.Location = new System.Drawing.Point(12, 65);
            this.AssignmentGrid.Name = "AssignmentGrid";
            this.AssignmentGrid.RowHeadersWidth = 51;
            this.AssignmentGrid.RowTemplate.Height = 29;
            this.AssignmentGrid.Size = new System.Drawing.Size(901, 544);
            this.AssignmentGrid.TabIndex = 0;
            // 
            // CheckBoxDelete
            // 
            this.CheckBoxDelete.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.CheckBoxDelete.HeaderText = "Delete?";
            this.CheckBoxDelete.MinimumWidth = 6;
            this.CheckBoxDelete.Name = "CheckBoxDelete";
            this.CheckBoxDelete.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CheckBoxDelete.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.CheckBoxDelete.Width = 89;
            // 
            // CourseNumber
            // 
            this.CourseNumber.HeaderText = "Class ID";
            this.CourseNumber.MinimumWidth = 6;
            this.CourseNumber.Name = "CourseNumber";
            this.CourseNumber.ReadOnly = true;
            this.CourseNumber.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.CourseNumber.Width = 125;
            // 
            // AssignmentName
            // 
            this.AssignmentName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.AssignmentName.HeaderText = "Name";
            this.AssignmentName.MinimumWidth = 6;
            this.AssignmentName.Name = "AssignmentName";
            // 
            // AssignmentType
            // 
            this.AssignmentType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.AssignmentType.HeaderText = "Type";
            this.AssignmentType.MinimumWidth = 6;
            this.AssignmentType.Name = "AssignmentType";
            this.AssignmentType.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // PossiblePoints
            // 
            this.PossiblePoints.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PossiblePoints.HeaderText = "Points Possible";
            this.PossiblePoints.MinimumWidth = 6;
            this.PossiblePoints.Name = "PossiblePoints";
            this.PossiblePoints.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(1126, 504);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(119, 29);
            this.BackButton.TabIndex = 1;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(1014, 401);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(143, 29);
            this.SearchButton.TabIndex = 2;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // ListOfCoursesBox
            // 
            this.ListOfCoursesBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.ListOfCoursesBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ListOfCoursesBox.FormattingEnabled = true;
            this.ListOfCoursesBox.Items.AddRange(new object[] {
            " "});
            this.ListOfCoursesBox.Location = new System.Drawing.Point(1014, 274);
            this.ListOfCoursesBox.Name = "ListOfCoursesBox";
            this.ListOfCoursesBox.Size = new System.Drawing.Size(346, 28);
            this.ListOfCoursesBox.TabIndex = 3;
            // 
            // CoursePickLabel
            // 
            this.CoursePickLabel.AutoSize = true;
            this.CoursePickLabel.Location = new System.Drawing.Point(947, 277);
            this.CoursePickLabel.Name = "CoursePickLabel";
            this.CoursePickLabel.Size = new System.Drawing.Size(61, 20);
            this.CoursePickLabel.TabIndex = 4;
            this.CoursePickLabel.Text = "Course: ";
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(12, 4);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(1378, 58);
            this.ErrorLabel.TabIndex = 5;
            this.ErrorLabel.Text = "Error: ";
            this.ErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(1217, 401);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(143, 29);
            this.SaveButton.TabIndex = 6;
            this.SaveButton.Text = "Save Changes";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // AddAssignmentButton
            // 
            this.AddAssignmentButton.Location = new System.Drawing.Point(1014, 356);
            this.AddAssignmentButton.Name = "AddAssignmentButton";
            this.AddAssignmentButton.Size = new System.Drawing.Size(143, 29);
            this.AddAssignmentButton.TabIndex = 7;
            this.AddAssignmentButton.Text = "Add Assignment";
            this.AddAssignmentButton.UseVisualStyleBackColor = true;
            this.AddAssignmentButton.Click += new System.EventHandler(this.AddAssignmentButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(952, 201);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Name: ";
            // 
            // TypeLabel
            // 
            this.TypeLabel.AutoSize = true;
            this.TypeLabel.Location = new System.Drawing.Point(961, 238);
            this.TypeLabel.Name = "TypeLabel";
            this.TypeLabel.Size = new System.Drawing.Size(47, 20);
            this.TypeLabel.TabIndex = 9;
            this.TypeLabel.Text = "Type: ";
            // 
            // AssignmentTypeDropDown
            // 
            this.AssignmentTypeDropDown.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.AssignmentTypeDropDown.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.AssignmentTypeDropDown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AssignmentTypeDropDown.FormattingEnabled = true;
            this.AssignmentTypeDropDown.Items.AddRange(new object[] {
            " "});
            this.AssignmentTypeDropDown.Location = new System.Drawing.Point(1014, 235);
            this.AssignmentTypeDropDown.Name = "AssignmentTypeDropDown";
            this.AssignmentTypeDropDown.Size = new System.Drawing.Size(346, 28);
            this.AssignmentTypeDropDown.Sorted = true;
            this.AssignmentTypeDropDown.TabIndex = 10;
            // 
            // AssignmentNameBox
            // 
            this.AssignmentNameBox.Location = new System.Drawing.Point(1014, 198);
            this.AssignmentNameBox.Name = "AssignmentNameBox";
            this.AssignmentNameBox.PlaceholderText = "Enter Assignment Name";
            this.AssignmentNameBox.Size = new System.Drawing.Size(346, 27);
            this.AssignmentNameBox.TabIndex = 11;
            // 
            // DeleteButton
            // 
            this.DeleteButton.Location = new System.Drawing.Point(1217, 356);
            this.DeleteButton.Name = "DeleteButton";
            this.DeleteButton.Size = new System.Drawing.Size(143, 29);
            this.DeleteButton.TabIndex = 12;
            this.DeleteButton.Text = "Delete Assignment";
            this.DeleteButton.UseVisualStyleBackColor = true;
            this.DeleteButton.Click += new System.EventHandler(this.DeleteButton_Click);
            // 
            // PossiblePointsBox
            // 
            this.PossiblePointsBox.Location = new System.Drawing.Point(1014, 311);
            this.PossiblePointsBox.Name = "PossiblePointsBox";
            this.PossiblePointsBox.PlaceholderText = "Enter Assignment Possible Points";
            this.PossiblePointsBox.Size = new System.Drawing.Size(346, 27);
            this.PossiblePointsBox.TabIndex = 16;
            // 
            // PointsLabel
            // 
            this.PointsLabel.AutoSize = true;
            this.PointsLabel.Location = new System.Drawing.Point(952, 314);
            this.PointsLabel.Name = "PointsLabel";
            this.PointsLabel.Size = new System.Drawing.Size(55, 20);
            this.PointsLabel.TabIndex = 15;
            this.PointsLabel.Text = "Points: ";
            // 
            // ClearSearchButton
            // 
            this.ClearSearchButton.Location = new System.Drawing.Point(1126, 460);
            this.ClearSearchButton.Name = "ClearSearchButton";
            this.ClearSearchButton.Size = new System.Drawing.Size(119, 29);
            this.ClearSearchButton.TabIndex = 17;
            this.ClearSearchButton.Text = "Clear Search";
            this.ClearSearchButton.UseVisualStyleBackColor = true;
            this.ClearSearchButton.Click += new System.EventHandler(this.ClearSearchButton_Click);
            // 
            // UserCourseAssignments
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1402, 626);
            this.Controls.Add(this.ClearSearchButton);
            this.Controls.Add(this.PossiblePointsBox);
            this.Controls.Add(this.PointsLabel);
            this.Controls.Add(this.DeleteButton);
            this.Controls.Add(this.AssignmentNameBox);
            this.Controls.Add(this.AssignmentTypeDropDown);
            this.Controls.Add(this.TypeLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AddAssignmentButton);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.CoursePickLabel);
            this.Controls.Add(this.ListOfCoursesBox);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.AssignmentGrid);
            this.Name = "UserCourseAssignments";
            this.Text = "Assignments";
            ((System.ComponentModel.ISupportInitialize)(this.AssignmentGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView AssignmentGrid;
        private Button BackButton;
        private Button SearchButton;
        private ComboBox ListOfCoursesBox;
        private Label CoursePickLabel;
        private Label ErrorLabel;
        private Button SaveButton;
        private Button AddAssignmentButton;
        private Label label1;
        private Label TypeLabel;
        private ComboBox AssignmentTypeDropDown;
        private TextBox AssignmentNameBox;
        private Button DeleteButton;
        private TextBox PossiblePointsBox;
        private Label PointsLabel;
        private DataGridViewCheckBoxColumn CheckBoxDelete;
        private DataGridViewTextBoxColumn CourseNumber;
        private DataGridViewTextBoxColumn AssignmentName;
        private DataGridViewTextBoxColumn AssignmentType;
        private DataGridViewTextBoxColumn PossiblePoints;
        private Button ClearSearchButton;
    }
}