﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Ostrander_Final_Project.Classes;

namespace Ostrander_Final_Project.Screens
{
    public partial class LoginScreen : Form
    {
        public static string userAccountID;
        List<Faculty> staff = new List<Faculty>();

        public LoginScreen()
        {
            InitializeComponent();

            LoginErrorLabel.Text = "";
            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();
            }
            catch
            {
                //File does not exist in directory
                //File location C:\Users\ostra\Desktop\C# repos 2022\Ostrander_Final_Project\bin\Debug\net6.0-windows
            }


        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            try
            {
                Faculty userAccount = new(); //User to hold current user information when logged in
                bool adminStatus = false; //Used later to determine which set of menus to use

                string employeeID = UsernameLoginBox.Text;

                LoginErrorLabel.Text = "";
                LoginErrorLabel.ForeColor = Color.Red;

                IEnumerable<Faculty>? accounts =
                from faculty in staff
                where faculty.GetID() == employeeID
                select faculty;

                bool isEmpty = !accounts.Any();

                if (string.IsNullOrWhiteSpace(employeeID))
                {
                    UsernameLoginLabel.ForeColor = Color.Red;
                    LoginErrorLabel.Text = "Error: You did not enter a username. Please Try again.";
                    return;
                }
                //If username field is filled out but no match for ID, throw error
                else if(!string.IsNullOrWhiteSpace(employeeID) && accounts.Count() == 0 || isEmpty == true)
                {
                    UsernameLoginLabel.ForeColor = Color.Red;
                    LoginErrorLabel.Text = "Error: Username not found. Please Try again.";
                }
                //If a match was found AND the ID matched the one entered, then check password field
                else if(accounts.Count() > 0 && accounts.First().GetID() == employeeID)
                {
                    //Remove error coloring and message from failed username attempts (if needed)
                    UsernameLoginLabel.ForeColor = Color.Black;
                    LoginErrorLabel.Text = "";

                    //If the password field is left empty or does not match account found, throw error
                    if (string.IsNullOrWhiteSpace(PasswordLoginBox.Text) || PasswordLoginBox.Text != accounts.First().GetPassword())
                    {
                        PasswordLoginLabel.ForeColor = Color.Red;
                        LoginErrorLabel.Text = "Error: Password is incorrect. Please Try again.";
                        return;
                    }
                    //If password matches for user, allow login
                    else if (PasswordLoginBox.Text == accounts.First().GetPassword())
                    {
                        //Reset color and text for error messages accordingly
                        PasswordLoginLabel.ForeColor = Color.Black;
                        LoginErrorLabel.Text = "";

                        userAccount = accounts.First(); //set userAccount to user logged in WORKS!!!
                        userAccountID = userAccount.GetID();
                        adminStatus = userAccount.GetAdminStatus(); //Determine if user is an admin
                        //LoginErrorLabel.Text = $"Welcome {userAccount.GetName()}!"; //for testing


                        //Login to appropriate Menu based on Admin Status
                        if(adminStatus == false)
                        {
                            this.Hide(); //Hide current form window
                            StandardUserMenu1 standardMenu1 = new StandardUserMenu1();
                            standardMenu1.ShowDialog();

                            this.Show();
                        }
                        else if(adminStatus == true)
                        {
                            this.Hide(); //This works for at least hiding the window, but it remains open in background
                            AdminMenu adminForm1 = new AdminMenu();
                            adminForm1.ShowDialog(); //Show next form

                            this.Show(); //When admin form is closed, show this form again (to properly close application)
                        }
                    } 
                }//End of else if blocks
            }
            catch
            {
                LoginErrorLabel.Text = "Error: An unexpected error has occurred.";
            }


        } //end of button click method

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
    }
}
