﻿namespace Ostrander_Final_Project.Screens
{
    partial class AdminViewClass
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InstructorList = new System.Windows.Forms.ListView();
            this.AdminBackButton = new System.Windows.Forms.Button();
            this.ViewAllButton = new System.Windows.Forms.Button();
            this.AdminSearchButton = new System.Windows.Forms.Button();
            this.InstructorSearchBox = new System.Windows.Forms.TextBox();
            this.InstructorLabel = new System.Windows.Forms.Label();
            this.AdminErrorLabel = new System.Windows.Forms.Label();
            this.ShowInstructorClassesButton = new System.Windows.Forms.Button();
            this.AllCoursesButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // InstructorList
            // 
            this.InstructorList.Location = new System.Drawing.Point(27, 12);
            this.InstructorList.Name = "InstructorList";
            this.InstructorList.Size = new System.Drawing.Size(712, 492);
            this.InstructorList.Sorting = System.Windows.Forms.SortOrder.Descending;
            this.InstructorList.TabIndex = 0;
            this.InstructorList.UseCompatibleStateImageBehavior = false;
            // 
            // AdminBackButton
            // 
            this.AdminBackButton.Location = new System.Drawing.Point(593, 602);
            this.AdminBackButton.Name = "AdminBackButton";
            this.AdminBackButton.Size = new System.Drawing.Size(94, 29);
            this.AdminBackButton.TabIndex = 1;
            this.AdminBackButton.Text = "Back";
            this.AdminBackButton.UseVisualStyleBackColor = true;
            this.AdminBackButton.Click += new System.EventHandler(this.AdminBackButton_Click);
            // 
            // ViewAllButton
            // 
            this.ViewAllButton.Location = new System.Drawing.Point(77, 602);
            this.ViewAllButton.Name = "ViewAllButton";
            this.ViewAllButton.Size = new System.Drawing.Size(228, 29);
            this.ViewAllButton.TabIndex = 2;
            this.ViewAllButton.Text = "View All Active Instructors";
            this.ViewAllButton.UseVisualStyleBackColor = true;
            this.ViewAllButton.Click += new System.EventHandler(this.ViewAllButton_Click);
            // 
            // AdminSearchButton
            // 
            this.AdminSearchButton.Location = new System.Drawing.Point(423, 544);
            this.AdminSearchButton.Name = "AdminSearchButton";
            this.AdminSearchButton.Size = new System.Drawing.Size(94, 29);
            this.AdminSearchButton.TabIndex = 3;
            this.AdminSearchButton.Text = "Search";
            this.AdminSearchButton.UseVisualStyleBackColor = true;
            this.AdminSearchButton.Click += new System.EventHandler(this.AdminSearchButton_Click);
            // 
            // InstructorSearchBox
            // 
            this.InstructorSearchBox.Location = new System.Drawing.Point(180, 544);
            this.InstructorSearchBox.Name = "InstructorSearchBox";
            this.InstructorSearchBox.PlaceholderText = "Enter Instructor ID or Name";
            this.InstructorSearchBox.Size = new System.Drawing.Size(228, 27);
            this.InstructorSearchBox.TabIndex = 4;
            // 
            // InstructorLabel
            // 
            this.InstructorLabel.AutoSize = true;
            this.InstructorLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.InstructorLabel.Location = new System.Drawing.Point(74, 540);
            this.InstructorLabel.Name = "InstructorLabel";
            this.InstructorLabel.Size = new System.Drawing.Size(105, 28);
            this.InstructorLabel.TabIndex = 5;
            this.InstructorLabel.Text = "Instructor: ";
            // 
            // AdminErrorLabel
            // 
            this.AdminErrorLabel.AutoSize = true;
            this.AdminErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.AdminErrorLabel.Location = new System.Drawing.Point(180, 512);
            this.AdminErrorLabel.Name = "AdminErrorLabel";
            this.AdminErrorLabel.Size = new System.Drawing.Size(0, 20);
            this.AdminErrorLabel.TabIndex = 6;
            // 
            // ShowInstructorClassesButton
            // 
            this.ShowInstructorClassesButton.Location = new System.Drawing.Point(532, 544);
            this.ShowInstructorClassesButton.Name = "ShowInstructorClassesButton";
            this.ShowInstructorClassesButton.Size = new System.Drawing.Size(155, 29);
            this.ShowInstructorClassesButton.TabIndex = 7;
            this.ShowInstructorClassesButton.Text = "See Their Classes";
            this.ShowInstructorClassesButton.UseVisualStyleBackColor = true;
            this.ShowInstructorClassesButton.Click += new System.EventHandler(this.ShowInstructorClassesButton_Click);
            // 
            // AllCoursesButton
            // 
            this.AllCoursesButton.Location = new System.Drawing.Point(335, 602);
            this.AllCoursesButton.Name = "AllCoursesButton";
            this.AllCoursesButton.Size = new System.Drawing.Size(228, 29);
            this.AllCoursesButton.TabIndex = 8;
            this.AllCoursesButton.Text = "View All Offered Courses";
            this.AllCoursesButton.UseVisualStyleBackColor = true;
            this.AllCoursesButton.Click += new System.EventHandler(this.AllCoursesButton_Click);
            // 
            // AdminViewClass
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 653);
            this.Controls.Add(this.AllCoursesButton);
            this.Controls.Add(this.ShowInstructorClassesButton);
            this.Controls.Add(this.AdminErrorLabel);
            this.Controls.Add(this.InstructorLabel);
            this.Controls.Add(this.InstructorSearchBox);
            this.Controls.Add(this.AdminSearchButton);
            this.Controls.Add(this.ViewAllButton);
            this.Controls.Add(this.AdminBackButton);
            this.Controls.Add(this.InstructorList);
            this.Name = "AdminViewClass";
            this.Text = "Course Search";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListView InstructorList;
        private Button AdminBackButton;
        private Button ViewAllButton;
        private Button AdminSearchButton;
        private TextBox InstructorSearchBox;
        private Label InstructorLabel;
        private Label AdminErrorLabel;
        private Button ShowInstructorClassesButton;
        private Button AllCoursesButton;
    }
}