﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens
{

    public partial class AdminEditFaculty : Form
    {
        private List<Faculty> staff = new List<Faculty>();
        private List<Courses> currentCourses = new List<Courses>(); //used for printing classes currently registered
        private Faculty selectedUser;
        public static string selectedUserID; //Holds selectedUser ID so information can be passed to another form
        private string currentUser = LoginScreen.userAccountID; //Stores logged in user's employee id info from login screen form, SHOULD be an admin
        private List<string> departmentSelection = new List<string>(); //Holds department information

        public AdminEditFaculty()
        {
            InitializeComponent();

            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput = new FileStream("ClassList.txt", FileMode.OpenOrCreate, FileAccess.Read);

                using(StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            currentCourses.Add(new Courses(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                //Add the courses for the teachers accordingly, based on matching instructor ID, which SHOULD be unique
                foreach (Faculty member in staff)
                {
                    bool courseListExists = member.HasCourseList();

                    if( courseListExists == true)
                    {
                        foreach(Courses course in currentCourses)
                        {
                            if(course.GetTeacherID() == member.GetID())
                            {
                                member.AddCourse(course);
                            }
                        }
                    }
                }

                //Load in department information for dropdown menu
                //Import list of Departments
                fileInput = new FileStream("DepartmentList.txt", FileMode.OpenOrCreate, FileAccess.Read);
                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        if (!string.IsNullOrWhiteSpace(line)) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            departmentSelection.Add(line);
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();

                //Load lists into the dropdown boxes
                foreach (string item in departmentSelection)
                {
                    AdminDepartmentBox2.Items.Add(item);
                }

                AdminErrorLabel1.Text = "";
            }

            catch
            {
                AdminErrorLabel1.Text = "Error: There was a problem loading the necessary data.";
            }
        }

        private void AdminCancelButton1_Click(object sender, EventArgs e)
        {
            this.Close(); //Close this form and return to previous form (AdminMenu1)
        }

        private void AdminCheckIDButton1_Click(object sender, EventArgs e)
        {
            //Test value to attempt simulating hack or user account mistakenly accessing Admin Menu (which shouldn't happen anyway)
            //Uncomment for testing to ensure user is kicked immediately if invalid or non admin result
            //NOTE: EmployeeIDs should be unique
            //currentUser = "S111"; 

            //Clear any previous error messages
            AdminErrorLabel1.Text = "";

            try
            {
                //Verify currentUser actually exists and is an admin FIRST
                //In a try block because it seems to crash if no results are found

                IEnumerable<Faculty>? accounts =
                from faculty in staff
                where faculty.GetID() == currentUser
                select faculty;

                bool isEmpty = !accounts.Any();

                //Kick user out if current logged in user Employee ID is not found, or is not an Admin authorized ID
                if ( isEmpty == true || (accounts.First().GetID() == currentUser && accounts.First().GetAdminStatus() != true))
                {
                    throw new Exception();
                }

                bool verify = LookUpUserID(); 

            }
            catch
            {

                //Code in place should hacker or nonadmin user get into the Admin menu system. 
                //Note: I am not a hacker, so this is probably mediocre protection at best.

                //userAccount is invalid. Close Admin menu immediately and boot back to Login Screen
                this.Close();
            }
        } 

        private void AdminClearButton1_Click(object sender, EventArgs e)
        {
            //Clear any previous error messages
            AdminErrorLabel1.Text = "";

            //Clear all displayed data
            AdminEmployeeIDBox1.Text = "";
            AdminFNameBox1.Text = "";
            AdminLNameBox1.Text = "";
            AdminAddressBox1.Text = "";
            AdminPhoneBox1.Text = "";
            AdminDepartmentBox2.Text = "";
            AdminSalaryBox1.Text = "";
            AdminStatusOnButton1.Checked = false;
            AdminStatusOffButton1.Checked = false;
        }

        private void AdminUpdateButton_Click(object sender, EventArgs e)
        {
            //Clear any previous error messages
            AdminErrorLabel1.Text = "";
            AdminErrorLabel1.ForeColor = Color.Red;

            try
            {
                //Check that there IS an ID entered first
                if (string.IsNullOrWhiteSpace(AdminEmployeeIDBox1.Text))
                {
                    AdminErrorLabel1.Text = "Error: Employee ID was not entered. Please try again.";
                }
                else if (!string.IsNullOrWhiteSpace(AdminEmployeeIDBox1.Text) && selectedUser == null)
                {
                    AdminErrorLabel1.Text = "Error: Unable to update faculty information without first looking the user up. " +
                        "Performing user lookup now...";
                    LookUpUserID();
                }
                //Do not allow Admins to change their own admin status. Other Admins can change status for other users/admins.
                else if (selectedUser.GetID() == currentUser && AdminStatusOffButton1.Checked)
                {
                    AdminErrorLabel1.Text = "Error: Administrators cannot change Admin Rights for themselves.\n" +
                        "Doing so would result in loss of access to Administrator functionality.\n" +
                        "Admin Rights for this account remains unchanged.";
                    return;
                }

                //All fields must have data and the data must be input correctly. Uses another method in class to verify
                else if(VerifyUserInput() == false)
                {
                    return;
                }
                else
                {
                        //Update all user information.
                        /*HUGE PROBLEM: Have to update the actual staff List in order for information to stick.
                         Which currently means that the information will not technically be saved to the user side of program
                        because I have to manually pull the information in each time per Form currently*/

                        selectedUser.UpdateName(AdminFNameBox1.Text, AdminLNameBox1.Text);
                        selectedUser.UpdateAddress(AdminAddressBox1.Text);
                        selectedUser.UpdatePhone(AdminPhoneBox1.Text);
                        selectedUser.UpdateDepartment(AdminDepartmentBox2.Text);
                        selectedUser.UpdateSalary(decimal.Parse(AdminSalaryBox1.Text));

                        //Change admin settings based on radio button selected
                        if (AdminStatusOffButton1.Checked)
                        {
                            selectedUser.UpdateAdmin(false);
                        }
                        else if (AdminStatusOnButton1.Checked)
                        {
                            selectedUser.UpdateAdmin(true);
                        }

                        AdminUpdateRecords(); //Updates records

                        AdminErrorLabel1.Text = "Account Updated.";
                        AdminErrorLabel1.ForeColor = Color.Green;

                } // End of If/else structure

            }
            catch
            {
                 AdminErrorLabel1.Text = "Unknown error: Unable to complete the operation.\n" +
                        "Please verify data entered and try again.";

            } //End of catch block

        }

        private void PasswordResetButton_Click(object sender, EventArgs e)
        {
            AdminErrorLabel1.Text = "";

            if (selectedUserID == null && string.IsNullOrWhiteSpace(AdminEmployeeIDBox1.Text))
            {
                AdminErrorLabel1.Text = "Error: Employee ID field is blank. Please search an ID number and try again.";
                AdminErrorLabel1.ForeColor = Color.Red;
            }
            else
            {
                this.Hide();
                AdminResetPassword userResetPassword = new AdminResetPassword();
                userResetPassword.ShowDialog();

                this.Show();
            }
        }

        private void RemoveFacultyButton_Click(object sender, EventArgs e)
        {
            AdminErrorLabel1.Text = "";

            try
            {
                //Note: selectedUserID is set when running the search on employee id field.
                if (selectedUserID == null && string.IsNullOrWhiteSpace(AdminEmployeeIDBox1.Text))
                {
                    AdminErrorLabel1.Text = "Error: Employee ID field is blank. Please search an ID number and try again.";
                    AdminErrorLabel1.ForeColor = Color.Red;
                }
                else if (AdminEmployeeIDBox1.Text == currentUser)
                {
                    AdminErrorLabel1.Text = "Error: You cannot delete yourself!";
                }
                else if(LookUpUserID() != false)
                {
                    var confirmResult = MessageBox.Show("Are you sure you want to delete this account?",
                                         "Confirm Delete.",
                                         MessageBoxButtons.YesNo);
                    if (confirmResult == DialogResult.Yes)
                    {
                        // If 'Yes', store the account information in a separate file should it need to be restored
                        //This only appends the information to file, it does NOT completely rewrite the entire file
                        using (StreamWriter AddToFile = File.AppendText("C:\\Users\\ostra\\Desktop\\C# repos 2022\\Ostrander_Final_Project\\DB Files\\FormerFacultyAccounts.txt"))
                        {
                            AddToFile.WriteLine(selectedUser.PrintToFile());
                        }

                        //Remove individual from active staff list
                        var individual = 
                            from faculty in staff
                            where faculty.GetID() == selectedUser.GetID()
                            select faculty;

                        staff.Remove(individual.First());

                        AdminUpdateRecords();
                    }
                    else
                    {
                        AdminErrorLabel1.Text = "Deletion process aborted.";
                        return;
                    }    
                }
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An unexpected error occurred while removing the account.";
            }

            
        }

        private void AddFacultyButton_Click(object sender, EventArgs e)
        {
            AdminErrorLabel1.ForeColor = Color.Red;
            try
            {
                //Employee ID does not exist for new faculty member yet, so verify other information
                //If other entries all pass checks, then verify information does not match existing accounts first
                if(VerifyUserInput() == true)
                {
                    var check = 
                        from faculty in staff
                        where faculty.GetFName() == AdminFNameBox1.Text && faculty.GetLName() == AdminLNameBox1.Text
                           && faculty.GetAddress() == AdminAddressBox1.Text
                        select faculty;

                    bool matchFound = check.Any();

                    if(matchFound == true)
                    {
                        //If match is found, verify admin wishes to proceed with account creation
                        var confirmResult = MessageBox.Show("An account matching the name and address you entered already exists." +
                            "\nThe employee ID is: " + check.First().GetID() + "\nDo you wish to proceed?",
                                     "Confirm Delete.",
                                     MessageBoxButtons.YesNo);

                        if(confirmResult == DialogResult.Yes)
                        {
                            AddEmployeeAccount();
                        }
                        else
                        {
                            AdminErrorLabel1.Text = "Account creation aborted.";
                        }
                    }
                    else
                    {
                        //Proceed with account creation if no matches are found
                        AddEmployeeAccount();
                    }
                }
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An unexpected error occurred while adding the new faculty account.";
            }
        }


        private void AdminUpdateRecords()
        {
            //Saves all account information to a file so it can be used next time program is launched
            using (StreamWriter fileWriter = new StreamWriter("FacultyAccounts.txt", false))
            {
                var sorted = from accounts in staff
                             orderby accounts.GetID() ascending
                             select accounts;

                //Print each account to the file. NOTE: Stores files in bin folder currently
                foreach(Faculty individual in sorted)
                {
                    fileWriter.WriteLine(individual.PrintToFile());

                    if(individual.HasCourseList() == true)
                    {
                        //pull in the list of their classes and save to a special list that will be printed at end
                        var individualClasses = individual.GetCourses();

                        foreach(Courses course in individualClasses)
                        {
                            if (!currentCourses.Contains(course))
                            {
                                currentCourses.Add(course);
                            }
                        }
                    }
                }

                using (StreamWriter classWriter = new StreamWriter("ClassList.txt", false))
                {
                    foreach(Courses courses in currentCourses)
                    {
                        classWriter.WriteLine(courses.PrintClassInformation());
                    }
                    classWriter.Close();
                }

                fileWriter.Close();
            }

        }

        private bool LookUpUserID()
        {
            try
            {
                //Grab entered ID and determine if user exists in database
                string employeeID = AdminEmployeeIDBox1.Text;

                //It should only find ONE result. Allowed to be null to avoid crashing
                IEnumerable<Faculty>? user =
                from faculty in staff
                where faculty.GetID() == employeeID
                select faculty;

                bool isEmpty = !user.Any();

                //if nothing is entered, user count is 0 or the result is empty 
                if (user.Count() == 0 || isEmpty == true)
                {
                    AdminErrorLabel1.Text = "Error: Employee ID not found. Please try again.";
                    AdminErrorLabel1.ForeColor = Color.Red;
                    return false;
                }
                else
                {
                    foreach (var faculty in user)
                    {
                        //Save selected user for use in the update button call
                        selectedUser = user.First();
                        selectedUserID = selectedUser.GetID();

                        //Display current user information to screen
                        AdminFNameBox1.Text = user.First().GetFName();
                        AdminLNameBox1.Text = user.First().GetLName();
                        AdminAddressBox1.Text = user.First().GetAddress();
                        AdminPhoneBox1.Text = user.First().GetPhone();
                        AdminSalaryBox1.Text = user.First().GetSalary().ToString();

                        //Used to locate the department information and set if found
                        //Which is should because all new faculty accounts require selection from drop menu
                        int index = AdminDepartmentBox2.FindString(user.First().GetDepartment());
                        if (index < 0)
                        {
                            MessageBox.Show("Item not found.");
                        }
                        else
                        {
                            AdminDepartmentBox2.SelectedIndex = index;
                        }

                        if (user.First().GetAdminStatus() == true)
                        {
                            AdminStatusOnButton1.Checked = true;
                        }
                        else
                        {
                            AdminStatusOffButton1.Checked = true;
                        }

                    }

                    return true;
                }
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: Unexpected error occurred while looking up user information.";
                return false;
            }

        }

        private bool VerifyUserInput()
        {
            try
            {
                if (string.IsNullOrWhiteSpace(AdminFNameBox1.Text))
                {
                    AdminErrorLabel1.Text += "Error: First Name field cannot be left blank.\n";
                    return false;
                }
                else if (string.IsNullOrWhiteSpace(AdminLNameBox1.Text))
                {
                    AdminErrorLabel1.Text += "Error: Last Name field cannot be left blank.\n";
                    return false;
                }
                else if (string.IsNullOrWhiteSpace(AdminAddressBox1.Text))
                {
                    AdminErrorLabel1.Text += "Error: Address field cannot be left blank.\n";
                    return false;
                }
                else if (string.IsNullOrWhiteSpace(AdminPhoneBox1.Text))
                {
                    AdminErrorLabel1.Text += "Error: Phone field cannot be left blank.\n";
                    return false;
                }
                //Check phone information is input in correct format
                else if (DataVerified(AdminPhoneBox1.Text, "phone") == false)
                {
                    AdminErrorLabel1.Text += "Error: Phone information given is in the wrong format.\n";
                    return false;
                }
                else if (string.IsNullOrWhiteSpace(AdminDepartmentBox2.Text))
                {
                    AdminErrorLabel1.Text += "Error: Department field cannot be left blank.\n";
                    return false;
                }
                else if (AdminStatusOffButton1.Checked == false && AdminStatusOnButton1.Checked == false)
                {
                    AdminErrorLabel1.Text = "Error: You must select the admin rights for account before proceeding.";
                    return false;
                }
                else if (string.IsNullOrWhiteSpace(AdminSalaryBox1.Text))
                {
                    AdminErrorLabel1.Text += "Error: Salary field cannot be left blank.\n";
                    return false;
                }
                //Need try-catch block because of this code.
                else if (decimal.TryParse(AdminSalaryBox1.Text, out decimal result))
                {
                    if (result < 0)
                    {
                        AdminErrorLabel1.Text += "Error: Salary cannot be negative.\n";
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return true;
                }
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An unexpected error has occurred. " +
                    "Please verify that the Salary field is not blank and only contains a numeric value.";
                return false;
            }
        }

        private bool DataVerified(string data, string field)
        {
            try
            {
                string pattern = "";
                if (field == "phone")
                {
                    //Verifies that phone entered matches one of following formats:
                    /*
                     *  +XXXXXXXXXXXX
                     *  XXXXXXXXXX
                     *  +XXXXXXXXXXX
                     *  XXX-XXX-XXXX
                    */
                    pattern = @"^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$";
                }
                //Note currently used since no email information implemented. Keeping just in case needed later
                else if (field == "email")
                {
                    //Simple regex for determining if email is in general XXXX@XXXX.XXX format.
                    pattern = @"[^@ \t\r\n]+@[^@ \t\r\n]+\.[^@ \t\r\n]+";
                }

                var match = Regex.Match(data, pattern);
                return match.Success;
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An unexpected error occurred while verifying phone or email entry.";
                return false;
            }

        }

        private void AddEmployeeAccount()
        {
            try
            {
                VerifyUserInput();

                bool matchID = true; //Used to run while loop until an unused ID is found
                string newEmployeeID = "TX";
                bool matchFound = true;
                Random random = new Random();

                while (matchID == true)
                {
                    
                    newEmployeeID += random.Next(0,9999); //Added limit because the account number selected was CRAZY long!
                    var check =
                        from faculty in staff
                        where faculty.GetID() == newEmployeeID
                        select faculty;

                    matchFound = check.Any();

                    if (matchFound == false)
                    {
                        matchID = false;
                        break;
                    }
                    else
                    {
                        newEmployeeID = "TX"; //Reset and try again
                    }
                }

                if (AdminStatusOffButton1.Checked == true)
                {
                    Faculty newEmployee = new Faculty(AdminFNameBox1.Text, AdminLNameBox1.Text, AdminAddressBox1.Text, AdminPhoneBox1.Text,
                        newEmployeeID, AdminDepartmentBox2.Text, decimal.Parse(AdminSalaryBox1.Text), false);
                    staff.Add(newEmployee);
                }
                else if (AdminStatusOnButton1.Checked == true)
                {
                    Faculty newEmployee = new Faculty(AdminFNameBox1.Text, AdminLNameBox1.Text, AdminAddressBox1.Text, AdminPhoneBox1.Text,
                        newEmployeeID, AdminDepartmentBox2.Text, decimal.Parse(AdminSalaryBox1.Text), true);
                    staff.Add(newEmployee);
                }

                AdminErrorLabel1.Text = "Account Successfully created! Employee ID is: " + newEmployeeID;
                AdminErrorLabel1.ForeColor = Color.Green;
                AdminUpdateRecords();
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An unexpected error occurred while adding the new faculty account.";
            }

        }
    }
}
