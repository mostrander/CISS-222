﻿namespace Ostrander_Final_Project.Screens
{
    partial class AdminResetPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.Label();
            this.CancelButton = new System.Windows.Forms.Button();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.New_Password_Box2 = new System.Windows.Forms.MaskedTextBox();
            this.New_Password_Box1 = new System.Windows.Forms.MaskedTextBox();
            this.Label_NewPassword2 = new System.Windows.Forms.Label();
            this.Label_NewPassword1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.BackColor = System.Drawing.SystemColors.Control;
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(12, 174);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(366, 99);
            this.ErrorLabel.TabIndex = 22;
            this.ErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NameLabel
            // 
            this.NameLabel.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.NameLabel.Location = new System.Drawing.Point(12, 17);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(366, 51);
            this.NameLabel.TabIndex = 21;
            this.NameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(210, 288);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(94, 29);
            this.CancelButton.TabIndex = 20;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(82, 288);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(94, 29);
            this.SubmitButton.TabIndex = 19;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // New_Password_Box2
            // 
            this.New_Password_Box2.Location = new System.Drawing.Point(142, 134);
            this.New_Password_Box2.Name = "New_Password_Box2";
            this.New_Password_Box2.PasswordChar = '*';
            this.New_Password_Box2.Size = new System.Drawing.Size(218, 27);
            this.New_Password_Box2.TabIndex = 18;
            // 
            // New_Password_Box1
            // 
            this.New_Password_Box1.Location = new System.Drawing.Point(142, 89);
            this.New_Password_Box1.Name = "New_Password_Box1";
            this.New_Password_Box1.PasswordChar = '*';
            this.New_Password_Box1.Size = new System.Drawing.Size(218, 27);
            this.New_Password_Box1.TabIndex = 17;
            // 
            // Label_NewPassword2
            // 
            this.Label_NewPassword2.AutoSize = true;
            this.Label_NewPassword2.Location = new System.Drawing.Point(36, 137);
            this.Label_NewPassword2.Name = "Label_NewPassword2";
            this.Label_NewPassword2.Size = new System.Drawing.Size(89, 20);
            this.Label_NewPassword2.TabIndex = 15;
            this.Label_NewPassword2.Text = "Enter Again:";
            // 
            // Label_NewPassword1
            // 
            this.Label_NewPassword1.AutoSize = true;
            this.Label_NewPassword1.Location = new System.Drawing.Point(24, 92);
            this.Label_NewPassword1.Name = "Label_NewPassword1";
            this.Label_NewPassword1.Size = new System.Drawing.Size(107, 20);
            this.Label_NewPassword1.TabIndex = 14;
            this.Label_NewPassword1.Text = "New Password:";
            // 
            // AdminResetPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 332);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.New_Password_Box2);
            this.Controls.Add(this.New_Password_Box1);
            this.Controls.Add(this.Label_NewPassword2);
            this.Controls.Add(this.Label_NewPassword1);
            this.Name = "AdminResetPassword";
            this.Text = "Password Reset";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label ErrorLabel;
        private Label NameLabel;
        private Button CancelButton;
        private Button SubmitButton;
        private MaskedTextBox New_Password_Box2;
        private MaskedTextBox New_Password_Box1;
        private Label Label_NewPassword2;
        private Label Label_NewPassword1;
    }
}