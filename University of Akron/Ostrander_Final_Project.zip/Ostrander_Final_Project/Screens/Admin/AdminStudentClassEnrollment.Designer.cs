﻿namespace Ostrander_Final_Project.Screens
{
    partial class AdminStudentClassEnrollment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CourseGridView = new System.Windows.Forms.DataGridView();
            this.chk = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.CourseIDCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CourseName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InstructorName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CurrentClassCapacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaxClassCapacity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BackButton = new System.Windows.Forms.Button();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.ErrorLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.CourseGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // CourseGridView
            // 
            this.CourseGridView.AllowUserToAddRows = false;
            this.CourseGridView.AllowUserToDeleteRows = false;
            this.CourseGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CourseGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.chk,
            this.CourseIDCode,
            this.CourseName,
            this.InstructorName,
            this.CurrentClassCapacity,
            this.MaxClassCapacity});
            this.CourseGridView.Location = new System.Drawing.Point(12, 12);
            this.CourseGridView.Name = "CourseGridView";
            this.CourseGridView.RowHeadersWidth = 51;
            this.CourseGridView.RowTemplate.Height = 29;
            this.CourseGridView.Size = new System.Drawing.Size(935, 482);
            this.CourseGridView.TabIndex = 0;
            // 
            // chk
            // 
            this.chk.HeaderText = "Enrolled";
            this.chk.MinimumWidth = 6;
            this.chk.Name = "chk";
            this.chk.Width = 75;
            // 
            // CourseIDCode
            // 
            this.CourseIDCode.HeaderText = "Course ID";
            this.CourseIDCode.MinimumWidth = 6;
            this.CourseIDCode.Name = "CourseIDCode";
            this.CourseIDCode.Width = 125;
            // 
            // CourseName
            // 
            this.CourseName.HeaderText = "Course Name";
            this.CourseName.MinimumWidth = 6;
            this.CourseName.Name = "CourseName";
            this.CourseName.Width = 250;
            // 
            // InstructorName
            // 
            this.InstructorName.HeaderText = "Instructor";
            this.InstructorName.MinimumWidth = 6;
            this.InstructorName.Name = "InstructorName";
            this.InstructorName.Width = 250;
            // 
            // CurrentClassCapacity
            // 
            this.CurrentClassCapacity.HeaderText = "Current Capacity";
            this.CurrentClassCapacity.MinimumWidth = 6;
            this.CurrentClassCapacity.Name = "CurrentClassCapacity";
            this.CurrentClassCapacity.Width = 90;
            // 
            // MaxClassCapacity
            // 
            this.MaxClassCapacity.HeaderText = "Max Capacity";
            this.MaxClassCapacity.MinimumWidth = 6;
            this.MaxClassCapacity.Name = "MaxClassCapacity";
            this.MaxClassCapacity.Width = 90;
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(852, 519);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(94, 29);
            this.BackButton.TabIndex = 1;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // UpdateButton
            // 
            this.UpdateButton.Location = new System.Drawing.Point(742, 519);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(94, 29);
            this.UpdateButton.TabIndex = 2;
            this.UpdateButton.Text = "Update";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(12, 497);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(593, 63);
            this.ErrorLabel.TabIndex = 3;
            this.ErrorLabel.Text = "Error: ";
            this.ErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AdminStudentClassEnrollment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 569);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.UpdateButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.CourseGridView);
            this.Name = "AdminStudentClassEnrollment";
            this.Text = "Course Enrollment ";
            ((System.ComponentModel.ISupportInitialize)(this.CourseGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DataGridView CourseGridView;
        private DataGridViewCheckBoxColumn chk;
        private DataGridViewTextBoxColumn CourseIDCode;
        private DataGridViewTextBoxColumn CourseName;
        private DataGridViewTextBoxColumn InstructorName;
        private DataGridViewTextBoxColumn CurrentClassCapacity;
        private DataGridViewTextBoxColumn MaxClassCapacity;
        private Button BackButton;
        private Button UpdateButton;
        private Label ErrorLabel;
    }
}