﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens
{
    public partial class AdminMenu : Form
    {
        private List<Faculty> staff = new List<Faculty>(); //Holds the data for the faculty list
        private string currentUser = LoginScreen.userAccountID; //Stores logged in user's employee id info from login screen form

        public AdminMenu()
        {
            InitializeComponent();

            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();

                //Uncomment next lines to see program crash when form is opened with invalid account (S111) or non admin (T142)
                //currentUser = "S111";
                //currentUser = "T142"; 

                var account =
                from faculty in staff
                where faculty.GetID() == currentUser
                select faculty;

                //If there are any results found, check that individual is an admin
                if (account.Any() && account.First().GetAdminStatus() == true)
                {
                    string name = "";
                    foreach(Faculty faculty in account)
                    {
                        name = faculty.GetName();
                    }

                    AdminMenuLabel1.Text = $"Welcome {name}!";
                }
                else
                {
                    throw new Exception();
                }

            }
            catch
            {
                //Crashes program completely if user is not found and is not an admin
                Environment.Exit(0);
            }



        }

        private void AdminExitButton1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void AdminViewFacultyButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminViewFaculty viewFacultyInformation = new AdminViewFaculty();
            viewFacultyInformation.ShowDialog();

            this.Show();
        }

        private void AdminChangeFacultyButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminEditFaculty changeFacultyInformation = new AdminEditFaculty();
            changeFacultyInformation.ShowDialog();

            this.Show();
        }

        private void AdminClassInfoButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminViewClass currentClassesTaught = new AdminViewClass();
            currentClassesTaught.ShowDialog();

            this.Show();
        }

        private void EnrollmentButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminStudentEnrollment enrollment = new AdminStudentEnrollment();
            enrollment.ShowDialog();

            this.Show();
        }

        private void ChangePasswordButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserChangePassword changePassword = new UserChangePassword();
            changePassword.ShowDialog();

            this.Show();
        }

        private void ModifyCoursesButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminModifyCourseList changeCourseList = new AdminModifyCourseList();
            changeCourseList.ShowDialog();

            this.Show();
        }
    }
}
