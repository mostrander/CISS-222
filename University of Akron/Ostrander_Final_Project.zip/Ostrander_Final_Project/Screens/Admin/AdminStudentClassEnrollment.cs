﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens
{
    public partial class AdminStudentClassEnrollment : Form
    {
        private List<Faculty> staff = new List<Faculty>(); //Holds the data for the faculty list
        private List<Courses> currentCourses = new List<Courses>(); //Holds data for courses offered currently
        private List<Student> StudentsEnrolled = new List<Student>(); //List of all students
        private string studentSelected = AdminStudentEnrollment.selectedStudent;
        Student individual;



        public AdminStudentClassEnrollment()
        {
            InitializeComponent();

            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                //Read in the entire courses offered list, SHOULD auto call in student enrollment
                fileInput = new FileStream("ClassList.txt", FileMode.OpenOrCreate, FileAccess.Read);

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            currentCourses.Add(new Courses(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                            words[4].ToString(), words[5].ToString(), words[6].ToString()));
                        }
                    }

                    fileReader.Close();
                }


                //Import entire list of students
                fileInput = new FileStream("StudentAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            StudentsEnrolled.Add(new Student(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                            words[4].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();

                //Grab student account
                IEnumerable<Student> chosenStudent =
                    from available in StudentsEnrolled
                    where available.GetStudentID() == studentSelected
                    select available;

                individual = chosenStudent.First();

                DisplayCourses();
                ErrorLabel.Text = "";

            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error occurred while loading data.";
            }

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            ErrorLabel.Text = "";
            ErrorLabel.ForeColor = Color.Red;

            try
            {
                List<string> changesMade = new List<string>();
                int size = CourseGridView.Rows.Count;
                string information;

                //Grab student account
                IEnumerable<Student> chosenStudent =
                    from available in StudentsEnrolled
                    where available.GetStudentID() == studentSelected
                    select available;

                Student individual = chosenStudent.First();
                string courseEnrollmentSelected;
                bool studentEnrollmentFound = false; //assumed false

                //For every row (which is a class listing
                foreach(DataGridViewRow row in CourseGridView.Rows)
                {
                    foreach(Courses course in currentCourses)
                    {
                        //compare the displayed courseID with each course department code
                        if(course.GetDeptCode() == row.Cells["CourseIDCode"].Value.ToString())
                        {
                            //If courseID match is found then check if check box is checked.
                            courseEnrollmentSelected = row.Cells[0].Value.ToString();

                            //search students enrolled in course
                            foreach (Student student in course.GetEnrollment())
                            {
                                if(student.GetStudentID() == individual.GetStudentID())
                                {
                                    studentEnrollmentFound = true;
                                }
                            }

                            //If yes and student is NOT in the course, add them
                            if ( studentEnrollmentFound == false && 
                               ( courseEnrollmentSelected == "true" || 
                                 courseEnrollmentSelected.Contains("true", StringComparison.OrdinalIgnoreCase)) )
                            {

                                //verify that the course is not full first
                                if(int.Parse(course.GetCurrentCapacity()) < int.Parse(course.GetMaxCapacity()) )
                                {
                                    course.AddStudent(individual);
                                }
                                else
                                {
                                    ErrorLabel.Text = "Unable to add student to all chosen courses due to course capacity limits.";
                                }


                            }
                            //If not checked and they ARE in the class, remove them.
                            else if (studentEnrollmentFound == true && courseEnrollmentSelected == "false" ||
                                 courseEnrollmentSelected.Contains("false", StringComparison.OrdinalIgnoreCase)) 
                            {
                                course.RemoveStudent(individual);
                            }

                        }

                    }

                } //End of row foreach loop


                //Output to text files for storage
                SaveChanges();

                //Update View
                DisplayCourses();

            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred while updating the student's class enrollment.";
            }
        }



        private void DisplayCourses()
        {
            //Display courses offered in DataGridView as default.
            string[] row;
            List<Student> students = new List<Student>();

            CourseGridView.Rows.Clear(); //Clear rows shown to refresh view properly

            foreach (Courses course in currentCourses)
            {
                students = course.GetEnrollment();

                if (course.GetEnrollment() == null || !course.GetEnrollment().Any())
                {
                    row = new string[] { "false", course.GetDeptCode(), course.GetName(), course.GetTeacherID(), course.GetCurrentCapacity(), course.GetMaxCapacity() };
                    CourseGridView.Rows.Add(row);
                }
                else
                {
                    //Identify if student/individual is in the specific course
                    IEnumerable<Student>? studentFound =
                        from student in students
                        where student.GetStudentID() == individual.GetStudentID()
                        select student;

                    //If match is found, add a check mark next to class to indicate enrollment, else do not
                    if (studentFound != null && studentFound.Any())
                    {
                        row = new string[] { "true", course.GetDeptCode(), course.GetName(), course.GetTeacherID(), course.GetCurrentCapacity(), course.GetMaxCapacity() };
                        CourseGridView.Rows.Add(row);
                    }
                    else
                    {
                        row = new string[] { "false", course.GetDeptCode(), course.GetName(), course.GetTeacherID(), course.GetCurrentCapacity(), course.GetMaxCapacity() };
                        CourseGridView.Rows.Add(row);
                    }
                }
            }

        } //End of method


        private void SaveChanges()
        {
            //Output to text file for storage
            using (StreamWriter fileWriter = new StreamWriter("CourseEnrollment.txt", false))
            {
                IEnumerable<Courses> sortedCourseList =
                    from course in currentCourses
                    where course.GetEnrollment() != null && course.GetEnrollment().Any()
                    orderby course.GetDeptCode()
                    select course;

                foreach (Courses course in sortedCourseList)
                {
                    course.ClassHasStudentsEnrolled();

                    foreach(Student student in course.GetEnrollment())
                    {
                        fileWriter.WriteLine(course.PrintStudents(student));
                    }
                }

                //reprint courses to update the information
                using (StreamWriter classWriter = new StreamWriter("ClassList.txt", false))
                {
                    foreach (Courses course in currentCourses)
                    {
                        classWriter.WriteLine(course.PrintClassInformation());
                    }
                    classWriter.Close();
                }

                fileWriter.Close();
            }

        }

    }

}
