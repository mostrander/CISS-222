﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens
{
    public partial class AdminViewFaculty : Form
    {
        private List<Faculty> staff = new List<Faculty>();
        private List<Courses> currentCourses = new List<Courses>();
        ListViewItem[] listResults;//creates array to pass to AddRange() later
        ListViewItem item;//Will be used for creating each item individually

        public AdminViewFaculty()
        {
            InitializeComponent();

            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput = new FileStream("ClassList.txt", FileMode.OpenOrCreate, FileAccess.Read);

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            currentCourses.Add(new Courses(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                            words[4].ToString(), words[5].ToString(), words[6].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();

                //Add the courses for the teachers accordingly, based on matching instructor ID, which SHOULD be unique
                foreach (Faculty faculty in staff)
                {
                    if (faculty.HasCourseList() == true)
                    {
                        foreach (Courses course in currentCourses)
                        {
                            if (course.GetTeacherID() == faculty.GetID())
                            {
                                faculty.AddCourse(course);
                            }
                        }
                    }
                }

                AdminErrorLabel1.Text = "";

            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An unexpected error occurred while loading data.";
            }
        }

        private void AdminBackButton1_Click(object sender, EventArgs e)
        {
            AdminInfoBox1.Items.Clear(); //Clear list show whenever button is pressed

            //Return to previous menu
            this.Close();
        }

        private void AdminViewIGeneralButton_Click(object sender, EventArgs e)
        {
            AdminInfoBox1.Items.Clear(); //Clear list show whenever button is pressed
            AdminErrorLabel1.Text = "";

            //Shows basic information such as faculty Name, Department, Phone
            try
            {
                //Select everyone
                IEnumerable<Faculty>? facultyAccounts =
                    from faculty in staff
                    orderby faculty.GetLName()
                    select faculty;
            
                bool isEmpty = !facultyAccounts.Any(); //Verify there are entries first before performing actions

                if(isEmpty == false)
                {
                    DisplayResultsGeneral(facultyAccounts);
                }
                else
                {
                    AdminErrorLabel1.Text = "Error: No valid entries found. Unable to display data.";
                }
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An Unexpected error has occurred. Unable to complete operation.";
            }

        }

        private void AdminViewAllButton_Click(object sender, EventArgs e)
        {
            AdminInfoBox1.Items.Clear(); //Clear list show whenever button is pressed
            AdminErrorLabel1.Text = "";

            //Shows all information associated with faculty members
            try
            {
                //Select everyone
                IEnumerable<Faculty>? facultyAccounts =
                    from faculty in staff
                    orderby faculty.GetLName()
                    select faculty;

                bool isEmpty = !facultyAccounts.Any(); //Verify there are entries first before performing actions

                if (isEmpty == false)
                {
                    DisplayResultsAll(facultyAccounts);
                }
                else
                {
                    AdminErrorLabel1.Text = "Error: No valid entries found. Unable to display data.";
                }
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An Unexpected error has occurred. Unable to complete operation.";
            }
        }

        private void AdminSearchFacultyButton_Click(object sender, EventArgs e)
        {
            AdminInfoBox1.Items.Clear(); //Clear list show whenever button is pressed
            AdminErrorLabel1.Text = "";

            //Shows all information associated with faculty members
            try
            {
                if (!string.IsNullOrWhiteSpace(searchBox.Text))
                {
                    //Select everyone that matches search text REGARDLESS of case sensitivity
                    IEnumerable<Faculty>? facultyAccounts =
                        from faculty in staff
                        where faculty.GetName().Contains(searchBox.Text, StringComparison.OrdinalIgnoreCase)
                        orderby faculty.GetLName()
                        select faculty;

                    bool isEmpty = !facultyAccounts.Any(); //Verify there are entries first before performing actions

                    if (isEmpty == false)
                    {
                        DisplayResultsAll(facultyAccounts);
                    }
                    else
                    {
                        AdminErrorLabel1.Text = "Error: No valid entries found. Unable to display data.";
                    }
                }
                else
                {
                    AdminErrorLabel1.Text = "Error: You did not enter a name in the search field. Please try again.";
                }

            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An Unexpected error has occurred. Unable to complete operation.";
            }
        }

        private void DisplayResultsGeneral(IEnumerable<Faculty>? results)
        {
            //Similar to the Search button functionality, except it returns EVERYONE that teaches.
            //Employees who teach will start will have an idea that starts with T?
            //At least in my program they do. Probably will not work that way in the real world

            //Clear items and columns so duplicates do not appear
            AdminInfoBox1.Items.Clear();
            AdminInfoBox1.Columns.Clear();

            //Clear the error label & search box
            AdminErrorLabel1.Text = "";
            //InstructorSearchBox.Text = "";

            //List Columns for making viewing easier; -2 is for autosizing
            AdminInfoBox1.Columns.Add("Last, First Name", 250, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("ID", 70, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("Department", 265, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("Admin?", 100, HorizontalAlignment.Center);

            //Show details of the items and allow columns to be reordered
            AdminInfoBox1.View = View.Details;
            AdminInfoBox1.AllowColumnReorder = true;
            AdminInfoBox1.GridLines = true;
            AdminInfoBox1.FullRowSelect = true; //Allows rows to be selected
            AdminInfoBox1.AllowDrop = false; //Do not accept anything dragged and dropped onto the control
            AdminInfoBox1.Sort();

            try
            {
                if (results.Any())
                {
                    int size = results.Count(); //Number of results found
                    int count = 0; //Log current entry for inserting into array

                    listResults = new ListViewItem[size];

                    foreach (var member in results)
                    {
                        item = new ListViewItem(member.PrintName(), 0);
                        item.SubItems.Add(member.GetID());
                        item.SubItems.Add(member.GetDepartment());
                        item.SubItems.Add(member.GetAdminStatus().ToString());
                        listResults[count] = item;
                        count++;
                    }

                    AdminInfoBox1.Items.AddRange(listResults); //Output to the ListItem box control

                }
                else
                {
                    AdminInfoBox1.Text = "Error: No results found.";
                    return;
                }
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An unexpected error has occurred while displaying results.";
            }
        }

        private void DisplayResultsAll(IEnumerable<Faculty>? results)
        {
            //Similar to the Search button functionality, except it returns EVERYONE that teaches.
            //Employees who teach will start will have an idea that starts with T?
            //At least in my program they do. Probably will not work that way in the real world

            //Clear items and columns so duplicates do not appear
            AdminInfoBox1.Items.Clear();
            AdminInfoBox1.Columns.Clear();

            //Clear the error label & search box
            AdminErrorLabel1.Text = "";
            //InstructorSearchBox.Text = "";

            //List Columns for making viewing easier; -2 is for autosizing
            AdminInfoBox1.Columns.Add("Last, First Name", 250, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("Address", 250, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("Phone", 150, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("ID", 70, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("Department", 265, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("Salary", 150, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("Admin?", 100, HorizontalAlignment.Center);
            AdminInfoBox1.Columns.Add("Courses", 100, HorizontalAlignment.Center);

            //Show details of the items and allow columns to be reordered
            AdminInfoBox1.View = View.Details;
            AdminInfoBox1.AllowColumnReorder = true;
            AdminInfoBox1.GridLines = true;
            AdminInfoBox1.FullRowSelect = true; //Allows rows to be selected
            AdminInfoBox1.AllowDrop = false; //Do not accept anything dragged and dropped onto the control
            AdminInfoBox1.Sort();

            try
            {
                if (results.Any())
                {
                    int size = results.Count(); //Number of results found
                    int count = 0; //Log current entry for inserting into array

                    listResults = new ListViewItem[size];

                    foreach (var member in results)
                    {
                        item = new ListViewItem(member.PrintName(), 0);
                        item.SubItems.Add(member.GetAddress());
                        item.SubItems.Add(member.GetPhone());
                        item.SubItems.Add(member.GetID());
                        item.SubItems.Add(member.GetDepartment());
                        item.SubItems.Add("$" + member.GetSalary().ToString());
                        item.SubItems.Add(member.GetAdminStatus().ToString());
                        item.SubItems.Add(member.NumberOfCourses().ToString());

                        listResults[count] = item;
                        count++;
                    }

                    AdminInfoBox1.Items.AddRange(listResults); //Output to the ListItem box control

                }
                else
                {
                    AdminInfoBox1.Text = "Error: No results found.";
                    return;
                }
            }
            catch
            {
                AdminErrorLabel1.Text = "Error: An unexpected error has occurred while displaying results.";
            }
        }

    }
}
