﻿namespace Ostrander_Final_Project.Screens
{
    partial class AdminEditFaculty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AdminCheckIDButton1 = new System.Windows.Forms.Button();
            this.AdminClearButton1 = new System.Windows.Forms.Button();
            this.AdminEmployeeIDBox1 = new System.Windows.Forms.TextBox();
            this.AdminIDEntryLabel1 = new System.Windows.Forms.Label();
            this.AdminFNameBox1 = new System.Windows.Forms.TextBox();
            this.AdminFNameLabel1 = new System.Windows.Forms.Label();
            this.AdminLNameLabel1 = new System.Windows.Forms.Label();
            this.AdminLNameBox1 = new System.Windows.Forms.TextBox();
            this.AdminAddressLabel1 = new System.Windows.Forms.Label();
            this.AdminAddressBox1 = new System.Windows.Forms.TextBox();
            this.AdminPhoneLabel1 = new System.Windows.Forms.Label();
            this.AdminPhoneBox1 = new System.Windows.Forms.TextBox();
            this.AdminDepartmentLabel1 = new System.Windows.Forms.Label();
            this.AdminSalaryLabel1 = new System.Windows.Forms.Label();
            this.AdminSalaryBox1 = new System.Windows.Forms.TextBox();
            this.AdminStatusGroupBox1 = new System.Windows.Forms.GroupBox();
            this.AdminStatusOffButton1 = new System.Windows.Forms.RadioButton();
            this.AdminStatusOnButton1 = new System.Windows.Forms.RadioButton();
            this.AdminUpdateButton = new System.Windows.Forms.Button();
            this.AdminCancelButton1 = new System.Windows.Forms.Button();
            this.AdminErrorLabel1 = new System.Windows.Forms.Label();
            this.RemoveFacultyButton = new System.Windows.Forms.Button();
            this.AddFacultyButton = new System.Windows.Forms.Button();
            this.PasswordResetButton = new System.Windows.Forms.Button();
            this.AdminDepartmentBox2 = new System.Windows.Forms.ComboBox();
            this.AdminStatusGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // AdminCheckIDButton1
            // 
            this.AdminCheckIDButton1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminCheckIDButton1.Location = new System.Drawing.Point(275, 85);
            this.AdminCheckIDButton1.Name = "AdminCheckIDButton1";
            this.AdminCheckIDButton1.Size = new System.Drawing.Size(94, 29);
            this.AdminCheckIDButton1.TabIndex = 2;
            this.AdminCheckIDButton1.Text = "Check ID";
            this.AdminCheckIDButton1.UseVisualStyleBackColor = true;
            this.AdminCheckIDButton1.Click += new System.EventHandler(this.AdminCheckIDButton1_Click);
            // 
            // AdminClearButton1
            // 
            this.AdminClearButton1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminClearButton1.Location = new System.Drawing.Point(388, 85);
            this.AdminClearButton1.Name = "AdminClearButton1";
            this.AdminClearButton1.Size = new System.Drawing.Size(94, 29);
            this.AdminClearButton1.TabIndex = 3;
            this.AdminClearButton1.Text = "Clear";
            this.AdminClearButton1.UseVisualStyleBackColor = true;
            this.AdminClearButton1.Click += new System.EventHandler(this.AdminClearButton1_Click);
            // 
            // AdminEmployeeIDBox1
            // 
            this.AdminEmployeeIDBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminEmployeeIDBox1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.AdminEmployeeIDBox1.Location = new System.Drawing.Point(275, 49);
            this.AdminEmployeeIDBox1.Name = "AdminEmployeeIDBox1";
            this.AdminEmployeeIDBox1.Size = new System.Drawing.Size(207, 30);
            this.AdminEmployeeIDBox1.TabIndex = 1;
            // 
            // AdminIDEntryLabel1
            // 
            this.AdminIDEntryLabel1.AutoSize = true;
            this.AdminIDEntryLabel1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminIDEntryLabel1.Location = new System.Drawing.Point(272, 26);
            this.AdminIDEntryLabel1.Name = "AdminIDEntryLabel1";
            this.AdminIDEntryLabel1.Size = new System.Drawing.Size(110, 23);
            this.AdminIDEntryLabel1.TabIndex = 3;
            this.AdminIDEntryLabel1.Text = "Employee ID:";
            // 
            // AdminFNameBox1
            // 
            this.AdminFNameBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminFNameBox1.Location = new System.Drawing.Point(123, 149);
            this.AdminFNameBox1.Name = "AdminFNameBox1";
            this.AdminFNameBox1.Size = new System.Drawing.Size(221, 30);
            this.AdminFNameBox1.TabIndex = 4;
            // 
            // AdminFNameLabel1
            // 
            this.AdminFNameLabel1.AutoSize = true;
            this.AdminFNameLabel1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminFNameLabel1.Location = new System.Drawing.Point(20, 152);
            this.AdminFNameLabel1.Name = "AdminFNameLabel1";
            this.AdminFNameLabel1.Size = new System.Drawing.Size(101, 23);
            this.AdminFNameLabel1.TabIndex = 0;
            this.AdminFNameLabel1.Text = "First Name: ";
            // 
            // AdminLNameLabel1
            // 
            this.AdminLNameLabel1.AutoSize = true;
            this.AdminLNameLabel1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminLNameLabel1.Location = new System.Drawing.Point(21, 196);
            this.AdminLNameLabel1.Name = "AdminLNameLabel1";
            this.AdminLNameLabel1.Size = new System.Drawing.Size(100, 23);
            this.AdminLNameLabel1.TabIndex = 0;
            this.AdminLNameLabel1.Text = "Last Name: ";
            // 
            // AdminLNameBox1
            // 
            this.AdminLNameBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminLNameBox1.Location = new System.Drawing.Point(123, 193);
            this.AdminLNameBox1.Name = "AdminLNameBox1";
            this.AdminLNameBox1.Size = new System.Drawing.Size(221, 30);
            this.AdminLNameBox1.TabIndex = 5;
            // 
            // AdminAddressLabel1
            // 
            this.AdminAddressLabel1.AutoSize = true;
            this.AdminAddressLabel1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminAddressLabel1.Location = new System.Drawing.Point(42, 243);
            this.AdminAddressLabel1.Name = "AdminAddressLabel1";
            this.AdminAddressLabel1.Size = new System.Drawing.Size(79, 23);
            this.AdminAddressLabel1.TabIndex = 0;
            this.AdminAddressLabel1.Text = "Address: ";
            // 
            // AdminAddressBox1
            // 
            this.AdminAddressBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminAddressBox1.Location = new System.Drawing.Point(123, 240);
            this.AdminAddressBox1.Name = "AdminAddressBox1";
            this.AdminAddressBox1.Size = new System.Drawing.Size(221, 30);
            this.AdminAddressBox1.TabIndex = 6;
            // 
            // AdminPhoneLabel1
            // 
            this.AdminPhoneLabel1.AutoSize = true;
            this.AdminPhoneLabel1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminPhoneLabel1.Location = new System.Drawing.Point(54, 290);
            this.AdminPhoneLabel1.Name = "AdminPhoneLabel1";
            this.AdminPhoneLabel1.Size = new System.Drawing.Size(63, 23);
            this.AdminPhoneLabel1.TabIndex = 0;
            this.AdminPhoneLabel1.Text = "Phone:";
            // 
            // AdminPhoneBox1
            // 
            this.AdminPhoneBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminPhoneBox1.Location = new System.Drawing.Point(123, 287);
            this.AdminPhoneBox1.Name = "AdminPhoneBox1";
            this.AdminPhoneBox1.Size = new System.Drawing.Size(221, 30);
            this.AdminPhoneBox1.TabIndex = 7;
            // 
            // AdminDepartmentLabel1
            // 
            this.AdminDepartmentLabel1.AutoSize = true;
            this.AdminDepartmentLabel1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminDepartmentLabel1.Location = new System.Drawing.Point(381, 152);
            this.AdminDepartmentLabel1.Name = "AdminDepartmentLabel1";
            this.AdminDepartmentLabel1.Size = new System.Drawing.Size(111, 23);
            this.AdminDepartmentLabel1.TabIndex = 0;
            this.AdminDepartmentLabel1.Text = "Department: ";
            // 
            // AdminSalaryLabel1
            // 
            this.AdminSalaryLabel1.AutoSize = true;
            this.AdminSalaryLabel1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminSalaryLabel1.Location = new System.Drawing.Point(428, 196);
            this.AdminSalaryLabel1.Name = "AdminSalaryLabel1";
            this.AdminSalaryLabel1.Size = new System.Drawing.Size(64, 23);
            this.AdminSalaryLabel1.TabIndex = 0;
            this.AdminSalaryLabel1.Text = "Salary: ";
            // 
            // AdminSalaryBox1
            // 
            this.AdminSalaryBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminSalaryBox1.Location = new System.Drawing.Point(498, 193);
            this.AdminSalaryBox1.Name = "AdminSalaryBox1";
            this.AdminSalaryBox1.Size = new System.Drawing.Size(221, 30);
            this.AdminSalaryBox1.TabIndex = 9;
            // 
            // AdminStatusGroupBox1
            // 
            this.AdminStatusGroupBox1.Controls.Add(this.AdminStatusOffButton1);
            this.AdminStatusGroupBox1.Controls.Add(this.AdminStatusOnButton1);
            this.AdminStatusGroupBox1.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminStatusGroupBox1.Location = new System.Drawing.Point(498, 251);
            this.AdminStatusGroupBox1.Name = "AdminStatusGroupBox1";
            this.AdminStatusGroupBox1.Size = new System.Drawing.Size(221, 76);
            this.AdminStatusGroupBox1.TabIndex = 0;
            this.AdminStatusGroupBox1.TabStop = false;
            this.AdminStatusGroupBox1.Text = "Grant Admin Rights?";
            // 
            // AdminStatusOffButton1
            // 
            this.AdminStatusOffButton1.AutoSize = true;
            this.AdminStatusOffButton1.Location = new System.Drawing.Point(131, 33);
            this.AdminStatusOffButton1.Name = "AdminStatusOffButton1";
            this.AdminStatusOffButton1.Size = new System.Drawing.Size(54, 27);
            this.AdminStatusOffButton1.TabIndex = 0;
            this.AdminStatusOffButton1.TabStop = true;
            this.AdminStatusOffButton1.Text = "No";
            this.AdminStatusOffButton1.UseVisualStyleBackColor = true;
            // 
            // AdminStatusOnButton1
            // 
            this.AdminStatusOnButton1.AutoSize = true;
            this.AdminStatusOnButton1.Location = new System.Drawing.Point(43, 33);
            this.AdminStatusOnButton1.Name = "AdminStatusOnButton1";
            this.AdminStatusOnButton1.Size = new System.Drawing.Size(55, 27);
            this.AdminStatusOnButton1.TabIndex = 0;
            this.AdminStatusOnButton1.TabStop = true;
            this.AdminStatusOnButton1.Text = "Yes";
            this.AdminStatusOnButton1.UseVisualStyleBackColor = true;
            // 
            // AdminUpdateButton
            // 
            this.AdminUpdateButton.Location = new System.Drawing.Point(251, 456);
            this.AdminUpdateButton.Name = "AdminUpdateButton";
            this.AdminUpdateButton.Size = new System.Drawing.Size(94, 29);
            this.AdminUpdateButton.TabIndex = 10;
            this.AdminUpdateButton.Text = "Update";
            this.AdminUpdateButton.UseVisualStyleBackColor = true;
            this.AdminUpdateButton.Click += new System.EventHandler(this.AdminUpdateButton_Click);
            // 
            // AdminCancelButton1
            // 
            this.AdminCancelButton1.Location = new System.Drawing.Point(625, 456);
            this.AdminCancelButton1.Name = "AdminCancelButton1";
            this.AdminCancelButton1.Size = new System.Drawing.Size(94, 29);
            this.AdminCancelButton1.TabIndex = 11;
            this.AdminCancelButton1.Text = "Cancel";
            this.AdminCancelButton1.UseVisualStyleBackColor = true;
            this.AdminCancelButton1.Click += new System.EventHandler(this.AdminCancelButton1_Click);
            // 
            // AdminErrorLabel1
            // 
            this.AdminErrorLabel1.ForeColor = System.Drawing.Color.Red;
            this.AdminErrorLabel1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.AdminErrorLabel1.Location = new System.Drawing.Point(20, 326);
            this.AdminErrorLabel1.Name = "AdminErrorLabel1";
            this.AdminErrorLabel1.Size = new System.Drawing.Size(699, 119);
            this.AdminErrorLabel1.TabIndex = 23;
            this.AdminErrorLabel1.Text = "Error: ";
            this.AdminErrorLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RemoveFacultyButton
            // 
            this.RemoveFacultyButton.Location = new System.Drawing.Point(137, 456);
            this.RemoveFacultyButton.Name = "RemoveFacultyButton";
            this.RemoveFacultyButton.Size = new System.Drawing.Size(94, 29);
            this.RemoveFacultyButton.TabIndex = 24;
            this.RemoveFacultyButton.Text = "Delete";
            this.RemoveFacultyButton.UseVisualStyleBackColor = true;
            this.RemoveFacultyButton.Click += new System.EventHandler(this.RemoveFacultyButton_Click);
            // 
            // AddFacultyButton
            // 
            this.AddFacultyButton.Location = new System.Drawing.Point(27, 456);
            this.AddFacultyButton.Name = "AddFacultyButton";
            this.AddFacultyButton.Size = new System.Drawing.Size(94, 29);
            this.AddFacultyButton.TabIndex = 25;
            this.AddFacultyButton.Text = "Add";
            this.AddFacultyButton.UseVisualStyleBackColor = true;
            this.AddFacultyButton.Click += new System.EventHandler(this.AddFacultyButton_Click);
            // 
            // PasswordResetButton
            // 
            this.PasswordResetButton.Location = new System.Drawing.Point(461, 456);
            this.PasswordResetButton.Name = "PasswordResetButton";
            this.PasswordResetButton.Size = new System.Drawing.Size(147, 29);
            this.PasswordResetButton.TabIndex = 26;
            this.PasswordResetButton.Text = "Reset Password";
            this.PasswordResetButton.UseVisualStyleBackColor = true;
            this.PasswordResetButton.Click += new System.EventHandler(this.PasswordResetButton_Click);
            // 
            // AdminDepartmentBox2
            // 
            this.AdminDepartmentBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AdminDepartmentBox2.FormattingEnabled = true;
            this.AdminDepartmentBox2.Items.AddRange(new object[] {
            " "});
            this.AdminDepartmentBox2.Location = new System.Drawing.Point(498, 150);
            this.AdminDepartmentBox2.MaxDropDownItems = 20;
            this.AdminDepartmentBox2.Name = "AdminDepartmentBox2";
            this.AdminDepartmentBox2.Size = new System.Drawing.Size(221, 28);
            this.AdminDepartmentBox2.TabIndex = 27;
            // 
            // AdminEditFaculty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 497);
            this.Controls.Add(this.AdminDepartmentBox2);
            this.Controls.Add(this.PasswordResetButton);
            this.Controls.Add(this.AddFacultyButton);
            this.Controls.Add(this.RemoveFacultyButton);
            this.Controls.Add(this.AdminErrorLabel1);
            this.Controls.Add(this.AdminCancelButton1);
            this.Controls.Add(this.AdminUpdateButton);
            this.Controls.Add(this.AdminStatusGroupBox1);
            this.Controls.Add(this.AdminSalaryLabel1);
            this.Controls.Add(this.AdminSalaryBox1);
            this.Controls.Add(this.AdminDepartmentLabel1);
            this.Controls.Add(this.AdminPhoneLabel1);
            this.Controls.Add(this.AdminPhoneBox1);
            this.Controls.Add(this.AdminAddressLabel1);
            this.Controls.Add(this.AdminAddressBox1);
            this.Controls.Add(this.AdminLNameLabel1);
            this.Controls.Add(this.AdminLNameBox1);
            this.Controls.Add(this.AdminFNameLabel1);
            this.Controls.Add(this.AdminFNameBox1);
            this.Controls.Add(this.AdminIDEntryLabel1);
            this.Controls.Add(this.AdminEmployeeIDBox1);
            this.Controls.Add(this.AdminClearButton1);
            this.Controls.Add(this.AdminCheckIDButton1);
            this.Name = "AdminEditFaculty";
            this.Text = "Update Faculty";
            this.AdminStatusGroupBox1.ResumeLayout(false);
            this.AdminStatusGroupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button AdminCheckIDButton1;
        private Button AdminClearButton1;
        private TextBox AdminEmployeeIDBox1;
        private Label AdminIDEntryLabel1;
        private TextBox AdminFNameBox1;
        private Label AdminFNameLabel1;
        private Label AdminLNameLabel1;
        private TextBox AdminLNameBox1;
        private Label AdminAddressLabel1;
        private TextBox AdminAddressBox1;
        private Label AdminPhoneLabel1;
        private TextBox AdminPhoneBox1;
        private Label AdminDepartmentLabel1;
        private Label AdminSalaryLabel1;
        private TextBox AdminSalaryBox1;
        private GroupBox AdminStatusGroupBox1;
        private Button AdminUpdateButton;
        private Button AdminCancelButton1;
        private RadioButton AdminStatusOffButton1;
        private RadioButton AdminStatusOnButton1;
        private Label AdminErrorLabel1;
        private Button RemoveFacultyButton;
        private Button AddFacultyButton;
        private Button PasswordResetButton;
        private ComboBox AdminDepartmentBox2;
    }
}