﻿namespace Ostrander_Final_Project.Screens
{
    partial class AdminViewFaculty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AdminBackButton1 = new System.Windows.Forms.Button();
            this.AdminViewGeneralButton = new System.Windows.Forms.Button();
            this.AdminViewAllButton = new System.Windows.Forms.Button();
            this.AdminErrorLabel1 = new System.Windows.Forms.Label();
            this.AdminInfoBox1 = new System.Windows.Forms.ListView();
            this.AdminSearchFacultyButton = new System.Windows.Forms.Button();
            this.searchBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // AdminBackButton1
            // 
            this.AdminBackButton1.Location = new System.Drawing.Point(1172, 511);
            this.AdminBackButton1.Name = "AdminBackButton1";
            this.AdminBackButton1.Size = new System.Drawing.Size(94, 29);
            this.AdminBackButton1.TabIndex = 1;
            this.AdminBackButton1.Text = "Back";
            this.AdminBackButton1.UseVisualStyleBackColor = true;
            this.AdminBackButton1.Click += new System.EventHandler(this.AdminBackButton1_Click);
            // 
            // AdminViewGeneralButton
            // 
            this.AdminViewGeneralButton.Location = new System.Drawing.Point(740, 511);
            this.AdminViewGeneralButton.Name = "AdminViewGeneralButton";
            this.AdminViewGeneralButton.Size = new System.Drawing.Size(204, 29);
            this.AdminViewGeneralButton.TabIndex = 2;
            this.AdminViewGeneralButton.Text = "View General Information";
            this.AdminViewGeneralButton.UseVisualStyleBackColor = true;
            this.AdminViewGeneralButton.Click += new System.EventHandler(this.AdminViewIGeneralButton_Click);
            // 
            // AdminViewAllButton
            // 
            this.AdminViewAllButton.Location = new System.Drawing.Point(965, 511);
            this.AdminViewAllButton.Name = "AdminViewAllButton";
            this.AdminViewAllButton.Size = new System.Drawing.Size(184, 29);
            this.AdminViewAllButton.TabIndex = 3;
            this.AdminViewAllButton.Text = "View All Information";
            this.AdminViewAllButton.UseVisualStyleBackColor = true;
            this.AdminViewAllButton.Click += new System.EventHandler(this.AdminViewAllButton_Click);
            // 
            // AdminErrorLabel1
            // 
            this.AdminErrorLabel1.ForeColor = System.Drawing.Color.Red;
            this.AdminErrorLabel1.Location = new System.Drawing.Point(31, 9);
            this.AdminErrorLabel1.Name = "AdminErrorLabel1";
            this.AdminErrorLabel1.Size = new System.Drawing.Size(1235, 26);
            this.AdminErrorLabel1.TabIndex = 4;
            this.AdminErrorLabel1.Text = "Error: ";
            this.AdminErrorLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AdminInfoBox1
            // 
            this.AdminInfoBox1.Location = new System.Drawing.Point(31, 45);
            this.AdminInfoBox1.Name = "AdminInfoBox1";
            this.AdminInfoBox1.Size = new System.Drawing.Size(1235, 443);
            this.AdminInfoBox1.TabIndex = 5;
            this.AdminInfoBox1.UseCompatibleStateImageBehavior = false;
            // 
            // AdminSearchFacultyButton
            // 
            this.AdminSearchFacultyButton.Location = new System.Drawing.Point(287, 511);
            this.AdminSearchFacultyButton.Name = "AdminSearchFacultyButton";
            this.AdminSearchFacultyButton.Size = new System.Drawing.Size(107, 29);
            this.AdminSearchFacultyButton.TabIndex = 6;
            this.AdminSearchFacultyButton.Text = "Search";
            this.AdminSearchFacultyButton.UseVisualStyleBackColor = true;
            this.AdminSearchFacultyButton.Click += new System.EventHandler(this.AdminSearchFacultyButton_Click);
            // 
            // searchBox
            // 
            this.searchBox.Location = new System.Drawing.Point(31, 511);
            this.searchBox.Name = "searchBox";
            this.searchBox.PlaceholderText = "Enter Faculty First or Last Name";
            this.searchBox.Size = new System.Drawing.Size(234, 27);
            this.searchBox.TabIndex = 7;
            // 
            // AdminViewFaculty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1321, 567);
            this.Controls.Add(this.searchBox);
            this.Controls.Add(this.AdminSearchFacultyButton);
            this.Controls.Add(this.AdminInfoBox1);
            this.Controls.Add(this.AdminErrorLabel1);
            this.Controls.Add(this.AdminViewAllButton);
            this.Controls.Add(this.AdminViewGeneralButton);
            this.Controls.Add(this.AdminBackButton1);
            this.Name = "AdminViewFaculty";
            this.Text = "View Faculty";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Button AdminBackButton1;
        private Button AdminViewGeneralButton;
        private Button AdminViewAllButton;
        private Label AdminErrorLabel1;
        private ListView AdminInfoBox1;
        private Button AdminSearchFacultyButton;
        private TextBox searchBox;
    }
}