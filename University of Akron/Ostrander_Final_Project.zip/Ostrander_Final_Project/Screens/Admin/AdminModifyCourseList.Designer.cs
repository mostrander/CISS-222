﻿namespace Ostrander_Final_Project.Screens
{
    partial class AdminModifyCourseList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CourseListResults = new System.Windows.Forms.ListView();
            this.Dept_DropDownListBox = new System.Windows.Forms.ComboBox();
            this.DepartmentLabel = new System.Windows.Forms.Label();
            this.InstructorLabel = new System.Windows.Forms.Label();
            this.InstructorBox = new System.Windows.Forms.ComboBox();
            this.DescriptionBox = new System.Windows.Forms.TextBox();
            this.DescriptionLabel = new System.Windows.Forms.Label();
            this.CourseNameLabel = new System.Windows.Forms.Label();
            this.CourseNameBox = new System.Windows.Forms.TextBox();
            this.CapacityLabel = new System.Windows.Forms.Label();
            this.CapacityBox = new System.Windows.Forms.TextBox();
            this.SearchButton = new System.Windows.Forms.Button();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.AdminErrorLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioNO = new System.Windows.Forms.RadioButton();
            this.radioYES = new System.Windows.Forms.RadioButton();
            this.ClearButton = new System.Windows.Forms.Button();
            this.DeleteCourseButton = new System.Windows.Forms.Button();
            this.CourseNumberBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SessionNumBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CourseListResults
            // 
            this.CourseListResults.Location = new System.Drawing.Point(12, 12);
            this.CourseListResults.Name = "CourseListResults";
            this.CourseListResults.Size = new System.Drawing.Size(776, 646);
            this.CourseListResults.TabIndex = 0;
            this.CourseListResults.UseCompatibleStateImageBehavior = false;
            // 
            // Dept_DropDownListBox
            // 
            this.Dept_DropDownListBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.Dept_DropDownListBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.Dept_DropDownListBox.FormattingEnabled = true;
            this.Dept_DropDownListBox.Items.AddRange(new object[] {
            " "});
            this.Dept_DropDownListBox.Location = new System.Drawing.Point(933, 210);
            this.Dept_DropDownListBox.Name = "Dept_DropDownListBox";
            this.Dept_DropDownListBox.Size = new System.Drawing.Size(277, 28);
            this.Dept_DropDownListBox.Sorted = true;
            this.Dept_DropDownListBox.TabIndex = 1;
            // 
            // DepartmentLabel
            // 
            this.DepartmentLabel.AutoSize = true;
            this.DepartmentLabel.Location = new System.Drawing.Point(831, 213);
            this.DepartmentLabel.Name = "DepartmentLabel";
            this.DepartmentLabel.Size = new System.Drawing.Size(96, 20);
            this.DepartmentLabel.TabIndex = 2;
            this.DepartmentLabel.Text = "Department: ";
            // 
            // InstructorLabel
            // 
            this.InstructorLabel.AutoSize = true;
            this.InstructorLabel.Location = new System.Drawing.Point(849, 57);
            this.InstructorLabel.Name = "InstructorLabel";
            this.InstructorLabel.Size = new System.Drawing.Size(78, 20);
            this.InstructorLabel.TabIndex = 4;
            this.InstructorLabel.Text = "Instructor: ";
            // 
            // InstructorBox
            // 
            this.InstructorBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.InstructorBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.InstructorBox.FormattingEnabled = true;
            this.InstructorBox.Items.AddRange(new object[] {
            " "});
            this.InstructorBox.Location = new System.Drawing.Point(933, 54);
            this.InstructorBox.Name = "InstructorBox";
            this.InstructorBox.Size = new System.Drawing.Size(277, 28);
            this.InstructorBox.Sorted = true;
            this.InstructorBox.TabIndex = 3;
            // 
            // DescriptionBox
            // 
            this.DescriptionBox.Location = new System.Drawing.Point(933, 99);
            this.DescriptionBox.Multiline = true;
            this.DescriptionBox.Name = "DescriptionBox";
            this.DescriptionBox.PlaceholderText = "Enter a Description";
            this.DescriptionBox.Size = new System.Drawing.Size(277, 94);
            this.DescriptionBox.TabIndex = 5;
            // 
            // DescriptionLabel
            // 
            this.DescriptionLabel.AutoSize = true;
            this.DescriptionLabel.Location = new System.Drawing.Point(835, 102);
            this.DescriptionLabel.Name = "DescriptionLabel";
            this.DescriptionLabel.Size = new System.Drawing.Size(92, 20);
            this.DescriptionLabel.TabIndex = 6;
            this.DescriptionLabel.Text = "Description: ";
            // 
            // CourseNameLabel
            // 
            this.CourseNameLabel.AutoSize = true;
            this.CourseNameLabel.Location = new System.Drawing.Point(822, 15);
            this.CourseNameLabel.Name = "CourseNameLabel";
            this.CourseNameLabel.Size = new System.Drawing.Size(105, 20);
            this.CourseNameLabel.TabIndex = 7;
            this.CourseNameLabel.Text = "Course Name: ";
            // 
            // CourseNameBox
            // 
            this.CourseNameBox.Location = new System.Drawing.Point(933, 12);
            this.CourseNameBox.Name = "CourseNameBox";
            this.CourseNameBox.PlaceholderText = "Enter Course Name";
            this.CourseNameBox.Size = new System.Drawing.Size(277, 27);
            this.CourseNameBox.TabIndex = 8;
            // 
            // CapacityLabel
            // 
            this.CapacityLabel.AutoSize = true;
            this.CapacityLabel.Location = new System.Drawing.Point(822, 341);
            this.CapacityLabel.Name = "CapacityLabel";
            this.CapacityLabel.Size = new System.Drawing.Size(105, 20);
            this.CapacityLabel.TabIndex = 9;
            this.CapacityLabel.Text = "Max Capacity: ";
            // 
            // CapacityBox
            // 
            this.CapacityBox.Location = new System.Drawing.Point(933, 338);
            this.CapacityBox.Name = "CapacityBox";
            this.CapacityBox.PlaceholderText = "Enter a positive number 1-30";
            this.CapacityBox.Size = new System.Drawing.Size(277, 27);
            this.CapacityBox.TabIndex = 10;
            // 
            // SearchButton
            // 
            this.SearchButton.Location = new System.Drawing.Point(888, 452);
            this.SearchButton.Name = "SearchButton";
            this.SearchButton.Size = new System.Drawing.Size(124, 29);
            this.SearchButton.TabIndex = 11;
            this.SearchButton.Text = "Search";
            this.SearchButton.UseVisualStyleBackColor = true;
            this.SearchButton.Click += new System.EventHandler(this.SearchButton_Click);
            // 
            // SubmitButton
            // 
            this.SubmitButton.Location = new System.Drawing.Point(1038, 452);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(124, 29);
            this.SubmitButton.TabIndex = 12;
            this.SubmitButton.Text = "Add Course";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // BackButton
            // 
            this.BackButton.Location = new System.Drawing.Point(961, 535);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(124, 29);
            this.BackButton.TabIndex = 13;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // AdminErrorLabel
            // 
            this.AdminErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.AdminErrorLabel.Location = new System.Drawing.Point(822, 577);
            this.AdminErrorLabel.Name = "AdminErrorLabel";
            this.AdminErrorLabel.Size = new System.Drawing.Size(388, 81);
            this.AdminErrorLabel.TabIndex = 14;
            this.AdminErrorLabel.Text = "Error: ";
            this.AdminErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioNO);
            this.groupBox1.Controls.Add(this.radioYES);
            this.groupBox1.Location = new System.Drawing.Point(888, 382);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(272, 63);
            this.groupBox1.TabIndex = 15;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Only Show Classes With Availability?";
            // 
            // radioNO
            // 
            this.radioNO.AutoSize = true;
            this.radioNO.Location = new System.Drawing.Point(156, 27);
            this.radioNO.Name = "radioNO";
            this.radioNO.Size = new System.Drawing.Size(50, 24);
            this.radioNO.TabIndex = 1;
            this.radioNO.TabStop = true;
            this.radioNO.Text = "No";
            this.radioNO.UseVisualStyleBackColor = true;
            // 
            // radioYES
            // 
            this.radioYES.AutoSize = true;
            this.radioYES.Location = new System.Drawing.Point(79, 27);
            this.radioYES.Name = "radioYES";
            this.radioYES.Size = new System.Drawing.Size(51, 24);
            this.radioYES.TabIndex = 0;
            this.radioYES.TabStop = true;
            this.radioYES.Text = "Yes";
            this.radioYES.UseVisualStyleBackColor = true;
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(888, 493);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(124, 29);
            this.ClearButton.TabIndex = 16;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // DeleteCourseButton
            // 
            this.DeleteCourseButton.Location = new System.Drawing.Point(1038, 493);
            this.DeleteCourseButton.Name = "DeleteCourseButton";
            this.DeleteCourseButton.Size = new System.Drawing.Size(124, 29);
            this.DeleteCourseButton.TabIndex = 17;
            this.DeleteCourseButton.Text = "Remove Course";
            this.DeleteCourseButton.UseVisualStyleBackColor = true;
            this.DeleteCourseButton.Click += new System.EventHandler(this.DeleteCourseButton_Click);
            // 
            // CourseNumberBox
            // 
            this.CourseNumberBox.Location = new System.Drawing.Point(933, 255);
            this.CourseNumberBox.Name = "CourseNumberBox";
            this.CourseNumberBox.PlaceholderText = "Enter a positive number 100-499";
            this.CourseNumberBox.Size = new System.Drawing.Size(277, 27);
            this.CourseNumberBox.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(808, 258);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 20);
            this.label1.TabIndex = 18;
            this.label1.Text = "Course Number: ";
            // 
            // SessionNumBox
            // 
            this.SessionNumBox.Location = new System.Drawing.Point(933, 297);
            this.SessionNumBox.Name = "SessionNumBox";
            this.SessionNumBox.PlaceholderText = "Enter a positive number 100-999";
            this.SessionNumBox.Size = new System.Drawing.Size(277, 27);
            this.SessionNumBox.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(808, 300);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "Course Session: ";
            // 
            // AdminModifyCourseList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1236, 673);
            this.Controls.Add(this.SessionNumBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CourseNumberBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DeleteCourseButton);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.AdminErrorLabel);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.SearchButton);
            this.Controls.Add(this.CapacityBox);
            this.Controls.Add(this.CapacityLabel);
            this.Controls.Add(this.CourseNameBox);
            this.Controls.Add(this.CourseNameLabel);
            this.Controls.Add(this.DescriptionLabel);
            this.Controls.Add(this.DescriptionBox);
            this.Controls.Add(this.InstructorLabel);
            this.Controls.Add(this.InstructorBox);
            this.Controls.Add(this.DepartmentLabel);
            this.Controls.Add(this.Dept_DropDownListBox);
            this.Controls.Add(this.CourseListResults);
            this.Name = "AdminModifyCourseList";
            this.Text = "Courses";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ListView CourseListResults;
        private ComboBox Dept_DropDownListBox;
        private Label DepartmentLabel;
        private Label InstructorLabel;
        private ComboBox InstructorBox;
        private TextBox DescriptionBox;
        private Label DescriptionLabel;
        private Label CourseNameLabel;
        private TextBox CourseNameBox;
        private Label CapacityLabel;
        private TextBox CapacityBox;
        private Button SearchButton;
        private Button SubmitButton;
        private Button BackButton;
        private Label AdminErrorLabel;
        private GroupBox groupBox1;
        private RadioButton radioNO;
        private RadioButton radioYES;
        private Button ClearButton;
        private Button DeleteCourseButton;
        private TextBox CourseNumberBox;
        private Label label1;
        private TextBox SessionNumBox;
        private Label label2;
    }
}