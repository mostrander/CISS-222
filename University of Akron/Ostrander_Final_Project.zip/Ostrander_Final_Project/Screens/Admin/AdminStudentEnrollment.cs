﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens
{
    public partial class AdminStudentEnrollment : Form
    {
        private List<Student> StudentsEnrolled = new List<Student>();
        private Student? individual;
        static public string selectedStudent;

        public AdminStudentEnrollment()
        {
            InitializeComponent();

            //Read account information from file and put into List.
            var fileInput = new FileStream("StudentAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
            string line;

            using (StreamReader fileReader = new StreamReader(fileInput))
            {
                while ((line = fileReader.ReadLine()) != null)
                {
                    //Holds the necessary information pulled from file so information can be entered into accounts
                    string[] words = line.Split(',');

                    if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                    {
                        StudentsEnrolled.Add(new Student(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                        words[4].ToString() ));
                    }
                }

                fileReader.Close();
            }

            fileInput.Close();
            AdminErrorLabel.Text = "";
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            UpdateRecords(); //Update records upon leaving menu
            this.Close();
        }

        private void EnrollSearchButton_Click(object sender, EventArgs e)
        {
            string studentInfo = SearchBox.Text;
            AdminErrorLabel.Text = "";
            SearchStudents(studentInfo);
        }

        private void EnrollButton_Click(object sender, EventArgs e)
        {
            AdminErrorLabel.Text = "";
            AdminErrorLabel.ForeColor = Color.Red;

            if (string.IsNullOrWhiteSpace(FNameBox.Text) || string.IsNullOrWhiteSpace(LNameBox.Text) ||
                string.IsNullOrWhiteSpace(DOB_Box.Text) || string.IsNullOrWhiteSpace(Email_Box.Text))
            {
                AdminErrorLabel.Text = "Error: All fields except the Student ID must be entered.";
            }
            else
            {
                //Find anyone with matching Email address -
                //It is not likely any two people will have the exact same email address (spelling and domain)
                //Not doing a name match here because there are cases of individuals have same names (i.e. Todd Weber & Brian Weber). 
                IEnumerable<Student>? resultsFound =
                    from students in StudentsEnrolled
                    where (students.GetEmail() == Email_Box.Text)
                    select students;

                if (resultsFound.Any())
                {
                    AdminErrorLabel.Text = "A student with the matching email and DoB already exists." +
                        "The student is: " + resultsFound.First().GetName();
                }
                else
                {
                    //Need to add entry validation
                    string fname = FNameBox.Text;
                    string lName = LNameBox.Text;
                    string dob = DOB_Box.Text;
                    string email = Email_Box.Text;

                    Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
                    Match match = regex.Match(email);

                    if (match.Success)
                    {
                        Random random = new Random();
                        string id = "S" + random.Next(999).ToString();
                        bool duplicate = true;

                        while(duplicate == true)
                        {
                            resultsFound =
                            from students in StudentsEnrolled
                            where (students.GetStudentID() == id)
                            select students;

                            //if resultsFound returns nothing, then can use ID.
                            if (!resultsFound.Any())
                            {
                                duplicate = false;
                            }
                            else
                            {
                                //reroll ID for student. Need unique value.
                                id = "S" + random.Next(999).ToString();
                            }
                        }

                        //Add individual to list of enrolled students
                        individual = new Student(fname, lName, dob, email, id);
                        StudentsEnrolled.Add(individual);

                        /*UpdateRecords();*/ //Update file containing students records

                        //Alert user of success
                        AdminErrorLabel.Text = "Student is now enrolled.";
                        AdminErrorLabel.ForeColor = Color.Green;

                        StudentID_Box.Text = id; //Display ID information
                    }
                    else
                    {
                        AdminErrorLabel.Text = "Error: Email entered is not in the standard format of an email. " +
                            "Please verify that the email is entered correctly.";
                    }

                   
                }
            }
        }

        private void RemoveStudentButton_Click(object sender, EventArgs e)
        {
            try
            {
                AdminErrorLabel.ForeColor = Color.Red;
                AdminErrorLabel.Text = "";

                if (string.IsNullOrWhiteSpace(StudentID_Box.Text))
                {
                    AdminErrorLabel.Text = "Error: Student information has not been verified. Please search student by name or ID before proceeding.";
                }
                else
                {
                    var confirmResult = MessageBox.Show("Are you sure you want to delete this account?",
                                             "Confirm Delete.",
                                             MessageBoxButtons.YesNo);
                    if (confirmResult == DialogResult.Yes)
                    {
                        IEnumerable<Student> individual =
                            from student in StudentsEnrolled
                            where student.GetStudentID().Equals(StudentID_Box.Text)
                            select student;

                        if (!individual.Any())
                        {
                            AdminErrorLabel.Text = "Error: An unexpected error has occurred. Please verify with a search that the student record exists.";
                        }
                        else
                        {
                            StudentsEnrolled.Remove(individual.First());
                            AdminErrorLabel.Text = "Success. Student has been removed.";
                            AdminErrorLabel.ForeColor= Color.Green;
                        }
                    }
                    else
                    {
                        AdminErrorLabel.Text = "Process Aborted.";
                    }
                }
            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error has occurred.";
            }

            
        }


        private void SearchStudents(string id)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(id))
                {
                    //Obtain list of all current students
                    IEnumerable<Student>? results =
                        from student in StudentsEnrolled
                        where student.GetStudentID() == id || student.GetName().Contains(id, StringComparison.OrdinalIgnoreCase)
                        select student;

                    if (results.Any())
                    {
                        if(results.Count() > 1)
                        {
                            string statement = "Too many results for the name entered. Here are the results:\n";
                            
                            foreach(Student student in results)
                            {
                                statement += $"{student.GetStudentID()} {student.GetName()}\n";
                            }
                            statement += "Please enter a more specific search.";
                            var multiResults = MessageBox.Show(statement);
                        }
                        else
                        {
                            FNameBox.Text = results.First().GetFName();
                            LNameBox.Text = results.First().GetLName();
                            DOB_Box.Text = results.First().GetDoB();
                            Email_Box.Text = results.First().GetEmail();
                            StudentID_Box.Text = results.First().GetStudentID();
                        }
                    }
                    else
                    {
                        AdminErrorLabel.Text = "Error: No results found.";
                    }

                }
                else
                {
                    AdminErrorLabel.Text = "Error: Nothing was entered in the search field.";
                }
            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error has occurred.";
            }
        }



        private void UpdateRecords()
        {
            //Saves all account information to a file so it can be used next time program is launched
            var fileOutput = new FileStream("StudentAccounts.txt", FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter fileWriter = new StreamWriter(fileOutput);

            //StreamWriter fileWriter = new StreamWriter("FacultyAccounts.txt"); //Works

            var sorted = from accounts in StudentsEnrolled
                         orderby accounts.GetStudentID() ascending
                         select accounts;

            //Print each account to the file. NOTE: Stores files in bin folder
            foreach (var individual in sorted)
            {
                fileWriter.WriteLine(individual.PrintToFile());
            }

            fileWriter.Close();
        }

        private void ClassesButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(StudentID_Box.Text))
            {
                AdminErrorLabel.Text = "Error: Student ID was not selected. Please search for student information and try again.";
            }
            else
            {
                selectedStudent = StudentID_Box.Text; //store student ID number
                UpdateRecords(); //updates records should student be newly added and going straight to adding them to courses

                this.Hide();
                AdminStudentClassEnrollment studentEnrolledCourses = new AdminStudentClassEnrollment();
                studentEnrolledCourses.ShowDialog();

                this.Show();
            }
        }
    }
}
