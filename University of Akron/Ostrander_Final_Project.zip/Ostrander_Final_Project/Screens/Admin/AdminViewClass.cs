﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens
{
    public partial class AdminViewClass : Form
    {
        private List<Faculty> staff = new List<Faculty>(); //Holds the data for the faculty list
        private List<Courses> currentCourses = new List<Courses>();
        ListViewItem[] listResults;//creates array to pass to AddRange() later
        ListViewItem item;//Will be used for creating each item individually

        public AdminViewClass()
        {
            InitializeComponent();

            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }
                
                //Read in the entire courses offered list
                fileInput = new FileStream("ClassList.txt", FileMode.OpenOrCreate, FileAccess.Read);
                
                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            currentCourses.Add(new Courses(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                            words[4].ToString(), words[5].ToString(), words[6].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();

                //Add the courses for the teachers accordingly, based on matching instructor ID, which SHOULD be unique
                foreach (Faculty faculty in staff)
                {
                    if (faculty.HasCourseList() == true)
                    {
                        foreach (Courses course in currentCourses)
                        {
                            if (course.GetTeacherID().Contains(faculty.GetID(),StringComparison.OrdinalIgnoreCase))
                            {
                                faculty.AddCourse(course);
                            }
                        }
                    }
                }

            }
            catch
            {
                AdminErrorLabel.Text =  "Error: An unexpected error occurred while loading data.";
            }
        }

        private void AdminSearchButton_Click(object sender, EventArgs e)
        {
            //Test to see if I can even get the listview to work right.
            //Example: https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.listviewitem.subitems?view=windowsdesktop-6.0
            //WORKED!!!

            /* 
            Notes regarding ListView Control:
            1) You need an extra column than you actually intend to use because when you create the listviewitem initially,
                it will want a string value. That value will be placed in the first column.
            2) Do NOT attempt to create list view items from objects (i.e. Faculty class objects). It seems to show the name properly,
                but it just creates a mess. Try to pass the string values instead. 
            3) You CAN create an array of Listviewitems and pass it to the AddRange method for the listview control!
            4) That said, you need a way to determine the size of results and set that length for the array in advance.
             */

            try
            {
                string instructor = InstructorSearchBox.Text;

                if (string.IsNullOrWhiteSpace(instructor))
                {
                    //Display all instructors by default if nothing is entered
                    IOrderedEnumerable<Faculty>? instructorSearch =
                        from faculty in staff
                        where !faculty.GetDepartment().Contains("TSS",StringComparison.OrdinalIgnoreCase)
                        orderby faculty.GetLName() descending
                        select faculty;

                    DisplayResults(instructorSearch);
                }
                else
                {
                    IOrderedEnumerable<Faculty>? instructorSearch =
                        from faculty in staff
                        where faculty.GetName().Contains(instructor, StringComparison.OrdinalIgnoreCase) ||
                              faculty.GetID().Contains(instructor, StringComparison.OrdinalIgnoreCase)
                        orderby faculty.GetLName() descending
                        select faculty;

                    DisplayResults(instructorSearch);
                }
            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error has occurred.";
            }
        }

        private void AdminBackButton_Click(object sender, EventArgs e)
        {
            this.Close(); //Close this form and return to previous form (AdminMenu1)
        }

        private void ViewAllButton_Click(object sender, EventArgs e)
        {
            //Similar to the Search button functionality, except it returns EVERYONE that currently teaches.

            //Locate all faculty members who currently has assigned courses
            IOrderedEnumerable<Faculty>? instructorSearch =
                from faculty in staff
                where faculty.HasCourseList() == true
                orderby faculty.GetLName() descending
                select faculty;

            DisplayResults(instructorSearch);
        } 

        private void DisplayResults(IOrderedEnumerable<Faculty>? results)
        {
            //Similar to the Search button functionality, except it returns EVERYONE that teaches.
            //Employees who teach will start will have an idea that starts with T?
            //At least in my program they do. Probably will not work that way in the real world

            //Clear items and columns so duplicates do not appear
            InstructorList.Items.Clear();
            InstructorList.Columns.Clear();

            //Clear the error label & search box
            AdminErrorLabel.Text = "";

            //List Columns for making viewing easier; -2 is for autosizing
            InstructorList.Columns.Add("Last, First Name", 250, HorizontalAlignment.Center);
            InstructorList.Columns.Add("ID", 70, HorizontalAlignment.Center);
            InstructorList.Columns.Add("Department", 150, HorizontalAlignment.Center);
            InstructorList.Columns.Add("Courses", 100, HorizontalAlignment.Center);

            //Show details of the items and allow columns to be reordered
            InstructorList.View = View.Details;
            InstructorList.AllowColumnReorder = true;
            InstructorList.GridLines = true;
            InstructorList.FullRowSelect = true; //Allows rows to be selected
            InstructorList.AllowDrop = false; //Do not accept anything dragged and dropped onto the control
            InstructorList.Sort();

            try
            {
                if (results.Any())
                {
                    int size = results.Count(); //Number of results found
                    int count = 0; //Log current entry for inserting into array

                    listResults = new ListViewItem[size]; 

                    foreach (var member in results)
                    {
                        item = new ListViewItem(member.PrintName(), 0);
                        item.SubItems.Add(member.GetID());
                        item.SubItems.Add(member.GetDepartment());
                        item.SubItems.Add(member.NumberOfCourses().ToString());
                        listResults[count] = item;
                        count++;
                    }

                    InstructorList.Items.AddRange(listResults); //Output to the ListItem box control

                }
                else
                {
                    AdminErrorLabel.Text = "Error: No results found.";
                    return;
                }
            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error has occurred while displaying results.";
            }
        }

        private void ShowInstructorClassesButton_Click(object sender, EventArgs e)
        {
            string instructor = InstructorSearchBox.Text;

            try
            {
                if (string.IsNullOrWhiteSpace(instructor))
                {
                    AdminErrorLabel.Text = "Error: Unable to complete search. Nothing was entered in the search box.";
                }
                else
                {
                    ResetColumnDisplayCourses();

                    IOrderedEnumerable<Faculty>? instructorSearch =
                        from faculty in staff
                        where faculty.GetName().Contains(instructor, StringComparison.OrdinalIgnoreCase)
                        orderby faculty.GetLName() descending
                        select faculty;

                    int count = instructorSearch.First().NumberOfCourses(); //holds number of courses
                    int added = 0;
                    List<Courses> userCourseList = instructorSearch.First().GetCourses();
                    listResults = new ListViewItem[count];

                    if (userCourseList != null && userCourseList.Any())
                    {
                         foreach (var course in userCourseList)
                         {
                            item = new ListViewItem(instructorSearch.First().GetID(), 0); //Instructor ID
                            item.SubItems.Add(course.GetDeptCode()); //Course ID
                            item.SubItems.Add(course.GetName()); //Course Name
                            item.SubItems.Add(course.GetCurrentCapacity()); //Students enrolled
                            item.SubItems.Add(course.GetMaxCapacity()); //Capacity

                            listResults[added] = item;
                            added++;
                        }

                         InstructorList.Items.AddRange(listResults); //Output to the ListItem box control
                    }
                    else
                    {
                         AdminErrorLabel.Text = "Error: Instructor does not appear to be teaching any courses currently.";
                    }
                    
                }//End of if/else statement

            }
            catch
            {
                AdminErrorLabel.Text = "Error: Unexpected error has occurred.";
            }
        }

        private void AllCoursesButton_Click(object sender, EventArgs e)
        {
            try
            {

                if(currentCourses == null || !currentCourses.Any())
                {
                    AdminErrorLabel.Text = "It does not appear there are any courses offered currently.";
                }
                else
                {
                    ResetColumnDisplayCourses();
                    int count = currentCourses.Count();
                    int added = 0;
                    listResults = new ListViewItem[count];

                    foreach (var course in currentCourses)
                    {
                        item = new ListViewItem(course.GetTeacherID(), 0); //Instructor ID
                        item.SubItems.Add(course.GetDeptCode()); //Course ID
                        item.SubItems.Add(course.GetName()); //Course Name
                        item.SubItems.Add(course.GetCurrentCapacity()); //Students enrolled
                        item.SubItems.Add(course.GetMaxCapacity()); //Capacity

                        listResults[added] = item; //currently outside of array bounds?
                        added++;
                    }

                    InstructorList.Items.AddRange(listResults); //Output to the ListItem box control
                }
            }
            catch
            {
                AdminErrorLabel.Text = "Error: Unexpected error has occurred.";
            }
        }

        private void ResetColumnDisplayCourses()
        {

            //Clear items and columns so duplicates do not appear
            InstructorList.Items.Clear();
            InstructorList.Columns.Clear();

            //Clear the error label & search box
            AdminErrorLabel.Text = "";

            //Add the columns
            InstructorList.Columns.Add("Instructor ID", 150, HorizontalAlignment.Center);
            InstructorList.Columns.Add("Course ID", 100, HorizontalAlignment.Center);
            InstructorList.Columns.Add("Course Name", 250, HorizontalAlignment.Center);
            InstructorList.Columns.Add("Students", 100, HorizontalAlignment.Center);
            InstructorList.Columns.Add("Capacity", 100, HorizontalAlignment.Center);

            //Show details of the items and allow columns to be reordered
            InstructorList.View = View.Details;
            InstructorList.AllowColumnReorder = true;
            InstructorList.GridLines = true;
            InstructorList.FullRowSelect = true; //Allows rows to be selected
            InstructorList.AllowDrop = false; //Do not accept anything dragged and dropped onto the control
            InstructorList.Sort();
        }
    }


}
