﻿namespace Ostrander_Final_Project.Screens
{
    partial class AdminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AdminMenuLabel1 = new System.Windows.Forms.Label();
            this.AdminExitButton1 = new System.Windows.Forms.Button();
            this.AdminViewFacultyButton1 = new System.Windows.Forms.Button();
            this.AdminClassInfoButton1 = new System.Windows.Forms.Button();
            this.AdminChangeFacultyButton1 = new System.Windows.Forms.Button();
            this.EnrollmentButton = new System.Windows.Forms.Button();
            this.ChangePasswordButton = new System.Windows.Forms.Button();
            this.ModifyCoursesButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AdminMenuLabel1
            // 
            this.AdminMenuLabel1.Font = new System.Drawing.Font("Segoe UI", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AdminMenuLabel1.Location = new System.Drawing.Point(12, 19);
            this.AdminMenuLabel1.Name = "AdminMenuLabel1";
            this.AdminMenuLabel1.Size = new System.Drawing.Size(775, 62);
            this.AdminMenuLabel1.TabIndex = 1;
            this.AdminMenuLabel1.Text = "Welcome";
            this.AdminMenuLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AdminExitButton1
            // 
            this.AdminExitButton1.Location = new System.Drawing.Point(275, 413);
            this.AdminExitButton1.Name = "AdminExitButton1";
            this.AdminExitButton1.Size = new System.Drawing.Size(223, 29);
            this.AdminExitButton1.TabIndex = 2;
            this.AdminExitButton1.Text = "Log Off";
            this.AdminExitButton1.UseVisualStyleBackColor = true;
            this.AdminExitButton1.Click += new System.EventHandler(this.AdminExitButton1_Click);
            // 
            // AdminViewFacultyButton1
            // 
            this.AdminViewFacultyButton1.Location = new System.Drawing.Point(275, 153);
            this.AdminViewFacultyButton1.Name = "AdminViewFacultyButton1";
            this.AdminViewFacultyButton1.Size = new System.Drawing.Size(223, 29);
            this.AdminViewFacultyButton1.TabIndex = 3;
            this.AdminViewFacultyButton1.Text = "View Faculty Information";
            this.AdminViewFacultyButton1.UseVisualStyleBackColor = true;
            this.AdminViewFacultyButton1.Click += new System.EventHandler(this.AdminViewFacultyButton1_Click);
            // 
            // AdminClassInfoButton1
            // 
            this.AdminClassInfoButton1.Location = new System.Drawing.Point(275, 243);
            this.AdminClassInfoButton1.Name = "AdminClassInfoButton1";
            this.AdminClassInfoButton1.Size = new System.Drawing.Size(223, 29);
            this.AdminClassInfoButton1.TabIndex = 4;
            this.AdminClassInfoButton1.Text = "View Class Information";
            this.AdminClassInfoButton1.UseVisualStyleBackColor = true;
            this.AdminClassInfoButton1.Click += new System.EventHandler(this.AdminClassInfoButton1_Click);
            // 
            // AdminChangeFacultyButton1
            // 
            this.AdminChangeFacultyButton1.Location = new System.Drawing.Point(275, 198);
            this.AdminChangeFacultyButton1.Name = "AdminChangeFacultyButton1";
            this.AdminChangeFacultyButton1.Size = new System.Drawing.Size(223, 29);
            this.AdminChangeFacultyButton1.TabIndex = 5;
            this.AdminChangeFacultyButton1.Text = "Change Faculty Information";
            this.AdminChangeFacultyButton1.UseVisualStyleBackColor = true;
            this.AdminChangeFacultyButton1.Click += new System.EventHandler(this.AdminChangeFacultyButton1_Click);
            // 
            // EnrollmentButton
            // 
            this.EnrollmentButton.Location = new System.Drawing.Point(275, 329);
            this.EnrollmentButton.Name = "EnrollmentButton";
            this.EnrollmentButton.Size = new System.Drawing.Size(223, 29);
            this.EnrollmentButton.TabIndex = 6;
            this.EnrollmentButton.Text = "Student Enrollment";
            this.EnrollmentButton.UseVisualStyleBackColor = true;
            this.EnrollmentButton.Click += new System.EventHandler(this.EnrollmentButton_Click);
            // 
            // ChangePasswordButton
            // 
            this.ChangePasswordButton.Location = new System.Drawing.Point(275, 371);
            this.ChangePasswordButton.Name = "ChangePasswordButton";
            this.ChangePasswordButton.Size = new System.Drawing.Size(223, 29);
            this.ChangePasswordButton.TabIndex = 7;
            this.ChangePasswordButton.Text = "Change Password";
            this.ChangePasswordButton.UseVisualStyleBackColor = true;
            this.ChangePasswordButton.Click += new System.EventHandler(this.ChangePasswordButton_Click);
            // 
            // ModifyCoursesButton
            // 
            this.ModifyCoursesButton.Location = new System.Drawing.Point(275, 287);
            this.ModifyCoursesButton.Name = "ModifyCoursesButton";
            this.ModifyCoursesButton.Size = new System.Drawing.Size(223, 29);
            this.ModifyCoursesButton.TabIndex = 8;
            this.ModifyCoursesButton.Text = "Modify Course Offering";
            this.ModifyCoursesButton.UseVisualStyleBackColor = true;
            this.ModifyCoursesButton.Click += new System.EventHandler(this.ModifyCoursesButton_Click);
            // 
            // AdminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(799, 459);
            this.Controls.Add(this.ModifyCoursesButton);
            this.Controls.Add(this.ChangePasswordButton);
            this.Controls.Add(this.EnrollmentButton);
            this.Controls.Add(this.AdminChangeFacultyButton1);
            this.Controls.Add(this.AdminClassInfoButton1);
            this.Controls.Add(this.AdminViewFacultyButton1);
            this.Controls.Add(this.AdminExitButton1);
            this.Controls.Add(this.AdminMenuLabel1);
            this.Name = "AdminMenu";
            this.Text = "Main Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private Label AdminMenuLabel1;
        private Button AdminExitButton1;
        private Button AdminViewFacultyButton1;
        private Button AdminClassInfoButton1;
        private Button AdminChangeFacultyButton1;
        private Button EnrollmentButton;
        private Button ChangePasswordButton;
        private Button ModifyCoursesButton;
    }
}