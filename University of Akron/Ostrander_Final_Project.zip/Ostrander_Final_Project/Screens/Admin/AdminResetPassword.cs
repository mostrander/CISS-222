﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

//Similar to the userChangePassword Form, modified so Admins can reset other users' passwords

namespace Ostrander_Final_Project.Screens
{
    public partial class AdminResetPassword : Form
    {
        private List<Faculty> staff = new List<Faculty>();
        private string currentUser = LoginScreen.userAccountID; //Stores logged in user's employee id info from login screen form
        private string selectedUser = AdminEditFaculty.selectedUserID;

        IEnumerable<Faculty> account;

        public AdminResetPassword()
        {
            InitializeComponent();

            try
            {
                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using(StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();
            }
            catch
            {

            }

            account =
                from faculty in staff
                where faculty.GetID().Equals(selectedUser)
                select faculty;

            NameLabel.Text = $"{account.First().GetName()}";
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            //Just basic setup for now. Will deal with validation once basic is running

            //Reset error label message and field label colors.
            ErrorLabel.Text = "";
            Label_NewPassword1.ForeColor = Color.Black;
            Label_NewPassword2.ForeColor = Color.Black;

            //Obtain user entries from form
            string newPass = New_Password_Box1.Text;
            string newPass2 = New_Password_Box2.Text;

            //verify that text is not empty or null
            try
            {
                //If any of the following fields are empty, thrown an error message
                if (string.IsNullOrWhiteSpace(newPass))
                {
                    ErrorLabel.Text = "Error: Entry for new password was not entered.";
                    Label_NewPassword1.ForeColor = Color.Red;
                }
                else if (string.IsNullOrWhiteSpace(newPass2))
                {
                    ErrorLabel.Text = "Error: Entry for re-entering new password was not entered.";
                    Label_NewPassword2.ForeColor = Color.Red;
                }
                else if (newPass.Length < 15)
                {
                    ErrorLabel.Text = "Error: New password is too short. Password must be a minimum of 15 characters.";
                    Label_NewPassword1.ForeColor = Color.Red;
                }
                //If both new password entries do not match, throw an error message
                else if (newPass != newPass2)
                {
                    ErrorLabel.Text = "Error: Entries for new password do not match.";
                    Label_NewPassword1.ForeColor = Color.Red;
                    Label_NewPassword2.ForeColor = Color.Red;
                }
                else
                {
                    bool reqMet = PasswordVerified(newPass);

                    if (reqMet == true)
                    {
                        //Update account password.
                        account.First().UpdatePassword(newPass2);

                        //Export information to file to update data when imported next
                        UpdateRecords();

                        //Clear entry boxes for next submission (if needed)
                        New_Password_Box1.Text = "";
                        New_Password_Box2.Text = "";

                        //Verify to user process has completed. 
                        ErrorLabel.Text = "Password Changed.";
                        ErrorLabel.ForeColor = Color.Green;
                    }
                    else
                    {
                        ErrorLabel.Text = "Error: Password does not meet requirements. Must have the following " +
                            "characters: a lowercase letter, an uppercase letter, a number, and a special character. ";
                        Label_NewPassword1.ForeColor = Color.Red;
                    }
                }
            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred.";
            }

        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Close(); //return to previous menu
        }

        private void UpdateRecords()
        {
            //Saves all account information to a file so it can be used next time program is launched
            //var fileOutput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Write);
            //StreamWriter fileWriter = new StreamWriter(fileOutput);
            //C:\\Users\\ostra\\Desktop\\C# repos 2022\\Ostrander_Final_Project\\DB Files\\

            using (StreamWriter fileWriter = new StreamWriter("FacultyAccounts.txt", false))
            {
                var sorted = from accounts in staff
                             orderby accounts.GetID() ascending
                             select accounts;

                //Print each account to the file. NOTE: Stores files in bin folder
                foreach (var individual in sorted)
                {
                    fileWriter.WriteLine(individual.PrintToFile());
                }

                fileWriter.Close();
            }
        }


        private bool PasswordVerified(string pass)
        {
            //Verifies that password entered contains 1 lowercase and 1 uppercase letter, a number, and a special character
            const string pattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^a-zA-Z0-9 :])(?=.{15,})";

            var match = Regex.Match(pass, pattern);

            return match.Success;
        }
    }
}
