﻿using Ostrander_Final_Project.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Final_Project.Screens
{
    public partial class AdminModifyCourseList : Form
    {
        private List<Faculty> staff = new List<Faculty>(); //Holds the data for the faculty list
        private List<Courses> currentCourses = new List<Courses>();
        ListViewItem[] listResults;//creates array to pass to AddRange() later
        ListViewItem item;//Will be used for creating each item individually

        //These lists will be used for populating the drop down menus automatically
        private List<string> departmentSelection = new List<string>(); //Holds department information
        private List<string> facultySelection = new List<string>(); //Holds faculty information

        public AdminModifyCourseList()
        {
            InitializeComponent();

            try
            {
                //Reset error label information
                AdminErrorLabel.Text = "";
                AdminErrorLabel.ForeColor = Color.Red;

                //Read account information from file and put into List.
                var fileInput = new FileStream("FacultyAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            staff.Add(new Faculty(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                                words[4].ToString(), words[5].ToString(), words[6].ToString(), words[7].ToString(), words[8].ToString(),
                                words[9].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                //Read in the entire courses offered list
                fileInput = new FileStream("ClassList.txt", FileMode.OpenOrCreate, FileAccess.Read);

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            currentCourses.Add(new Courses(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                            words[4].ToString(), words[5].ToString(), words[6].ToString()));
                        }
                    }

                    fileReader.Close();
                }

                //Import list of Departments
                fileInput = new FileStream("DepartmentList.txt", FileMode.OpenOrCreate, FileAccess.Read);
                using(StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        if (!string.IsNullOrWhiteSpace(line)) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            //Should not include TSS department
                            if(line.Contains("TSS", StringComparison.OrdinalIgnoreCase))
                            {
                                //ignore
                            }
                            else
                            {
                                departmentSelection.Add(line);
                            }

                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close(); //Close the fileWriter command 


                //Add the courses for the teachers accordingly, based on matching instructor ID, which SHOULD be unique
                foreach (Faculty faculty in staff)
                {
                    //Should not include anyone in the TSS department
                    if(faculty.GetDepartment().Contains("TSS", StringComparison.OrdinalIgnoreCase))
                    {
                        //Ignore
                    }
                    else
                    {
                        //Add names to the facultySelection list to use with dropdown menu later
                        facultySelection.Add($"{faculty.GetID()} {faculty.GetName()}");

                        if (faculty.HasCourseList() == true)
                        {
                            foreach (Courses course in currentCourses)
                            {
                                if (course.GetTeacherID().Contains(faculty.GetID(),StringComparison.OrdinalIgnoreCase))
                                {
                                    faculty.AddCourse(course);
                                }
                            }
                        }
                    }

                }

                //Load lists into the dropdown boxes
                foreach(string item in departmentSelection)
                {
                    Dept_DropDownListBox.Items.Add(item);
                }

                foreach(string item in facultySelection)
                {
                    InstructorBox.Items.Add(item); 
                }

                AdminErrorLabel.Text = "";
                radioNO.Checked = true;

            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error occurred while loading data.";
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SearchButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Reset error label information (In case user successfully adds a course and then chooses to search for courses
                AdminErrorLabel.Text = "";
                AdminErrorLabel.ForeColor = Color.Red;

                string search = ""; //Will hold search statement depending on what the user selects in boxes
                IEnumerable<Courses> resultsFound = new List<Courses>(); //Holds the ultimate search results

                string deptCodeSearch = ""; //Holds dept code information from the drop down list

                if (!string.IsNullOrWhiteSpace(CourseNameBox.Text))
                {
                    resultsFound =
                    from course in currentCourses
                    where course.GetName().Contains(CourseNameBox.Text, StringComparison.OrdinalIgnoreCase)
                    select course;
                }
                else if (!string.IsNullOrWhiteSpace(InstructorBox.Text))
                {
                    resultsFound =
                    from course in currentCourses
                    where InstructorBox.Text.Contains(course.GetTeacherID(), StringComparison.OrdinalIgnoreCase)
                    select course;
                }
                else if (!string.IsNullOrWhiteSpace(DescriptionBox.Text))
                {
                    resultsFound =
                    from course in currentCourses
                    where course.GetDescription().Contains(DescriptionBox.Text, StringComparison.OrdinalIgnoreCase)
                    select course;
                }
                else if (!string.IsNullOrWhiteSpace(Dept_DropDownListBox.Text))
                {
                    deptCodeSearch = "";

                    //Determine which department the search needs to look for
                    //Note: Course DeptCode only contains the shortened acroynm
                    switch (Dept_DropDownListBox.Text)
                    {
                        case "MAT - Mathematics":
                            deptCodeSearch = "MAT";
                            break;
                        case "SCI - Science":
                            deptCodeSearch = "SCI";
                            break;
                        case "HIS - History":
                            deptCodeSearch = "HIS";
                            break;
                        case "ENG - English":
                            deptCodeSearch = "ENG";
                            break;
                        case "PSY - Psychology":
                            deptCodeSearch = "PSY";
                            break;
                        case "SOC - Sociology":
                            deptCodeSearch = "SOC";
                            break;
                        case "LAN - Language":
                            deptCodeSearch = "LAN";
                            break;
                        default:
                            break;
                    }

                    resultsFound =
                    from course in currentCourses
                    where course.GetDeptCode().Contains(deptCodeSearch, StringComparison.OrdinalIgnoreCase)
                    select course;

                }
                else if (!string.IsNullOrWhiteSpace(CourseNumberBox.Text))
                {
                    resultsFound =
                    from course in currentCourses
                    where course.GetDeptCode().Contains(CourseNumberBox.Text, StringComparison.OrdinalIgnoreCase)
                    select course;
                }
                else if (!string.IsNullOrWhiteSpace(SessionNumBox.Text))
                {
                    resultsFound =
                    from course in currentCourses
                    where course.GetDeptCode().Contains(SessionNumBox.Text, StringComparison.OrdinalIgnoreCase)
                    select course;
                }
                else if (radioYES.Checked)
                {
                    resultsFound =
                    from course in currentCourses
                    where int.Parse(course.GetCurrentCapacity()) < int.Parse(course.GetMaxCapacity())
                    select course;
                }

                //Analyze all the lists created for each search and determine what matches based on DeptCode
                //Sorta Works... Looks like it will take one criteria at a time basically...
                //Name search and description search works, but some reason teacher search opens it up MORE...

                //If nothing is entered for search, then show entire list of courses available
                else if (string.IsNullOrWhiteSpace(CourseNameBox.Text) && string.IsNullOrWhiteSpace(InstructorBox.Text) &&
                    string.IsNullOrWhiteSpace(DescriptionBox.Text) && string.IsNullOrWhiteSpace(Dept_DropDownListBox.Text)
                    && string.IsNullOrWhiteSpace(CourseNumberBox.Text) && string.IsNullOrWhiteSpace(SessionNumBox.Text)
                    && radioNO.Checked)
                {
                    resultsFound =
                        from course in currentCourses
                        orderby course.GetDeptCode()
                        select course;
                }

                DisplayResults(resultsFound);

                //End of if/else statements

            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error occurred while searching.";
            }
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Reset error label information
                AdminErrorLabel.Text = "";
                AdminErrorLabel.ForeColor = Color.Red;

                bool verify = true; //Assumes entries are valid by default.

                //Make sure all fields are entered first & valid
                if(string.IsNullOrWhiteSpace(CourseNameBox.Text))
                {
                    AdminErrorLabel.Text = "Error: You must enter a Course Name for the new class.";
                    verify = false;
                }
                else if (string.IsNullOrWhiteSpace(InstructorBox.Text))
                {
                    AdminErrorLabel.Text = "Error: You must select an instructor to assign the course to.";
                    verify = false;
                }
                else if (string.IsNullOrWhiteSpace(DescriptionBox.Text))
                {
                    AdminErrorLabel.Text = "Error: You must enter a description for the course.";
                    verify = false;
                }
                else if (string.IsNullOrWhiteSpace(Dept_DropDownListBox.Text))
                {
                    AdminErrorLabel.Text = "Error: You must select a department to assign the course to.";
                    verify = false;
                }
                else if (string.IsNullOrWhiteSpace(CapacityBox.Text))
                {
                    AdminErrorLabel.Text = "Error: You must enter the max capacity of the course allowed.";
                    verify = false;
                }
                else if (string.IsNullOrWhiteSpace(CourseNumberBox.Text))
                {
                    AdminErrorLabel.Text = "Error: A course number must be entered so the course may be created properly. " +
                        "For example: 101.";
                    verify = false;
                }

                int cap = 0;
                int courseNum = 0;

                //Make sure that the fields contain proper information data entry
                //If the Course Name or Description fields contain special characters outside of space, then error.
                if( !CourseNameBox.Text.All(c => Char.IsLetterOrDigit(c) || c == ' ') || 
                    !DescriptionBox.Text.All(c => Char.IsLetterOrDigit(c) || c == ' '))
                {
                    verify = false;
                    AdminErrorLabel.Text = "Error: Course name and description can only contain letters, numbers, and spaces. " +
                        "For example: History 101.";
                }
                //If Capacity and Course Number box is filled out, verify entries
                else if(!string.IsNullOrWhiteSpace(CapacityBox.Text) && !string.IsNullOrWhiteSpace(CourseNumberBox.Text))
                {
                    cap = int.Parse(CapacityBox.Text);
                    courseNum = int.Parse(CourseNumberBox.Text);

                    if (!CapacityBox.Text.All(Char.IsDigit) || cap <= 0 || cap > 30)
                    {
                        AdminErrorLabel.Text = "Error: Capacity must be entered using ONLY digits 1 - 30.";
                        verify = false;
                    }
                    else if(!CourseNumberBox.Text.All(Char.IsDigit) || courseNum < 100 || courseNum >= 500)
                    {
                        AdminErrorLabel.Text = "Error: Course number must be entered using ONLY digits 100 - 499.";
                        verify = false;
                    }

                }

                if(verify == true)
                {
                    //Determine a Department Code for the course (need to determine actual course level too.
                    string departmentCode = "";

                    switch (Dept_DropDownListBox.Text)
                    {
                        case "MAT - Mathematics":
                            departmentCode += "MAT ";
                            break;
                        case "SCI - Science":
                            departmentCode += "SCI ";
                            break;
                        case "HIS - History":
                            departmentCode += "HIS ";
                            break;
                        case "ENG - English":
                            departmentCode += "ENG ";
                            break;
                        case "MUS - Music":
                            departmentCode += "MUS ";
                            break;
                        case "PSY - Psychology":
                            departmentCode += "PSY ";
                            break;
                        case "SOC - Sociology":
                            departmentCode += "SOC ";
                            break;
                        case "LAN - Language":
                            departmentCode += "LAN ";
                            break;
                        default:
                            break;
                    }

                    //Add the course number entered by user. 
                    departmentCode += courseNum.ToString() + ":";

                    //Use random generator to obtain a number session ID (helps differentiate between courses of same dept & number)
                    Random random = new Random();
                    int sessionID = 0; //temp value just to initialize variable.
                    bool matchFound = true;

                    //Otherwise, regenerate a new course session ID until a unique number is given.
                    while (matchFound == true)
                    {
                        sessionID = random.Next(100, 999);

                        IEnumerable<Courses> findMatchingCourseID =
                            from course in currentCourses
                            where course.GetDeptCode() == (departmentCode + sessionID)
                            select course;

                        //If list generated does not contain anything (or is null), then proceed with creating course
                        if (!findMatchingCourseID.Any())
                        {
                            matchFound = false;
                            departmentCode += sessionID.ToString();
                        }
                    }

                    IEnumerable<Faculty> instructorFound =
                        from faculty in staff
                        where InstructorBox.Text.Contains(faculty.GetID(), StringComparison.OrdinalIgnoreCase)
                        select faculty;

                    //Grab instructor's ID number
                    string instructorIDNum = instructorFound.First().GetID();

                    //If instructor already has 5 classes assigned to them, verify Admin wants to continue with assignment.
                    IEnumerable<Courses> instructorCourseCount = 
                        from course in currentCourses
                        where InstructorBox.Text.Contains(course.GetTeacherID(),StringComparison.OrdinalIgnoreCase)
                        select course;

                    if(instructorCourseCount.Any() && instructorCourseCount.Count() >= 5)
                    {
                        var confirmResult = MessageBox.Show($"Are you sure you want to assign this course to {InstructorBox.Text}?" +
                            $"This instructor already has 5 courses assigned for this semester.",
                                         "Confirm Assignment.",
                                         MessageBoxButtons.YesNo);
                        if (confirmResult == DialogResult.No)
                        {
                            AdminErrorLabel.Text = "Course creation aborted.";
                        }
                        else
                        {
                            //Add course to current list of courses.
                            currentCourses.Add(new Courses(CourseNameBox.Text, instructorIDNum, DescriptionBox.Text,
                                departmentCode, cap));

                            //Call method to save new course to the current course list file.
                            UpdateCourseList(currentCourses);
                        }

                    }
                    else
                    {
                        //Add course to current list of courses.
                        currentCourses.Add(new Courses(CourseNameBox.Text, instructorIDNum, DescriptionBox.Text,
                            departmentCode, cap));

                        //Call method to save new course to the current course list file.
                        AdminErrorLabel.Text = "Course was successfully added.";
                        AdminErrorLabel.ForeColor = Color.Green;
                        UpdateCourseList(currentCourses);
                    }
                }

            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error has occurred. " +
                    "Please verify that you only entered numbers in the capacity field.";
            }
        }

        private void DisplayResults(IEnumerable<Courses> resultsFound)
        {
            //Clear items and columns so duplicates do not appear
            CourseListResults.Items.Clear();
            CourseListResults.Columns.Clear();

            //Clear the error label & search box
            AdminErrorLabel.Text = "";

            //Add the columns
            CourseListResults.Columns.Add("Course Name", 250, HorizontalAlignment.Center);
            CourseListResults.Columns.Add("Instructor", 100, HorizontalAlignment.Center);
            CourseListResults.Columns.Add("Description", 200, HorizontalAlignment.Center);
            CourseListResults.Columns.Add("Course ID", 115, HorizontalAlignment.Center);
            CourseListResults.Columns.Add("Max Capacity", 120, HorizontalAlignment.Center);

            //Show details of the items and allow columns to be reordered
            CourseListResults.View = View.Details;
            CourseListResults.AllowColumnReorder = true;
            CourseListResults.GridLines = true;
            CourseListResults.FullRowSelect = true; //Allows rows to be selected
            CourseListResults.AllowDrop = false; //Do not accept anything dragged and dropped onto the control
            CourseListResults.Sort();

            //Display the items in the resultsFound list to the CourseListResults ListView
            try
            {
                //If resultsFound list contains anything, do following
                if (resultsFound.Any())
                {
                    int size = resultsFound.Count(); //Number of results found
                    int count = 0; //Log current entry for inserting into array

                    listResults = new ListViewItem[size];

                    foreach (var member in resultsFound)
                    {
                        item = new ListViewItem(member.GetName(), 0);
                        item.SubItems.Add(member.GetTeacherID()); //Need name, not ID
                        item.SubItems.Add(member.GetDescription());
                        item.SubItems.Add(member.GetDeptCode());
                        item.SubItems.Add(member.GetMaxCapacity());

                        listResults[count] = item;
                        count++;
                    }

                    CourseListResults.Items.AddRange(listResults); //Output to the ListItem box control

                }
                else
                {
                    AdminErrorLabel.Text = "Error: No results found.";
                    return;
                }
            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error has occurred while displaying results.";
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            //Reset error label information
            AdminErrorLabel.Text = "";

            //reset normal text fields
            CourseNameBox.Text = "";
            DescriptionBox.Text = "";
            CapacityBox.Text = "";
            CourseNumberBox.Text = "";
            SessionNumBox.Text = "";

            //reset dropdown fields
            Dept_DropDownListBox.SelectedIndex = 0;
            InstructorBox.SelectedIndex = 0;
        }

        private void DeleteCourseButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Reset error label information
                AdminErrorLabel.Text = "";
                AdminErrorLabel.ForeColor = Color.Red;

                //Need department, course number, and session id to properly identify which course to delete.
                bool proceed = true; //Assumes necessary information is given
                int courseNum = 0; 
                int sessionNum = 0;

                if(string.IsNullOrWhiteSpace(Dept_DropDownListBox.Text) || string.IsNullOrWhiteSpace(CourseNumberBox.Text) ||
                     string.IsNullOrWhiteSpace(SessionNumBox.Text))
                {
                    proceed = false;
                    AdminErrorLabel.Text = "Error: Department, course number, and course session information is required. ";
                }
                else if(int.Parse(CourseNumberBox.Text) < 100 || int.Parse(CourseNumberBox.Text) >= 500 ||
                    int.Parse(SessionNumBox.Text) < 100 || int.Parse(SessionNumBox.Text) >= 1000)
                {
                    proceed = false;
                    AdminErrorLabel.Text = "Error: Please verify course number entry is between 100 - 499 and " +
                        "session number is between 100 - 999.";
                }
                else
                {
                    string dept = "";
                    courseNum = int.Parse(CourseNumberBox.Text);
                    sessionNum = int.Parse(SessionNumBox.Text);

                    switch (Dept_DropDownListBox.Text)
                    {
                        case "MAT - Mathematics":
                            dept = "MAT";
                            break;
                        case "SCI - Science":
                            dept = "SCI";
                            break;
                        case "HIS - History":
                            dept = "HIS";
                            break;
                        case "ENG - English":
                            dept = "ENG";
                            break;
                        case "PSY - Psychology":
                            dept = "PSY";
                            break;
                        case "SOC - Sociology":
                            dept = "SOC";
                            break;
                        case "LAN - Language":
                            dept = "LAN";
                            break;
                        default:
                            dept = "NA";
                            break;
                    }

                    IEnumerable<Courses> coursesFound =
                        from course in currentCourses
                        where course.GetDeptCode().Contains(courseNum.ToString(), StringComparison.OrdinalIgnoreCase) &&
                              course.GetDeptCode().Contains(sessionNum.ToString(), StringComparison.OrdinalIgnoreCase) &&
                              course.GetDeptCode().Contains(dept, StringComparison.OrdinalIgnoreCase)
                        select course;

                    //If anyone is in the course, deny deletion request
                    if (coursesFound.Any() && coursesFound.Count() > 1)
                    {
                        AdminErrorLabel.Text = "Error: Too many results found. Please verify all courses have a unique department code.";
                    }
                    else if (coursesFound.Any() && coursesFound != null)
                    {
                        var confirmResult = MessageBox.Show($"Are you sure you want to delete {coursesFound.First().GetDeptCode()} " +
                            $"{coursesFound.First().GetName()}?", "Confirm Deletion.", MessageBoxButtons.YesNo);

                        if (confirmResult == DialogResult.No)
                        {
                            AdminErrorLabel.Text = "Course deletion aborted.";
                        }
                        else if(confirmResult == DialogResult.Yes)
                        {
                                if(int.Parse(coursesFound.First().GetCurrentCapacity()) > 0)
                                {
                                    AdminErrorLabel.Text = "Error: Course has students currently enrolled. " +
                                        "Please remove student enrollment before proceeding with deletion.";
                                }
                                else
                                {
                                    //Delete the course from current records and update files.
                                    currentCourses.Remove(coursesFound.First());
                                    AdminErrorLabel.Text = "Deletion successful";
                                    AdminErrorLabel.ForeColor = Color.Green;
                                    UpdateCourseList(currentCourses);
                                }

                        }
                    }
                }

            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error has occurred while removing the course.";
            }
        }

        private void UpdateCourseList(IEnumerable<Courses> courseList)
        {
            try
            {
                IEnumerable<Courses> courseListOrdered =
                    from course in courseList
                    orderby course.GetDeptCode()
                    select course;
            
                using (StreamWriter classWriter = new StreamWriter("ClassList.txt", false))
                {
                    foreach (Courses courses in courseListOrdered)
                    {
                        classWriter.WriteLine(courses.PrintClassInformation());
                    }
                    classWriter.Close();
                }

                //Clear form information
                CourseNameBox.Text = "";
                InstructorBox.Text = "";
                DescriptionBox.Text = "";
                Dept_DropDownListBox.Text = "";
                CapacityBox.Text = "";
            }
            catch
            {
                AdminErrorLabel.Text = "Error: An unexpected error has occurred while adding the course to current list.";
            }

        }
    }
}
