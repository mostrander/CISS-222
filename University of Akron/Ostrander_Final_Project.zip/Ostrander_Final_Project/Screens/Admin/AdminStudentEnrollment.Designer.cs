﻿namespace Ostrander_Final_Project.Screens
{
    partial class AdminStudentEnrollment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EnrollButton = new System.Windows.Forms.Button();
            this.RemoveStudentButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.EnrollSearchButton = new System.Windows.Forms.Button();
            this.SearchBox = new System.Windows.Forms.TextBox();
            this.FNameBox = new System.Windows.Forms.TextBox();
            this.DOB_Box = new System.Windows.Forms.TextBox();
            this.LNameBox = new System.Windows.Forms.TextBox();
            this.FnameLabel = new System.Windows.Forms.Label();
            this.LnameLabel = new System.Windows.Forms.Label();
            this.DOB_Label = new System.Windows.Forms.Label();
            this.Email_Label = new System.Windows.Forms.Label();
            this.Email_Box = new System.Windows.Forms.TextBox();
            this.StudentID_Box = new System.Windows.Forms.TextBox();
            this.StudentID_Label = new System.Windows.Forms.Label();
            this.AdminErrorLabel = new System.Windows.Forms.Label();
            this.ClassesButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // EnrollButton
            // 
            this.EnrollButton.Location = new System.Drawing.Point(12, 346);
            this.EnrollButton.Name = "EnrollButton";
            this.EnrollButton.Size = new System.Drawing.Size(94, 29);
            this.EnrollButton.TabIndex = 0;
            this.EnrollButton.Text = "Enroll";
            this.EnrollButton.UseVisualStyleBackColor = true;
            this.EnrollButton.Click += new System.EventHandler(this.EnrollButton_Click);
            // 
            // RemoveStudentButton
            // 
            this.RemoveStudentButton.Location = new System.Drawing.Point(125, 346);
            this.RemoveStudentButton.Name = "RemoveStudentButton";
            this.RemoveStudentButton.Size = new System.Drawing.Size(94, 29);
            this.RemoveStudentButton.TabIndex = 1;
            this.RemoveStudentButton.Text = "Remove";
            this.RemoveStudentButton.UseVisualStyleBackColor = true;
            this.RemoveStudentButton.Click += new System.EventHandler(this.RemoveStudentButton_Click);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(355, 346);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(94, 29);
            this.CancelButton.TabIndex = 2;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // EnrollSearchButton
            // 
            this.EnrollSearchButton.Location = new System.Drawing.Point(298, 300);
            this.EnrollSearchButton.Name = "EnrollSearchButton";
            this.EnrollSearchButton.Size = new System.Drawing.Size(94, 29);
            this.EnrollSearchButton.TabIndex = 3;
            this.EnrollSearchButton.Text = "Search";
            this.EnrollSearchButton.UseVisualStyleBackColor = true;
            this.EnrollSearchButton.Click += new System.EventHandler(this.EnrollSearchButton_Click);
            // 
            // SearchBox
            // 
            this.SearchBox.AcceptsReturn = true;
            this.SearchBox.Location = new System.Drawing.Point(54, 302);
            this.SearchBox.Name = "SearchBox";
            this.SearchBox.PlaceholderText = "Enter Student ID or Name";
            this.SearchBox.Size = new System.Drawing.Size(233, 27);
            this.SearchBox.TabIndex = 4;
            // 
            // FNameBox
            // 
            this.FNameBox.Location = new System.Drawing.Point(181, 33);
            this.FNameBox.Name = "FNameBox";
            this.FNameBox.Size = new System.Drawing.Size(211, 27);
            this.FNameBox.TabIndex = 5;
            // 
            // DOB_Box
            // 
            this.DOB_Box.Location = new System.Drawing.Point(181, 121);
            this.DOB_Box.Name = "DOB_Box";
            this.DOB_Box.PlaceholderText = "mm/dd/yyyy";
            this.DOB_Box.Size = new System.Drawing.Size(211, 27);
            this.DOB_Box.TabIndex = 6;
            // 
            // LNameBox
            // 
            this.LNameBox.Location = new System.Drawing.Point(181, 77);
            this.LNameBox.Name = "LNameBox";
            this.LNameBox.Size = new System.Drawing.Size(211, 27);
            this.LNameBox.TabIndex = 7;
            // 
            // FnameLabel
            // 
            this.FnameLabel.AutoSize = true;
            this.FnameLabel.Location = new System.Drawing.Point(54, 36);
            this.FnameLabel.Name = "FnameLabel";
            this.FnameLabel.Size = new System.Drawing.Size(83, 20);
            this.FnameLabel.TabIndex = 8;
            this.FnameLabel.Text = "First Name:";
            // 
            // LnameLabel
            // 
            this.LnameLabel.AutoSize = true;
            this.LnameLabel.Location = new System.Drawing.Point(54, 80);
            this.LnameLabel.Name = "LnameLabel";
            this.LnameLabel.Size = new System.Drawing.Size(82, 20);
            this.LnameLabel.TabIndex = 9;
            this.LnameLabel.Text = "Last Name:";
            // 
            // DOB_Label
            // 
            this.DOB_Label.AutoSize = true;
            this.DOB_Label.Location = new System.Drawing.Point(54, 124);
            this.DOB_Label.Name = "DOB_Label";
            this.DOB_Label.Size = new System.Drawing.Size(97, 20);
            this.DOB_Label.TabIndex = 10;
            this.DOB_Label.Text = "Date of Birth:";
            // 
            // Email_Label
            // 
            this.Email_Label.AutoSize = true;
            this.Email_Label.Location = new System.Drawing.Point(54, 169);
            this.Email_Label.Name = "Email_Label";
            this.Email_Label.Size = new System.Drawing.Size(112, 20);
            this.Email_Label.TabIndex = 11;
            this.Email_Label.Text = "E-mail Address:";
            // 
            // Email_Box
            // 
            this.Email_Box.Location = new System.Drawing.Point(181, 166);
            this.Email_Box.Name = "Email_Box";
            this.Email_Box.Size = new System.Drawing.Size(211, 27);
            this.Email_Box.TabIndex = 12;
            // 
            // StudentID_Box
            // 
            this.StudentID_Box.Location = new System.Drawing.Point(181, 211);
            this.StudentID_Box.Name = "StudentID_Box";
            this.StudentID_Box.ReadOnly = true;
            this.StudentID_Box.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StudentID_Box.Size = new System.Drawing.Size(211, 27);
            this.StudentID_Box.TabIndex = 13;
            // 
            // StudentID_Label
            // 
            this.StudentID_Label.AutoSize = true;
            this.StudentID_Label.Location = new System.Drawing.Point(54, 214);
            this.StudentID_Label.Name = "StudentID_Label";
            this.StudentID_Label.Size = new System.Drawing.Size(82, 20);
            this.StudentID_Label.TabIndex = 14;
            this.StudentID_Label.Text = "Student ID:";
            // 
            // AdminErrorLabel
            // 
            this.AdminErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.AdminErrorLabel.Location = new System.Drawing.Point(12, 250);
            this.AdminErrorLabel.Name = "AdminErrorLabel";
            this.AdminErrorLabel.Size = new System.Drawing.Size(419, 49);
            this.AdminErrorLabel.TabIndex = 15;
            this.AdminErrorLabel.Text = "Error:";
            this.AdminErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ClassesButton
            // 
            this.ClassesButton.Location = new System.Drawing.Point(242, 346);
            this.ClassesButton.Name = "ClassesButton";
            this.ClassesButton.Size = new System.Drawing.Size(94, 29);
            this.ClassesButton.TabIndex = 16;
            this.ClassesButton.Text = "Classes";
            this.ClassesButton.UseVisualStyleBackColor = true;
            this.ClassesButton.Click += new System.EventHandler(this.ClassesButton_Click);
            // 
            // AdminStudentEnrollment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 395);
            this.Controls.Add(this.ClassesButton);
            this.Controls.Add(this.AdminErrorLabel);
            this.Controls.Add(this.StudentID_Label);
            this.Controls.Add(this.StudentID_Box);
            this.Controls.Add(this.Email_Box);
            this.Controls.Add(this.Email_Label);
            this.Controls.Add(this.DOB_Label);
            this.Controls.Add(this.LnameLabel);
            this.Controls.Add(this.FnameLabel);
            this.Controls.Add(this.LNameBox);
            this.Controls.Add(this.DOB_Box);
            this.Controls.Add(this.FNameBox);
            this.Controls.Add(this.SearchBox);
            this.Controls.Add(this.EnrollSearchButton);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.RemoveStudentButton);
            this.Controls.Add(this.EnrollButton);
            this.Name = "AdminStudentEnrollment";
            this.Text = "Student Enrollment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button EnrollButton;
        private Button RemoveStudentButton;
        private Button CancelButton;
        private Button EnrollSearchButton;
        private TextBox SearchBox;
        private TextBox FNameBox;
        private TextBox DOB_Box;
        private TextBox LNameBox;
        private Label FnameLabel;
        private Label LnameLabel;
        private Label DOB_Label;
        private Label Email_Label;
        private TextBox Email_Box;
        private TextBox StudentID_Box;
        private Label StudentID_Label;
        private Label AdminErrorLabel;
        private Button ClassesButton;
    }
}