﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ostrander_Final_Project.Screens;
using Ostrander_Final_Project.Classes;

namespace Ostrander_Final_Project.Classes
{
    internal class Assignment
    {
        private string CourseID;
        private string Type;
        private string Name;
        private string StudentID;
        private int PointsPossible;
        private int PointsEarned;
        private double Percentage;


        //Constructor for creating NEW assignments
        public Assignment(string courseID, string name, string type, int possible)
        {
            CourseID = courseID;
            Name = name;
            PointsPossible = possible;
            PointsEarned = 0; //default
            Type = type;
        }

        //Need to verify earned points are not <= 0, For importing existing assignments
        public Assignment(string courseID, string name, string type, int earned, int possible)
        {
            CourseID = courseID;
            Name = name;
            PointsPossible = possible;
            PointsEarned = earned;
            Percentage = PointsEarned / PointsPossible;
            Type = type;
        }

        public int GetPossiblePoints()
        {
            return PointsPossible;
        }

        public int GetPossibleEarned()
        {
            return PointsEarned;
        }

        public double GetPercentage()
        {
            return Percentage;
        }

        public string GetName()
        {
            return Name;
        }

        public string GetType()
        {
            return Type;
        }

        public string GetCourseID()
        {
            return CourseID;
        }

        public void Print()
        {
            Console.WriteLine($"{CourseID} {Name} {PointsEarned}/{PointsPossible} {Percentage}");
        }

        public string PrintToFile()
        {
            return $"{CourseID},{Name},{Type},{PointsPossible}";
        }

    }
}
