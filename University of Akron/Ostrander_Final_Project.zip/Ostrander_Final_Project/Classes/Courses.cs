﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ostrander_Final_Project.Screens;
using Ostrander_Final_Project.Classes;

namespace Ostrander_Final_Project.Classes
{
    internal class Courses
    {
        private string Name;
        private string InstructorID;
        private string Description;
        private string DeptCode;
        private int MaxCapacity; //Max allowed students
        private int CurrentCapacity; //Number of students enrolled in course currently
        private double ClassAverage;

        List<Student>? Enrolled;
        List<Assignment> AssignmentsList;
        bool hasStudents;

        public Courses(string name, string teacherID, string description, string deptcode, int capacity)
        {
            Name = name;
            InstructorID = teacherID;
            Description = description;
            DeptCode = deptcode;
            MaxCapacity = capacity;
            Enrolled = new List<Student>(); //default. No point in a class without students
            AssignmentsList = new List<Assignment>();
            CurrentCapacity = 0; //Default
            ClassAverage = 0; //Default
        }

        //Used for importing data from file
        public Courses(string name, string teacherID, string description, string deptcode, string currentCapacity, string capacity, string enrollment)
        {
            Name = name;
            InstructorID = teacherID;
            Description = description;
            DeptCode = deptcode;
            CurrentCapacity = 0; //default
            MaxCapacity = int.Parse(capacity);
            Enrolled = new List<Student>();
            AssignmentsList = new List<Assignment>();
            ClassAverage = 0; //Default
            
            //Used to determine if enrollment information for class needs to be imported.
            if(enrollment.Contains("true", StringComparison.OrdinalIgnoreCase))
            {
                hasStudents = true;
            }
            else
            {
                hasStudents = false;
            }

            if(hasStudents == true)
            {
                //Import entire list of students
                var fileInput = new FileStream("StudentAccounts.txt", FileMode.OpenOrCreate, FileAccess.Read);
                string line;

                List<Student> students = new List<Student>(); //temp list
                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            students.Add(new Student(words[0].ToString(), words[1].ToString(), words[2].ToString(), words[3].ToString(),
                            words[4].ToString()));
                        }
                    }

                    fileReader.Close();
                }


                //Import list of students enrolled in specific classes
                fileInput = new FileStream("CourseEnrollment.txt", FileMode.OpenOrCreate, FileAccess.Read);

                using (StreamReader fileReader = new StreamReader(fileInput))
                {
                    while ((line = fileReader.ReadLine()) != null)
                    {
                        //Holds the necessary information pulled from file so information can be entered into accounts
                        string[] words = line.Split(',');

                        if (words.Length > 1) //Prevents program from reading empty lines unintentionally inserted into the persistent file of accounts
                        {
                            string entry = $"{words[0].ToString()} {words[1].ToString()} {words[2].ToString()} {words[3].ToString()} {words[4].ToString()}";

                            //Idenitify the individual student in entry of file
                            IEnumerable<Student> found =
                                from individual in students
                                where !string.IsNullOrWhiteSpace(entry) && entry.Contains(individual.GetStudentID(), StringComparison.OrdinalIgnoreCase)
                                select individual;

                            //determine if individual belongs in the class
                            if(!string.IsNullOrWhiteSpace(entry) && entry.Contains(DeptCode,StringComparison.OrdinalIgnoreCase))
                            {
                                AddStudent(found.First());
                            }
                        }
                    }

                    fileReader.Close();
                }

                fileInput.Close();
            }
            
        }

        //Displays all students in course and their class average
        public string PrintStudents(Student studentSelectedToPrint)
        {
            return ($"{DeptCode} " + studentSelectedToPrint.PrintToFile());
        }

        public void SpecificStudentGrades(Student student)
        {
            student.PrintGrades();
        }

        public void UpdateClassAverage()
        {
            int possible = 0;
            int earned = 0;

            foreach (Student student in Enrolled)
            {
                possible = possible + student.GetTotalPossible();
                earned = earned + student.GetTotalEarned();
            }

            ClassAverage = earned / possible;
        }


        public string GetClassAverage()
        {
            string average = (ClassAverage * 100).ToString() + "%";
            return average;
        }


        //Admin functions below
        //Adds student to the class.
        public void AddStudent(Student student)
        {
                Enrolled.Add(student);
                CurrentCapacity++;
        }

        public void RemoveStudent(Student student)
        {

                Enrolled.Remove(student);
                CurrentCapacity--;
        }

        public void UpdateMaxCapacity(int newCapacity)
        {
            MaxCapacity = newCapacity;
        }

        public string PrintClassInformation()
        {
            ClassHasStudentsEnrolled();
            return $"{GetName()},{GetTeacherID()},{GetDescription()},{GetDeptCode()},{GetCurrentCapacity()},{GetMaxCapacity()}, {hasStudents}";
        }

        public string GetName()
        {
            return Name;
        }

        public string GetDeptCode()
        {
            return DeptCode;
        }

        public string GetDescription()
        {
            return Description;
        }

        public string GetTeacherID()
        {
            return InstructorID;
        }

        public string GetCurrentCapacity()
        {
            return CurrentCapacity.ToString();
        }

        public string GetMaxCapacity()
        {
            return MaxCapacity.ToString();
        }

        public List<Student> GetEnrollment()
        {
            return Enrolled;
        }


        public string NumberOfStudents()
        {
            int number;

            if (Enrolled == null || !Enrolled.Any())
            {
                number = 0;
            }
            else
            {
                number = Enrolled.Count();
            }
            return number.ToString();
        }

        public bool ClassHasStudentsEnrolled()
        {
            if (Enrolled == null || !Enrolled.Any())
            {
                hasStudents = false;
                CurrentCapacity = 0;
            }
            else
            {
                hasStudents = true;
                CurrentCapacity = Enrolled.Count();
            }
            
            return hasStudents;
        }

        public bool ClassHasAssignmentList()
        {
            if(AssignmentsList == null || !AssignmentsList.Any())
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public void AddAssignment(Assignment homework)
        {
            AssignmentsList.Add(homework);
        }

        public void RemoveAssignment(Assignment homework)
        {
            if (AssignmentsList != null && AssignmentsList.Any())
            {
                IEnumerable<Assignment> found =
                    from assignment in AssignmentsList
                    where assignment == homework
                    select assignment;

                if (found.Any())
                {
                    AssignmentsList.Remove(homework);
                }
            }
        }

    }
}
