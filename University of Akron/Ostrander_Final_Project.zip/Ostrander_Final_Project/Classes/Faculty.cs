﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ostrander_Final_Project.Screens;
using Ostrander_Final_Project.Classes;

namespace Ostrander_Final_Project.Classes
{
    internal class Faculty
    {
        //Personal information
        private string FirstName;
        private string LastName;
        private string Address;
        private string Phone;

        //company information
        private string EmployeeID;
        private string Department;
        private decimal Salary;
        private string Password;
        private bool Admin;

        List<Courses>? ListofCourses;
        bool hasCourseList;

        //Creates the faculty accounts initially
        public Faculty(string fname, string lname, string address, string phone, string ID, 
            string dpt, decimal salary, bool admin)
        {
            FirstName = fname;
            LastName = lname;
            Address = address;
            Phone = phone;
            EmployeeID = ID;
            Department = dpt;
            Salary = salary;
            Password = "Welcome2Company!"; //Default password
            Admin = admin;

            if (!dpt.Contains("TSS", StringComparison.OrdinalIgnoreCase))
            {
                AddCourseList();
            }
        }

        //Used when importing existing Faculty accounts from file
        public Faculty(string fname, string lname, string address, string phone, string ID,
                        string dpt, string password, string salary, string admin, string courseListExists)
        {
            FirstName = fname;
            LastName = lname;
            Address = address;
            Phone = phone;
            EmployeeID = ID;
            Department = dpt;
            Salary = decimal.Parse(salary);
            Password = password; 
            
            if(admin == "true" || admin == "True" || admin.Equals("true",StringComparison.OrdinalIgnoreCase))
            {
                Admin = true;
            }
            else
            {
                Admin = false;
            }

            if(courseListExists.Contains("true", StringComparison.OrdinalIgnoreCase))
            {
                AddCourseList(); //Sets hasCourseList variable to true, anyway
            }
            else
            {
                hasCourseList = false;
            }
            
        }


        //Used only for holding current userAccount. May discard this option.
        public Faculty()
        {
        }

        //Used to add a list of courses for an instructor
        //(prevents admins from having course lists by default)
        public void AddCourseList()
        {
            ListofCourses = new List<Courses>();
            hasCourseList = true; 
        }

        public void AddCourse(Courses course)
        {
            if(HasCourseList() == true)
            {
                ListofCourses.Add(course);
            }

        }

        //Methods for updating various information
        //NOTE: Must implement verification for valid imput
        public void UpdateName(string fname, string lname)
        {
            FirstName = fname;
            LastName= lname;
        }

        public void UpdateAddress(string address)
        {
            Address = address;
        }

        public void UpdatePhone(string phone)
        {
            Phone = phone;
        }

        //Password method is exception - Users should be able to change own password
        //Admin can change too
        public void UpdatePassword(string password)
        {
            Password = password;
        }

        //Only Admins should be allowed to update following information
        public void UpdateDepartment(string department)
        {
            Department = department;
        }

        public void UpdateSalary(decimal salary)
        {
            Salary = salary;
        }

        public void UpdateAdmin(bool admin)
        {
            Admin = admin;
        }

        public string GetID()
        {
            return EmployeeID;
        }

        public string GetPassword()
        {
            return Password;
        }

        public bool GetAdminStatus()
        {
            return Admin;
        }

        public string GetName()
        {
            string name = $"{FirstName} {LastName}";
            return name;
        }

        public string PrintName()
        {
            string name = $"{LastName}, {FirstName}";
            return name;
        }

        public string GetFName()
        {
            return FirstName;
        }

        public string GetLName()
        {
            return LastName;
        }

        public string GetAddress()
        {
            return Address;
        }

        public string GetDepartment()
        {
            return Department;
        }

        public decimal GetSalary()
        {
            return Salary;
        }

        public string GetPhone()
        {
            return Phone;
        }

        public bool HasCourseList()
        {
            return hasCourseList;

        }

        public List<Courses> GetCourses()
        {
            return ListofCourses;
        }

        public int NumberOfCourses()
        {
            int number;
            
            if(ListofCourses == null || !ListofCourses.Any())
            {
                number = 0;
            }
            else
            {
                number = ListofCourses.Count();
            }
            return number;
        }

        //Allows all necessary information for recreating the individual account when exporting to a file.
        public string PrintToFile()
        {
            HasCourseList();
            return $"{FirstName},{LastName},{Address},{Phone},{EmployeeID},{Department},{Password},{Salary},{Admin},{hasCourseList}";
        }

    }
}
