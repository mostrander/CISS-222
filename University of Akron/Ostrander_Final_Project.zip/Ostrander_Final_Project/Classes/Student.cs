﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ostrander_Final_Project.Screens;
using Ostrander_Final_Project.Classes;

namespace Ostrander_Final_Project.Classes
{
    internal class Student
    {
        private string FirstName;
        private string LastName;
        private DateTime dob; //Date of Birth
        private int Age;
        private string Email;
        private string StudentID;
        private double StudentAverage;
        private int TotalPossible;
        private int TotalEarned;
        List<Assignment> CourseAssignments;
        List<string> grades;

        public Student(string fname, string lname, string DateOfBirth, string email, string id)
        {
            FirstName = fname;
            LastName = lname;
            dob = Convert.ToDateTime(DateOfBirth).Date;

            //Calculate their Age
            DateTime today = DateTime.Now;
            Age = today.Year - dob.Year;

            Email = email;

            StudentID = id;

            CourseAssignments = new List<Assignment>(); //Default, all students have assignments
            grades = new List<string>();
        }
       
        public void AddAssignment(string course, string type, string name, int earned, int possible)
        {
            Assignment homework = new Assignment(course,type, name, earned, possible);
            CourseAssignments.Add(homework);
        }

        public void AddAssignment(Assignment homework)
        {
            CourseAssignments.Add(homework);
        }

        public void RemoveAssignment(Assignment name)
        {
            CourseAssignments.Remove(name);
        }

        public void AddGrade(string gradeValue)
        {
            grades.Add(gradeValue);
        }

        private void UpdateAverage()
        {
            TotalPossible = 0;
            TotalEarned = 0;

            for(int i = 0; i < CourseAssignments.Count; i++)
            {
                TotalPossible = TotalPossible + CourseAssignments[i].GetPossiblePoints();
                TotalEarned = TotalEarned + CourseAssignments[i].GetPossibleEarned();
            }

            StudentAverage = TotalEarned / TotalPossible;
        }


        public double GetAverage()
        {
            return StudentAverage;
        }

        public string GetName()
        {
            return $"{FirstName} {LastName}";
        }

        public string GetFName()
        {
            return FirstName;
        }

        public string GetLName()
        {
            return LastName;
        }

        public string GetDoB()
        {
            return dob.ToString("MM/dd/yyyy");
        }

        public int GetAge()
        {
            //Recalculate their Age to ensure accuracy (At least as close as I can get)
            DateTime today = DateTime.Now;
            Age = today.Year - dob.Year;

            return Age;
        }

        public string GetEmail()
        {
            return Email;
        }

        public string GetStudentID()
        {
            return StudentID;
        }

        public int GetTotalPossible()
        {
            return TotalPossible;
        }

        public int GetTotalEarned()
        {
            return TotalEarned;
        }

        public void Print()
        {
            Console.WriteLine($"{FirstName} {LastName} {StudentAverage}");
        }

        public void PrintGrades()
        {
            foreach (Assignment assignment in CourseAssignments)
            {
                assignment.Print();
            }
        }


        public string PrintToFile()
        {
            return $"{FirstName},{LastName},{dob},{Email},{StudentID}";
        }

        public List<Assignment> ReturnAssignmentList()
        {
            return CourseAssignments;
        }

    }
}
