using Ostrander_Final_Project.Classes;
using Ostrander_Final_Project.Screens;

namespace Ostrander_Final_Project
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new LoginScreen());
        }
    }
}