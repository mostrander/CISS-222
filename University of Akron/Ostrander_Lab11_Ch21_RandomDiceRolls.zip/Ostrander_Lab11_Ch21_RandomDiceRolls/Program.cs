﻿var random = new Random();
Console.WriteLine("Random Die Thrown");

// Generates 60,000,000 random numbers ranging from 1-6
int[] values = Enumerable.Range(1, 60000000)
    .Select(x => random.Next(1, 7))
    .ToArray();

// Groups the generated numbers by the values (1-6) and sorts them in ascending order
IEnumerable<IGrouping<int, int>> groups = 
    values.OrderBy(x => x)
    .GroupBy(x => x);

foreach(IGrouping<int, int> group in groups)
{
    // Writes the current value to the console (1-6)
    Console.Write("\n " + group.Key + ": " + group.Count());
}

// Pauses the Console window so we can see the results
Console.ReadLine();
