﻿using Ostrander_Lab9_CarbonFootPrint;

Console.WriteLine("Welcome to the Carbon Footprint Calculator!\n" +
    "This program will calculate your footprint for your home, automobile, and airplane usage.\n" +
    "Please only respond with positive numbers, unless asked otherwise. \nDo not include spaces or special characters( i.e., $)" +
    " in your responses.\n");

Console.WriteLine("\nLet's begin with your automobile.");
Automobile carPrint = new Automobile();

Console.WriteLine("\nNow, let's look at your airplane footprint.");
Air_Flight planePrint = new Air_Flight();

Console.WriteLine("\nFinally, let's look at your home footprint.");
Home homePrint = new Home();

Console.WriteLine("\nHere is the summary of your carbon footprint: \n" +
    $"Home: {homePrint.GetCarbonFootprint()}\n" +
    $"Automobile: {carPrint.GetCarbonFootprint()}\n" +
    $"Plane: {planePrint.GetCarbonFootprint()}");

Console.ReadLine(); //Allows user to end program when they want.
