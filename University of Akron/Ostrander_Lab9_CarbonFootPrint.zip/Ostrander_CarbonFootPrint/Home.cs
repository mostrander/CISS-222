﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab9_CarbonFootPrint
{
    internal class Home : ICarbonFootprint
    {

        decimal electricBill;
        decimal gasBill;
        decimal oilBill;
        decimal recycleNews;
        decimal recycleTin;

        public Home()
        {
            int attempts = 0;
            bool valid = false;

            while (attempts <= 3 && valid == false)
            {
                int number; 

                try
                {
                    if(attempts >= 3)
                    {
                        //Allows reset of program to continue working, assigns zero as default value
                        Console.WriteLine("Too many failed attempts. Unable to calculate your home carbon footprint.");
                        electricBill = 0;
                        gasBill = 0;
                        oilBill = 0;
                        recycleTin = 0;
                        recycleNews = 0;

                        valid = true; //Needed to break loop
                    }
                    else
                    {
                        Console.WriteLine("Please enter the number corresponding to the type of bill you pay monthly: \n" +
                            "1. Electric Bill\n" +
                            "2. Gas Bill\n" +
                            "3. Oil Bill\n" +
                            "4. None\n");
                        number = int.Parse(Console.ReadLine());

                        switch (number)
                        {
                            case 1:
                                Console.WriteLine("\nPlease enter the amount you pay monthly for your electric bill: ");
                                electricBill = decimal.Parse(Console.ReadLine());

                                if (electricBill <= 0)
                                {
                                    Console.WriteLine("Error: It is not possible to have no bill if you are paying it monthly. Try again.");
                                    throw new Exception();
                                }
                                break;

                            case 2:
                                Console.WriteLine("\nPlease enter the amount you pay monthly for your gas bill: ");
                                gasBill = decimal.Parse(Console.ReadLine());

                                if (gasBill <= 0)
                                {
                                    Console.WriteLine("Error: It is not possible to have no bill if you are paying it monthly. Try again.");
                                    throw new Exception();
                                }
                                break;

                            case 3:
                                Console.WriteLine("\nPlease enter the amount you pay monthly for your oil bill: ");
                                oilBill = decimal.Parse(Console.ReadLine());

                                if (oilBill <= 0)
                                {
                                    Console.WriteLine("Error: It is not possible to have no bill if you are paying it monthly. Try again.");
                                    throw new Exception();
                                }
                                break;

                            case 4:
                                Console.WriteLine("\nYou don't have any energy costs? How lucky of you!");
                                break;

                            default:
                                Console.WriteLine("Invalid response. Please enter a number between 1 - 3 corresponding to your selection.");
                                throw new Exception();
                                break;
                        }

                        Console.WriteLine("\nDo you recycle newspapers? Y/N");
                        string answer = Console.ReadLine();

                        if (answer != "Y" && answer != "y" && answer != "N" && answer != "n")
                        {
                            Console.WriteLine("Invalid input. Please enter 'y' or 'n' without any spaces for your response.\n" +
                                "Do you recycle newspapers? Y/N");
                            answer = Console.ReadLine();

                            if(answer != "Y" && answer != "y" && answer != "N" && answer != "n")
                            {
                                Console.WriteLine("Error: Input is still invalid.");
                                throw new Exception();
                            }

                        }

                        switch (answer)
                        {
                            case "n":
                            case "N":
                                recycleNews = 184;
                                break;
                            case "y":
                            case "Y":
                            default:
                                break;
                        }


                        Console.WriteLine("\nDo you recycle aluminum and tin? Y/N");
                        answer = Console.ReadLine();

                        if (answer != "Y" && answer != "y" && answer != "N" && answer != "n")
                        {
                            Console.WriteLine("Invalid input. Please enter 'y' or 'n' without any spaces for your response.\n" +
                                "Do you recycle aluminum and tin? Y/N");
                            answer = Console.ReadLine();

                            if (answer != "Y" && answer != "y" && answer != "N" && answer != "n")
                            {
                                Console.WriteLine("Error: Input is still invalid.");
                                throw new Exception();
                            }
                        }

                        switch (answer)
                        {
                            case "n":
                            case "N":
                                recycleTin = 166;
                                break;
                            case "y":
                            case "Y":
                            default:
                                break;
                        }

                        Console.WriteLine("\nYour home carbon footprint is: " + GetCarbonFootprint());
                        valid = true;
                    }
                }
                catch
                {
                    Console.WriteLine("Invalid input. Please only enter positive, numerical values.");
                    attempts++;
                }
            }
        }

        public decimal GetCarbonFootprint()
        {
            return (electricBill * 105) + (gasBill * 105) + (oilBill * 113) + recycleNews + recycleTin;
        }
    }
}
