﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab9_CarbonFootPrint
{
    internal class Automobile : ICarbonFootprint
    {

        decimal yearlyMilage;

        public Automobile()
        {
            int attempts = 0;
            bool valid = false;

            while (attempts <= 3 && valid == false)
            {
                try
                {
                    if (attempts >= 3)
                    {
                        //Allows reset of program to continue working, assigns zero as default value
                        Console.WriteLine("\nToo many failed attempts. Unable to calculate your automobile carbon footprint.");
                        yearlyMilage = 0;
                        valid = true; //Needed to break loop
                    }
                    else
                    {
                        Console.WriteLine("\nPlease enter the number of miles you drive your car yearly: ");
                        yearlyMilage = decimal.Parse(Console.ReadLine());

                        if(yearlyMilage < 0)
                        {
                            Console.WriteLine("Error: It is not possible to drive negative milages.");
                            throw new Exception();
                        }

                        Console.WriteLine("\nYou automobile carbon footprint is: " + GetCarbonFootprint());
                        valid = true;
                    }

                }
                catch
                {
                    Console.WriteLine("Invalid input. Please enter only positive, numerical values.");
                    attempts++;
                }
            }
        }


        public decimal GetCarbonFootprint()
        {
            return yearlyMilage * (decimal).79;
        }
    }
}
