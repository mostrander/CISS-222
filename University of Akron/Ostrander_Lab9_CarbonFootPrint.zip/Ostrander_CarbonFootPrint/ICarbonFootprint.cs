﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab9_CarbonFootPrint
{
    internal interface ICarbonFootprint
    {
        decimal GetCarbonFootprint();
    }
}
