﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab9_CarbonFootPrint
{
    internal class Air_Flight : ICarbonFootprint
    {

        decimal flightLessThan_4;
        decimal flightMoreThan_4;

        public Air_Flight()
        {
            int attempts = 0;
            bool valid = false;

            while (attempts <= 3 && valid == false)
            {
                try
                {
                    if(attempts >= 3)
                    {
                        //Allows reset of program to continue working, assigns zero as default value
                        Console.WriteLine("\nToo many failed attempts. Unable to calculate your flight carbon footprint.");
                        flightLessThan_4 = 0;
                        flightMoreThan_4 = 0;

                        valid = true; //Needed to break loop
                    }
                    else
                    {
                        Console.WriteLine("\nPlease enter the number of miles flown in the last year for flights under 4 hours: ");
                        decimal number = decimal.Parse(Console.ReadLine());

                        Console.WriteLine("\nPlease enter the number of miles flown in the last year for flights over 4 hours: ");
                        decimal number2 = decimal.Parse(Console.ReadLine());

                        if (number < 0 || number2 < 0)
                        {
                            Console.WriteLine("Error: It is impossible to fly negative miles.");
                            throw new Exception();
                        }
                        else
                        {
                            flightLessThan_4 = number;
                            flightMoreThan_4 = number2;
                        }

                        Console.WriteLine("\nYour carbon footprint for flights is: " + GetCarbonFootprint()); 
                        valid = true;

                    }
                }
                catch
                {
                    Console.WriteLine("Invalid input. Please only enter positive, numerical values.");
                    attempts++;
                }
            }

        }


        public decimal GetCarbonFootprint()
        {

            return (flightLessThan_4 * 1100) + (flightMoreThan_4 * 4400);
        }
    }
}
