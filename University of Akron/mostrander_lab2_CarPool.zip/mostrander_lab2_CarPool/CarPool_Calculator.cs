﻿// Purpose: To take user information regarding their costs of driving daily and calculate how much they can save by carpooling.

int tries = 1; //Tracks number of user tries before terminating program. (To prevent infinite loops)

while (tries <= 3)
{
    //Try-Catch block to help resolve errors.
    try
    {
        Console.WriteLine("Welcome to the Car-Pool Savings Calculator!\nLet's begin by gathering some information.\n\n" +
            "How many total miles do you drive daily?");
        int milesDriven = int.Parse(Console.ReadLine());

        Console.WriteLine("What is the average number of miles per gallon for your car?");
        float milePerGallon = float.Parse(Console.ReadLine());

        Console.WriteLine("What is the average cost per gallon of gasoline (in cents) you pay?");
        decimal gasCost = decimal.Parse(Console.ReadLine());

        Console.WriteLine("How much do you pay daily for parking fees (in cents)?");
        decimal parkingFeeCost = decimal.Parse(Console.ReadLine());

        Console.WriteLine("How much do you pay daily for tolls (in cents)?");
        decimal tollFeeCost = decimal.Parse(Console.ReadLine());

        if(milesDriven < 0 || milePerGallon < 0 || gasCost < 0 || parkingFeeCost < 0 || tollFeeCost < 0)
        {
            throw new Exception();
        }

        Console.WriteLine("\nYou have entered: \n" +
            $"\nTotal Miles: {milesDriven}" +
            $"\nAverage miles per gallon: {milePerGallon}" +
            $"\nCost per Gallon of Gas: {gasCost:C}" +
            $"\nParking fees per day (in cents): {parkingFeeCost:C}" +
            $"\nTolls per day (in cents): {tollFeeCost:C}");

        //Begin calculating the daily cost of driving alone versus carpooling with others (up to 3 people)
        float gallonsUsed = milesDriven / milePerGallon;
        decimal gallonsUsedCost = (decimal)gallonsUsed * gasCost;
        decimal dailyCostSolo = gallonsUsedCost + parkingFeeCost + tollFeeCost;

        //Savings based on carpooling.
        decimal savings = dailyCostSolo - (dailyCostSolo / 2);
        Console.WriteLine($"\nHere is how much you spend daily on driving: {dailyCostSolo:C}");
        Console.WriteLine($"Here is how much you would save if you car-pool with one person: {savings:C}");

        savings = dailyCostSolo - (dailyCostSolo / 3);
        Console.WriteLine($"Here is how much you would save if you car-pool with two people: {savings:C}");

        savings = dailyCostSolo - (dailyCostSolo / 4);
        Console.WriteLine($"Here is how much you would save if you car-pool with three people: {savings:C}");

        tries = 4; //End loop and terminate
    }
    catch
    {
        if(tries < 3)
        {
            Console.WriteLine("\nError: Invalid input. Program only accepts positive numbers starting with 0. Please Try again.\n");
            tries++;
        }
        else
        {
            Console.WriteLine("\nToo many failed attempts. Terminating program. Goodbye.");
            Environment.Exit(1);
        }
    }
}