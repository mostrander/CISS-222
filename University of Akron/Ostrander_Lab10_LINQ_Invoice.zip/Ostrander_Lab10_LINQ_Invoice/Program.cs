﻿
using Ostrander_Lab10_LINQ_Invoice;

var invoices = new[] { new Invoice(83, "Electric sander", 7, (decimal)57.98),
                       new Invoice(3, "Wrench", 34, (decimal)7.50),
                       new Invoice(56, "Jig saw", 21, (decimal)11.00),
                       new Invoice(68, "Screwdriver", 106, (decimal)6.99),
                       new Invoice(39, "Lawn mower", 3, (decimal)79.5),
                       new Invoice(77, "Hammer", 76, (decimal)11.99),
                       new Invoice(7, "Sledge hammer", 11, (decimal)21.50),
                       new Invoice(24, "Power saw", 18, (decimal)99.99) };

//Just testing to make sure I entered information into array correctly.
Console.WriteLine("The original array of invoices: ");
Console.WriteLine("Part#   Description".PadRight(23) + "Quantity".PadRight(10) + "Price");
for (int i = 0; i < invoices.Length; i++)
{
    Console.WriteLine(invoices[i].ToString());
}

//LINQ that sorts by PartDescription
Console.WriteLine("\nThe invoices sorted by Description: ");
var descriptionSort = 
    from invoice in invoices
    orderby invoice.PartDescription
    select invoice;

Console.WriteLine("Part#   Description".PadRight(23) + "Quantity".PadRight(10) + "Price");
foreach(var element in descriptionSort)
{
    Console.WriteLine(element.ToString());
}


//LINQ that sorts by Price
Console.WriteLine("\nThe invoices sorted by Price: ");
var priceSort =
    from invoice2 in invoices
    orderby invoice2.Price
    select invoice2;

Console.WriteLine("Part#   Description".PadRight(23) + "Quantity".PadRight(10) + "Price");
foreach (var element in priceSort)
{
    Console.WriteLine(element.ToString());
}


//LINQ that selects PartDescription and Quantity, then sorts by Quantity
Console.WriteLine("\nThe invoices shown with only Description and Quantity, and sorted by Quantity: ");
var descriptionQuantity =
    from invoice3 in invoices
    orderby invoice3.Quantity
    select new {invoice3.PartDescription, invoice3.Quantity};

Console.WriteLine("Part Description".PadRight(21) + "Quantity");
foreach (var element in descriptionQuantity)
{
    Console.WriteLine($"{element.PartDescription.PadRight(20)} {element.Quantity}");
}


//LINQ that selects from each Invoice the PartDescription and value of Invoice (Quantity*Price), then names the calculated column
//InvoiceTotal. Orders by Invoice value.
Console.WriteLine("\n The invoices shown with only Description and total value, sorted by total value of invoice: ");
var invoiceValue = 
    from invoice4 in invoices
    let InvoiceTotal = invoice4.Quantity * invoice4.Price
    orderby InvoiceTotal
    select new {invoice4.PartDescription, InvoiceTotal};

Console.WriteLine("Part Description".PadRight(21) + "Total");
foreach (var element in invoiceValue)
{
    Console.WriteLine($"{element.PartDescription.PadRight(20)} {element.InvoiceTotal:C}");
}


//LINQ that takes results from previous and selects Invoices in range of $200-500.
Console.WriteLine("\nInvoices selected within the range of $200 - $500: ");
var invoiceValueRange =
    from invoice5 in invoiceValue
    where invoice5.InvoiceTotal >= 200M && invoice5.InvoiceTotal <= 500M
    select invoice5;

Console.WriteLine("Part Description".PadRight(21) + "Total");
foreach (var element in invoiceValueRange)
{
    Console.WriteLine($"{element.PartDescription.PadRight(20)} {element.InvoiceTotal:C}");
}