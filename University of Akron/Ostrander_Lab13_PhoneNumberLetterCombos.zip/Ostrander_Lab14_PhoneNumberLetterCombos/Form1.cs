﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ostrander_Lab14_PhoneNumberLetterCombos
{
    public partial class NumberLetterComboGenerator : Form
    {
        //Lists for the number combinations. 
        List<string> number2 = new List<string>() { "A", "B", "C" };
        List<string> number3 = new List<string>() { "D", "E", "F" };
        List<string> number4 = new List<string>() { "G", "H", "I" };
        List<string> number5 = new List<string>() { "J", "K", "L" };
        List<string> number6 = new List<string>() { "M", "N", "O" };
        List<string> number7 = new List<string>() { "P", "R", "S" };
        List<string> number8 = new List<string>() { "T", "U", "V" };
        List<string> number9 = new List<string>() { "W", "X", "Y", "Z" };

        public NumberLetterComboGenerator()
        {
            InitializeComponent();
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            try
            {
                ErrorLabel.ForeColor = Color.Red;
                ErrorLabel.Text = "";

                //If any of the boxes are empty, inform the user
                if (string.IsNullOrWhiteSpace(BoxNumber1.Text) || string.IsNullOrWhiteSpace(BoxNumber2.Text) || 
                    string.IsNullOrWhiteSpace(BoxNumber3.Text) || string.IsNullOrWhiteSpace(BoxNumber4.Text) || 
                    string.IsNullOrWhiteSpace(BoxNumber5.Text) || string.IsNullOrWhiteSpace(BoxNumber6.Text) || 
                    string.IsNullOrWhiteSpace(BoxNumber7.Text) )
                {
                    ErrorLabel.Text = "Error: All boxes above must be filled out. Please ensure a number 2 - 9 is entered into each box.";
                }
                //All boxes must only contain DIGITS. Not letters or any other type of character.
                else if(!BoxNumber1.Text.All(c => char.IsDigit(c)) || !BoxNumber2.Text.All(c => char.IsDigit(c)) || 
                    !BoxNumber3.Text.All(c => char.IsDigit(c)) || !BoxNumber4.Text.All(c => char.IsDigit(c)) || 
                    !BoxNumber5.Text.All(c => char.IsDigit(c)) || !BoxNumber6.Text.All(c => char.IsDigit(c)) || 
                    !BoxNumber7.Text.All(c => char.IsDigit(c)))
                {
                    ErrorLabel.Text = "Error: All boxes must contain a numeric value between 2 - 9 and nothing else.";
                }
                else if (int.Parse(BoxNumber1.Text) <2 || int.Parse(BoxNumber1.Text) > 9 || int.Parse(BoxNumber2.Text) < 2 || 
                    int.Parse(BoxNumber2.Text) > 9 || int.Parse(BoxNumber3.Text) < 2 || int.Parse(BoxNumber3.Text) > 9 ||
                    int.Parse(BoxNumber4.Text) < 2 || int.Parse(BoxNumber4.Text) > 9 || int.Parse(BoxNumber5.Text) < 2 || 
                    int.Parse(BoxNumber5.Text) > 9 || int.Parse(BoxNumber6.Text) < 2 || int.Parse(BoxNumber6.Text) > 9 ||
                    int.Parse(BoxNumber7.Text) < 2 || int.Parse(BoxNumber7.Text) > 9)
                {
                    ErrorLabel.Text = "Error: All values entered must be between 2 - 9.";
                }
                else
                {
                    string phoneNumberText = "";
                    string value1Text, value2Text, value3Text, value4Text, value5Text, value6Text, value7Text, value8Text;
                    value1Text = value2Text = value3Text = value4Text = value5Text = value6Text = value7Text = value8Text = "";

                    //Determine what lists are being used
                    foreach(string value1 in getNumberList(BoxNumber1.Text))
                    {
                        value1Text = value1.ToUpper(); //grab the value in the list each round, display as capital letters

                        foreach (string value2 in getNumberList(BoxNumber2.Text))
                        {
                            value2Text = value2.ToUpper();
                            foreach (string value3 in getNumberList(BoxNumber3.Text))
                            {
                                value3Text = value3.ToUpper();
                                foreach (string value4 in getNumberList(BoxNumber4.Text))
                                {
                                    value4Text = value4.ToUpper();
                                    foreach (string value5 in getNumberList(BoxNumber5.Text))
                                    {
                                        value5Text = value5.ToUpper();
                                        foreach (string value6 in getNumberList(BoxNumber6.Text))
                                        {
                                            value6Text = value6.ToUpper();
                                            foreach (string value7 in getNumberList(BoxNumber7.Text))
                                            {
                                                value7Text = value7.ToUpper();
                                                phoneNumberText = ""; //Reset the string value each time through

                                                phoneNumberText = value1Text + value2Text + value3Text + value4Text + value5Text
                                                    + value6Text + value7Text;

                                                //Add to listview so the user can view without needing to bring up the exported file
                                                DisplayNumberCombosBox.Items.Add(phoneNumberText);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }//End of the Foreach loops

                    using(StreamWriter fileWriter = new StreamWriter("MyPhoneText.txt", false))
                    {
                        foreach(string value in DisplayNumberCombosBox.Items)
                        {
                            fileWriter.WriteLine(value);
                        }
                    }

                    ErrorLabel.Text = "Success. The copy has been saved to the bin folder.";
                    ErrorLabel.ForeColor = Color.Green;
                }
            }
            catch
            {
                ErrorLabel.Text = "Error: An unexpected error has occurred.";
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            //Reset the form fields for user

            BoxNumber1.Text = "";
            BoxNumber2.Text = "";
            BoxNumber3.Text = "";
            BoxNumber4.Text = "";
            BoxNumber5.Text = "";
            BoxNumber6.Text = "";
            BoxNumber7.Text = "";

            DisplayNumberCombosBox.Items.Clear();
        }

        private List<string> getNumberList(string value)
        {
            switch (value)
            {
                case "2":
                    return number2;
                    break;
                case "3":
                    return number3;
                    break;
                case "4":
                    return number4;
                    break;
                case "5":
                    return number5;
                    break;
                case "6":
                    return number6;
                    break;
                case "7":
                    return number7;
                    break;
                case "8":
                    return number8;
                    break;
                case "9":
                    return number9;
                    break;
                default:
                    //return a blank list
                    return new List<string>();
                    break;
            }
        }
    }
}
