﻿namespace Ostrander_Lab14_PhoneNumberLetterCombos
{
    partial class NumberLetterComboGenerator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ClearButton = new System.Windows.Forms.Button();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.BoxNumber1 = new System.Windows.Forms.TextBox();
            this.BoxNumber8 = new System.Windows.Forms.TextBox();
            this.BoxNumber7 = new System.Windows.Forms.TextBox();
            this.BoxNumber6 = new System.Windows.Forms.TextBox();
            this.BoxNumber5 = new System.Windows.Forms.TextBox();
            this.BoxNumber3 = new System.Windows.Forms.TextBox();
            this.BoxNumber2 = new System.Windows.Forms.TextBox();
            this.BoxNumber4 = new System.Windows.Forms.TextBox();
            this.DisplayNumberCombosBox = new System.Windows.Forms.ListBox();
            this.ErrorLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ClearButton
            // 
            this.ClearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearButton.Location = new System.Drawing.Point(219, 72);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(99, 29);
            this.ClearButton.TabIndex = 0;
            this.ClearButton.Text = "Clear";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // SubmitButton
            // 
            this.SubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButton.Location = new System.Drawing.Point(114, 72);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(94, 29);
            this.SubmitButton.TabIndex = 1;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // BoxNumber1
            // 
            this.BoxNumber1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoxNumber1.Location = new System.Drawing.Point(79, 28);
            this.BoxNumber1.Name = "BoxNumber1";
            this.BoxNumber1.Size = new System.Drawing.Size(29, 30);
            this.BoxNumber1.TabIndex = 2;
            // 
            // BoxNumber8
            // 
            this.BoxNumber8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoxNumber8.Location = new System.Drawing.Point(184, 28);
            this.BoxNumber8.Name = "BoxNumber8";
            this.BoxNumber8.ReadOnly = true;
            this.BoxNumber8.Size = new System.Drawing.Size(29, 30);
            this.BoxNumber8.TabIndex = 3;
            this.BoxNumber8.Text = " --";
            // 
            // BoxNumber7
            // 
            this.BoxNumber7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoxNumber7.Location = new System.Drawing.Point(324, 28);
            this.BoxNumber7.Name = "BoxNumber7";
            this.BoxNumber7.Size = new System.Drawing.Size(29, 30);
            this.BoxNumber7.TabIndex = 4;
            // 
            // BoxNumber6
            // 
            this.BoxNumber6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoxNumber6.Location = new System.Drawing.Point(289, 28);
            this.BoxNumber6.Name = "BoxNumber6";
            this.BoxNumber6.Size = new System.Drawing.Size(29, 30);
            this.BoxNumber6.TabIndex = 5;
            // 
            // BoxNumber5
            // 
            this.BoxNumber5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoxNumber5.Location = new System.Drawing.Point(254, 28);
            this.BoxNumber5.Name = "BoxNumber5";
            this.BoxNumber5.Size = new System.Drawing.Size(29, 30);
            this.BoxNumber5.TabIndex = 6;
            // 
            // BoxNumber3
            // 
            this.BoxNumber3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoxNumber3.Location = new System.Drawing.Point(149, 28);
            this.BoxNumber3.Name = "BoxNumber3";
            this.BoxNumber3.Size = new System.Drawing.Size(29, 30);
            this.BoxNumber3.TabIndex = 7;
            // 
            // BoxNumber2
            // 
            this.BoxNumber2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoxNumber2.Location = new System.Drawing.Point(114, 28);
            this.BoxNumber2.Name = "BoxNumber2";
            this.BoxNumber2.Size = new System.Drawing.Size(29, 30);
            this.BoxNumber2.TabIndex = 8;
            // 
            // BoxNumber4
            // 
            this.BoxNumber4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BoxNumber4.Location = new System.Drawing.Point(219, 28);
            this.BoxNumber4.Name = "BoxNumber4";
            this.BoxNumber4.Size = new System.Drawing.Size(29, 30);
            this.BoxNumber4.TabIndex = 9;
            // 
            // DisplayNumberCombosBox
            // 
            this.DisplayNumberCombosBox.FormattingEnabled = true;
            this.DisplayNumberCombosBox.ItemHeight = 16;
            this.DisplayNumberCombosBox.Location = new System.Drawing.Point(12, 152);
            this.DisplayNumberCombosBox.MultiColumn = true;
            this.DisplayNumberCombosBox.Name = "DisplayNumberCombosBox";
            this.DisplayNumberCombosBox.Size = new System.Drawing.Size(418, 580);
            this.DisplayNumberCombosBox.Sorted = true;
            this.DisplayNumberCombosBox.TabIndex = 10;
            // 
            // ErrorLabel
            // 
            this.ErrorLabel.ForeColor = System.Drawing.Color.Red;
            this.ErrorLabel.Location = new System.Drawing.Point(12, 104);
            this.ErrorLabel.Name = "ErrorLabel";
            this.ErrorLabel.Size = new System.Drawing.Size(418, 45);
            this.ErrorLabel.TabIndex = 11;
            this.ErrorLabel.Text = "Error: ";
            this.ErrorLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // NumberLetterComboGenerator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(447, 744);
            this.Controls.Add(this.ErrorLabel);
            this.Controls.Add(this.DisplayNumberCombosBox);
            this.Controls.Add(this.BoxNumber4);
            this.Controls.Add(this.BoxNumber2);
            this.Controls.Add(this.BoxNumber3);
            this.Controls.Add(this.BoxNumber5);
            this.Controls.Add(this.BoxNumber6);
            this.Controls.Add(this.BoxNumber7);
            this.Controls.Add(this.BoxNumber8);
            this.Controls.Add(this.BoxNumber1);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.ClearButton);
            this.Name = "NumberLetterComboGenerator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.Button SubmitButton;
        private System.Windows.Forms.TextBox BoxNumber1;
        private System.Windows.Forms.TextBox BoxNumber8;
        private System.Windows.Forms.TextBox BoxNumber7;
        private System.Windows.Forms.TextBox BoxNumber6;
        private System.Windows.Forms.TextBox BoxNumber5;
        private System.Windows.Forms.TextBox BoxNumber3;
        private System.Windows.Forms.TextBox BoxNumber2;
        private System.Windows.Forms.TextBox BoxNumber4;
        private System.Windows.Forms.ListBox DisplayNumberCombosBox;
        private System.Windows.Forms.Label ErrorLabel;
    }
}

