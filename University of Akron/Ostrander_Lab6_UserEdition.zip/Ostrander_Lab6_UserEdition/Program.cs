﻿//This version of the program uses user input for the numbers and returns basic math results to user

using Ostrander_Lab6_UserEdition;

Random numbers = new Random();
Rational calculateValues;
int num1;
int num2;
string input;
bool userContinues = true;
int attempts = 0; //Closes program if fails to enter valid input. In case of keyboard issues

while(userContinues == true)
{
    Console.WriteLine("Please enter the first number or type exit to quit the program: ");
    input = Console.ReadLine();

    if(input == "exit" || input == "Exit" || input == "EXIT")
    {
        Console.WriteLine("Closing program. Thank you and have a good day!");
        userContinues = false;
    }
    else if(attempts > 5)
    {
        Console.WriteLine("Too many failed attempts to enter valid input. Closing program.");
        userContinues = false;
    }
    else if(input != "exit" || input != "Exit" || input != "EXIT")
    {
        try
        {
            num1 = int.Parse(input);
            Console.WriteLine("Please enter the second number: ");
            num2 = int.Parse(Console.ReadLine());

            Console.WriteLine($"The values generated are: {num1} and {num2}");

            if(num1 < 0 || num2 <= 0) //If 1st number is negative or if 2nd number is less than or equal to zero
            {
                throw new Exception();
            }
            else
            {
                calculateValues = new Rational(num1, num2);
                calculateValues.Add();
                calculateValues.Subtract();
                calculateValues.Multiply();
                calculateValues.Divide();
                Console.WriteLine(); //Adds space between attempts
            }
        }
        catch
        {
            Console.WriteLine("Invalid. Values must be positive integers and Denominator must be a nonzero integer.\n" +
                "Please try again.\n");
            attempts++;
        }
    }

}

Console.ReadLine(); //Keeps program open so people can actually read output.