﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Class assumes that denominator <= 0 has already been checked and rejected before calling any of these methods.
//In other words, denominator is never assigned <= 0 value.

namespace Ostrander_Lab6_UserEdition
{
    internal class Rational
    {
        private int numerator;
        private int denominator;

        public Rational (int n, int d)
        {
            numerator = n;
            denominator = d;
        }

        public void Add()
        {
            int num = numerator + denominator;
            Console.WriteLine($"Added: {numerator} + {denominator} = {num}");
        }

        public void Subtract() //Covers both ways of subtracting values should user not put values in correct order originally
        {
            int option1 = numerator - denominator;
            int option2 = denominator - numerator;

            Console.WriteLine("The values can be subtracted in two ways:\n" +
                $"{numerator} - {denominator} = {option1}\n" +
                $"{denominator} - {numerator} = {option2}");
        }

        public void Multiply()
        {
            int num = numerator * denominator;
            Console.WriteLine($"Multiplied: {numerator} * {denominator} = {num}");
        }


        public void Divide()
        {
            //Need to call the Reduce method for this one - for showing fraction in smallest/simpliest form.
            double result= (double)numerator / (double)denominator;
            string fraction = Reduce();

            Console.WriteLine($"When divided we get:\n" +
                $"Decimal: {result}\n" +
                $"Reduced Fraction: {fraction}");
        }


        public string Reduce()
        {
            bool simplified = false;
            int num = numerator;
            int den = denominator;

            while (simplified == false)
            {
                if(num == 1 || den == 1)
                {
                    simplified = true; //Cannot reduce 1 further, finish loop
                }
                else if(num % den == 0) //requires testing
                {
                    num = num / den;
                    den = den / den;
                }
                else if(den % num == 0) //requires testing
                {
                    den = den / num;
                    num = num / num;
                }
                else if(num % 2 == 0 & den % 2 == 0) //Covers all even values
                {
                    num = num / 2;
                    den = den / 2;
                }
                else if(num % 3 == 0 & den % 3 == 0) //Covers 3, 6, 9 ....
                {
                    num = num / 3;
                    den = den / 3;
                }
                else if(num % 5 == 0 & den % 5 == 0) //Covers 5, 10 ....
                {
                    num = num / 5;
                    den = den / 5;
                }
                else if(num % 7 == 0 & den % 7 == 0) //Covers 7, 14, ...
                {
                    num = num / 7;
                    den = den / 7;
                }
                else
                {
                    simplified = true; //Values have nothing left in common and cannot be reduced further
                }

            }

            return $"{num}/{den}";
        }

    }
}
