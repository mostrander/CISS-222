﻿//Create an empty array to hold 5 unique values, between numbers 10 - 100 inclusive.
using Ostrander_Lab7_DuplicateElimination;

UniqueNumberArray arrayManagement = new UniqueNumberArray();
int[] uniqueNum = new int[5];
string input;
bool verified;
int index = 0; //Used to track current valid values inserted since array values default to 0.

Console.WriteLine("Welcome! This program will evaluate integer numbers you input and " +
    "discard any duplicates until 5 unique values have been entered.");

while(index < uniqueNum.Length)
{
    Console.WriteLine("\nPlease enter an integer value between 10 - 100.");
    input = Console.ReadLine();

    verified = arrayManagement.VerifyEntry(input);

    if(verified == true)
    {
        arrayManagement.CheckArrayNum(uniqueNum);
        index = arrayManagement.UpdateIndex();
    }
}

Console.WriteLine("\nHere is the final list of unique integers you have entered:");
arrayManagement.DisplayArray(uniqueNum);