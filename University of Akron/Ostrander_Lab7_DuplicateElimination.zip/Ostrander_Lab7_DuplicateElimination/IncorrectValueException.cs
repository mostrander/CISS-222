﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab7_DuplicateElimination
{
    internal class IncorrectValueException : Exception
    {
        public IncorrectValueException() { }

        public IncorrectValueException(string message)
            : base(String.Format(message)) { }

        public IncorrectValueException(string message, string number)
            : base(String.Format(message + number)) { }
    }
}