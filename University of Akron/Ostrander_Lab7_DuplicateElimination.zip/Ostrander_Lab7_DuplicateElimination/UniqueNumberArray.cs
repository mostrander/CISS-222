﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab7_DuplicateElimination
{
    internal class UniqueNumberArray
    {
        //Class is just for checking there is no duplicates in array
        //Thus, empty class constructor

        private int index = 0; //Tracks current place in array for inserting new unique values
        private int entered;

        public UniqueNumberArray() { }

        public void CheckArrayNum(int [] numbers)
        {
            bool duplicate = false;

            try
            {
                for(int a = 0; a < numbers.Length; a++)
                {
                    if(numbers[a] == entered)
                    {
                        duplicate = true; //Duplicate found, terminate loop. Do not print number
                        a = 1 + numbers.Length; //Sets loop iteration so it ends loop
                        throw new IncorrectValueException("\nOops! The number you entered is a duplicate: ", entered.ToString());
                    }
                    else if(a == (numbers.Length -1) && duplicate == false)
                    {
                        numbers[index] = entered; //insert new unique value
                        index++;

                        Console.WriteLine($"\nNew value added: {entered}");
                    }
                }
            }
            catch (IncorrectValueException ex)
            {
                Console.WriteLine(ex.Message);
            }

            //Display entire list of unique values entered thus far
            DisplayArray(numbers);
        }

        public void DisplayArray(int [] numbers)
        {
            Console.WriteLine("Here is the current list of unique values you have entered: ");

            for(int a = 0; a < index; a++)
            {
                Console.WriteLine(numbers[a]);
            }
        }


        public bool VerifyEntry(string value)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    //Throw error if input is blank or nothing but spaces.
                    throw new IncorrectValueException("Invalid. Nothing was entered.");
                }
                else if(int.Parse(value) < 10 || int.Parse(value) > 100)
                {
                    //Throw error if value is not between 10 - 100.
                    throw new IncorrectValueException("Invalid. The following value is not between 10 - 100: ",value);
                }
                else
                {
                    entered = int.Parse(value);
                    return true;
                }

            }
            catch (IncorrectValueException ex)
            {
                Console.WriteLine(ex.Message );
                return false;
            }
            catch
            {
                //Error message for instances where non integer values or non numeric values are entered
                Console.WriteLine("Invalid. The entry is not an integer value.");
                return false;
            }
        }

        public int UpdateIndex()
        {
            return index;
        }

    }
}
