﻿// Fig. 23.1: FibonacciForm.cs
// Performing a compute-intensive calculation from a GUI app
using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FactorialTest
{
   public partial class FibonacciForm : Form
   {
        private long n1 = 1; // initialize with first factorial number
        private int count = 1; // current factorial number to display
        private long currentResult;

      public FibonacciForm()
      {
         InitializeComponent();
      }

      // start an async Task to calculate specified Fibonacci number
      private async void calculateButton_Click(object sender, EventArgs e)
      {
         // retrieve user's input as an integer
         int number = int.Parse(inputTextBox.Text);

         asyncResultLabel.Text = "Calculating...";

         // Task to perform Factorial calculation in separate thread
         currentResult = number; //set to the beginning number for the factorial
         Task<long> factorialTask = Task.Run(() => Factorial(number));

         // wait for Task in separate thread to complete
         await factorialTask;

         // display result after Task in separate thread completes
         asyncResultLabel.Text = factorialTask.Result.ToString();
      }

        //Factorial version of nextNumberButton_Click1
        private void nextNumberButton_Click(object sender, EventArgs e)
        {
            //Formula: n! = n * (n-1)!
            long temp;
            long factorialNum;

            //Calculate the factorial for the next number, NOTE 0! == 1
            if (n1 == 0 || (n1 - 1) == 0)
            {
                currentResult = 1;
            }
            else
            {
                temp = n1; //Store the number that starts the factorial, AKA n!
                factorialNum = temp - 1; //Determine what (n-1)! will be
                currentResult = temp * factorialNum;
                temp--;


                while (temp > 1)
                {
                    factorialNum = temp - 1; //Determine what (n-1)! will be
                    currentResult = currentResult * factorialNum;

                    temp--;
                }

            }

            // display the next Fibonacci number
            displayLabel.Text = $"Factorial of {count}:";
            syncResultLabel.Text = currentResult.ToString();

            //When complete, increase count and n1 for next number
            n1++;
            count++;

        }

        // recursive method Fibonacci; calculates nth Fibonacci number
        public long Factorial(long n)
        {
            if(n == 0 || n == 1)
            {
                return 1;
            }
            else
            {
                currentResult = currentResult * (n - 1);
                Factorial(n - 1);
                return currentResult;
            }
         
        }
   }
}


/*************************************************************************
* (C) Copyright 1992-2017 by Deitel & Associates, Inc. and               *
* Pearson Education, Inc. All Rights Reserved.                           *
*                                                                        *
* DISCLAIMER: The authors and publisher of this book have used their     *
* best efforts in preparing the book. These efforts include the          *
* development, research, and testing of the theories and programs        *
* to determine their effectiveness. The authors and publisher make       *
* no warranty of any kind, expressed or implied, with regard to these    *
* programs or to the documentation contained in these books. The authors *
* and publisher shall not be liable in any event for incidental or       *
* consequential damages in connection with, or arising out of, the       *
* furnishing, performance, or use of these programs.                     *
*************************************************************************/
