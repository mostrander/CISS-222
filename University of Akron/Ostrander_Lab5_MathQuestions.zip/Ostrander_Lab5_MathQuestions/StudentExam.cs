﻿// Project that produces two randomly generated single digit numbers for multiplication questions
// and grades student based on number of attempts (questions/attempts) - infinite questions until quit

using Ostrander_Lab5_MathQuestions;

MathExam mathTest = new MathExam();
bool testing = true;

while(testing == true) //just keeps program running while in use. Methods will terminate as needed
{
    mathTest.GenerateQuestion();
}