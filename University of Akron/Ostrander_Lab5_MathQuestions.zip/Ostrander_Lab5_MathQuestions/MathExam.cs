﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab5_MathQuestions
{
    internal class MathExam
    {
        private int attempts; //Stores number of attempts during exam for all questions
        private int questionsGenerated; //Tracks number of questions student has answered
        Random random = new Random();
        int digitOne;
        int digitTwo;

        public MathExam()
        {
            Console.WriteLine("Welcome to your math exam! Let's get started.\n");
            attempts = 0;
            questionsGenerated = 0;
        }

        public void GenerateQuestion()
        {
            digitOne = random.Next(10); //generates random digits 0 - 9 for two numbers
            digitTwo = random.Next(10);
            int failedAttempts = 0; //prevents loop if nothing is entered.
            bool correctResponse = false;

            //Console.WriteLine($"Digit 1: {digitOne} and Digit 2: {digitTwo}"); //for testing
            //Console.WriteLine("Please enter the answer or type 'quit' at any time to stop: ");
            string entered;

            while (correctResponse == false) //Prevents new question generation until current is answered correctly
            {
                Console.WriteLine($"Digit 1: {digitOne} and Digit 2: {digitTwo}"); //for testing
                Console.WriteLine("Please enter the answer or type 'quit' at any time to stop: ");
                entered = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(entered)) 
                {
                    Console.WriteLine("You did not enter a response. Please try again.");
                    failedAttempts++;

                    if(failedAttempts > 2)
                    {
                        Console.WriteLine("\nToo many failed attempts while entering response. " +
                            "Please check your keyboard before retrying.\n" +
                            "Closing the program now.");
                        System.Environment.Exit(0); //terminates program due to too many failed attempts
                    }
                }
                else if(entered == "quit" || entered == "Quit" || entered == "QUIT")
                {
                    if(attempts > 0)
                    {
                        double score = ((double)questionsGenerated / (double)attempts);
                        Console.WriteLine($"\nQuiting the program. Your score is: {score:P}\n" +
                        $"Press any key to leave the program.");
                    }
                    else
                    {
                        Console.WriteLine($"\nQuiting the program. Press any key to leave the program.");
                    }

                    Console.ReadLine(); //Pauses program so user can read score.
                    System.Environment.Exit(0); //terminates program
                }
                else
                {
                    correctResponse = VerifyValidResponse(entered); //send response to next method
                }
            }

            questionsGenerated++; //increase number of questions generated, does not count current question if quit
        }


        private bool VerifyValidResponse(string entered)
        {

            try
            {
                int response = int.Parse(entered); //Attempt to parse out int value

                if (response < 0) //This program is not using negative numbers, so should never have negative answer
                {
                    Console.WriteLine("Both values are positive. It is not possible to have a negative result.");
                    throw new Exception();
                }
                else
                {
                    attempts++; //increase number of valid attempts
                    return VerifyAnswer(response); //send valid response to next method
                }
            }
            catch
            {
                Console.WriteLine("Incorrect input has been entered. Please try again.");
                return false;
            }

        }


        private bool VerifyAnswer(int response)
        { //Method assumes answer is verified as valid BEFORE invoking method
            int answer = digitOne * digitTwo; //Calculates what the correct answer is
            int selectResponse = random.Next(4); //Select a random number between 0 - 4 for response to user

            if(answer == response)
            {
                switch (selectResponse)
                {
                    case 0:
                        Console.WriteLine("Very Good!\n");
                        return true;
                    case 1:
                        Console.WriteLine("Excellent!\n");
                        return true;
                    case 2:
                        Console.WriteLine("Nice Work!\n");
                        return true;
                    case 3:
                        Console.WriteLine("Keep up the good work!\n");
                        return true;
                    default:
                        Console.WriteLine("Correct!\n");
                        return true;
                }
            }
            else
            {
                switch (selectResponse)
                {
                    case 0:
                        Console.WriteLine("No. Please try again.\n");
                        return false;
                    case 1:
                        Console.WriteLine("Wrong. Try once more.\n");
                        return false;
                    case 2:
                        Console.WriteLine("Don't Give up!\n");
                        return false;
                    case 3:
                        Console.WriteLine("No. Keep trying.\n");
                        return false;
                    default:
                        Console.WriteLine($"Wrong. You've got this!\n");
                        return false;
                }
            }

        }

    }//end of class
}
