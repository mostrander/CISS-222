﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab4_HeartBeat
{
    internal class HeartRates
    {
        private string firstName;
        private string lastName;
        private int yearBorn;
        private int currentYear;

        public HeartRates(string fName, string lName, int born, int current)
        {
            firstName = fName;
            lastName = lName;
            yearBorn = born;
            currentYear = current;
        }

        public void SetFirstName()
        {
            Console.WriteLine("Please enter the first name: ");
            string newName = Console.ReadLine();

            if(newName != firstName && !string.IsNullOrEmpty(newName))
            {
                firstName = newName;
                Console.WriteLine("First name is now set to: " + firstName);
            }
            else
            {
                Console.WriteLine("Unable to complete process. \nYou either did not enter a name, " +
                    "or the value is already stored as the individual's first name.");
            }
        }

        public string GetFirstName()
        {
            return firstName;
        }


        public void SetLastName()
        {
            Console.WriteLine("Please enter the last name: ");
            string newName = Console.ReadLine();

            if (newName != lastName && !string.IsNullOrEmpty(newName))
            {
                lastName = newName;
                Console.WriteLine("First name is now set to: " + lastName);
            }
            else
            {
                Console.WriteLine("Unable to complete process. \nYou either did not enter a name, " +
                    "or the value is already stored as the individual's first name.");
            }
        }

        public string GetLastName()
        {
            return lastName;
        }


        public void SetBirthYear()
        {
            int newYear = -1;
            try
            {
                Console.WriteLine("Please enter the year the individual was born in the following format: YYYY");
                newYear = int.Parse(Console.ReadLine()); //Must be an integer value

                if(newYear <= 0)
                {
                    Console.WriteLine("The value entered is invalid. The year must be a positive integer value.");
                    throw new Exception();
                }
                else if(newYear > currentYear)
                {
                    Console.WriteLine("The value entered is invalid." +
                        "\nIt is impossible to log information for someone who has not yet been born.");
                    throw new Exception();
                }

                yearBorn = newYear; //If value passes all checks, then set it as the new value for year individual was born
                Console.WriteLine($"The year born is now set to: {yearBorn}");
            }
            catch
            {
                if (newYear == -1)
                {
                    Console.WriteLine("You did not enter any information.");
                }
                Console.WriteLine("Please try again.");
            }
        }

        public int GetYearBorn()
        {
            return yearBorn;
        }


        public void SetCurrentYear() //need to add clause where year cannot be LESS THAN that of birth year
        {
            DateTime today = DateTime.Now; //Obtains current year from computer to ensure user is not entering future year
            int newYear = -1;

            try
            {
                Console.WriteLine("Please enter the current year in the following format: YYYY");
                newYear = int.Parse(Console.ReadLine()); //Must be an integer value

                if (newYear <= 0)
                {
                    Console.WriteLine("The value entered is invalid. The year must be a positive integer value.");
                    throw new Exception();
                }
                else if (newYear > today.Year) //compares entered value against PC current year
                {
                    Console.WriteLine($"Are you a time traveler?! We have not reached {newYear} yet!");
                    throw new Exception();
                }
                else if(newYear < yearBorn)
                {
                    Console.WriteLine("Invalid input. It is impossible to have a record prior to individual being born.");
                    throw new Exception();
                }

                currentYear = newYear; //If value passes all checks, then set it as the new value for year individual was born
                Console.WriteLine($"The current year is now set to: {currentYear}");
            }
            catch
            {
                if(newYear == -1) //User did not enter any values, so it remained as default
                {
                    Console.WriteLine("You did not enter any information.");
                }
                Console.WriteLine("Please try again.");
            }
        }

        public int GetCurrentYear()
        {
            return currentYear;
        }


        public int GetAge()
        {
            int age;
            age = currentYear - yearBorn;
            return age;
        }

        public int MaxHeartRate() //Determines max heartrate for an individual
        {
            int maxHeartRate;
            maxHeartRate = 220 - GetAge();
            return maxHeartRate;
        }

        public double TargetMinRate()
        {
            int targetMinRate;
            targetMinRate = (int)(MaxHeartRate() * .5); //I realize it will truncate the decimal value.
            return targetMinRate;
        }

        public double TargetMaxRate()
        {
            int targetMaxRate;
            targetMaxRate = (int)(MaxHeartRate() * .85);
            return targetMaxRate;
        }
    }
}
