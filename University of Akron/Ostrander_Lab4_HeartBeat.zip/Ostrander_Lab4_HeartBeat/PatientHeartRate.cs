﻿// See https://aka.ms/new-console-template for more information
using Ostrander_Lab4_HeartBeat;

bool problem = true; //Assumes that an exception will be encountered
int attempts = 0; //logs 3 attempts before shutting down the program.

//Variables to store information, done this way so I can check when individuals do not enter ANY information
string fname = null;
string lname = null;
int yearBorn = -1;

//Use a while loop to keep the program running should errors occur
while(problem == true)
{
    try
    {
        //Obtain information required to create patient record
        Console.WriteLine("What is your first name?");
        fname = Console.ReadLine();

        Console.WriteLine("What is you last name?");
        lname = Console.ReadLine();

        Console.WriteLine("What year were you born?");
        yearBorn = int.Parse(Console.ReadLine());

        //Identify any specific issues. 
        if (string.IsNullOrWhiteSpace(fname))
        {
            Console.WriteLine("Invalid input. You did not enter your first name.");
            attempts++;
            throw new Exception();
        }
        else if (string.IsNullOrWhiteSpace(lname))
        {
            Console.WriteLine("Invalid input. You did not enter your last name.");
            attempts++;
            throw new Exception();
        }
        else if(yearBorn < 0)
        {
            Console.WriteLine("Invalid input. You must enter a positive integer for the year you were born.");
            attempts++;
            throw new Exception();
        }

        //Obtain the current year from the console(PC)
        DateTime today = DateTime.Now;

        //If successful, creates patient object to store & print information
        HeartRates patient = new HeartRates(fname, lname, yearBorn, today.Year);

        Console.WriteLine("\nYour information in the system is as follows:\n" +
             $"First name: {patient.GetFirstName()}\n" +
             $"Last name: {patient.GetLastName()}\n" +
             $"Year born: {patient.GetYearBorn()}\n" +
             $"Current Year: {patient.GetCurrentYear()}\n" +
             $"Age: {patient.GetAge()}\n\n" +
             $"Maximum heart rate: {patient.MaxHeartRate()}\n" +
             $"Max target rate: {patient.TargetMaxRate()}\n" +
             $"Min target rate: {patient.TargetMinRate()}\n");

        problem = false; //tells main loop to end.

        //Menu & loop for updating information in patient record
        string userResponse;

        Console.WriteLine("Would you like to update any of this information Y/N?");
        userResponse = Console.ReadLine();

        if(userResponse == "N" || userResponse == "n")
        {
            Console.WriteLine("Closing program. Thank you and have a good day.");
            Console.ReadLine(); //Forces program to wait
            System.Environment.Exit(0);
        }
        if(string.IsNullOrWhiteSpace(userResponse) || (userResponse != "Y" && userResponse != "N" 
            && userResponse != "y" && userResponse != "n"))
        {
            Console.WriteLine("Invalid input. Closing program. Thank you.");
            Console.ReadLine(); //Forces program to wait
            System.Environment.Exit(0);
        }

        while(userResponse != "5" && userResponse != "N" && userResponse != "n")
        {
            Console.WriteLine("\nThe current information in the system is as follows:\n" +
             $"First name: {patient.GetFirstName()}\n" +
             $"Last name: {patient.GetLastName()}\n" +
             $"Year born: {patient.GetYearBorn()}\n" +
             $"Current Year: {patient.GetCurrentYear()}\n" +
             $"Age: {patient.GetAge()}\n\n" +
             $"Maximum heart rate: {patient.MaxHeartRate()}\n" +
             $"Max target rate: {patient.TargetMaxRate()}\n" +
             $"Min target rate: {patient.TargetMinRate()}\n");

            //Menu for selecting which options to change
            Console.WriteLine("Would you like to change the...?\n" +
                "(Please enter only the number of the item you wish to change.)\n" +
                "1) First Name\n" +
                "2) Last Name\n" +
                "3) Year Born\n" +
                "4) Current Year\n" +
                "5) Exit program");
            userResponse = Console.ReadLine();

            switch (userResponse)
            {
                case "1":
                    patient.SetFirstName();
                    break;
                case "2":
                    patient.SetLastName();
                    break;
                case "3":
                    patient.SetBirthYear();
                    break;
                case "4":
                    patient.SetCurrentYear();
                    break;
                case "5":
                    Console.WriteLine("Closing the program. Have a good day.");
                    break;
                default:
                    Console.WriteLine("Invalid response. Please enter the number of the action you wish to take.");
                    break;
            }  

            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
            Console.Clear();
        } //end of inner loop statement for patient record modifications

        System.Environment.Exit(0); //closes program
    }
    catch
    {
        //If inputs are empty or if left at default values, then inform user of mistake.
        if (string.IsNullOrWhiteSpace(fname) && string.IsNullOrWhiteSpace(lname) && yearBorn == -1)
        {
            Console.WriteLine("You did not enter any information.");
            attempts++;
        }

        if(attempts > 2) //If exceeds 3 attempts, end program
        {
            Console.WriteLine("Too many failed attempts. Closing program.");
            System.Environment.Exit(0); //closes program
        }
        else
        {
            Console.WriteLine("Please try again.");
        }

        Console.WriteLine("Press any key to continue.");
        Console.ReadLine();
        Console.Clear(); //Clears screen after each attempt to keep it looking clean
    }

} 