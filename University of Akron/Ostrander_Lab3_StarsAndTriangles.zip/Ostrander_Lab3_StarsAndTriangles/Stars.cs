﻿// See https://aka.ms/new-console-template for more information
//Stars.cs is a program that outputs rows of 10 stars in order of increasing or desreasing quantity, in 4 different ways.

int k = 0;
int j = 0;

for (int i = 0; i < 10; i++)
{
    k = 0;
    while (k <= i) //While k is less than or equal to i, output a star to the current line
    {
        Console.Write("*");
        k++;
    }
    Console.WriteLine();
}
Console.WriteLine(); //Go to next line (create a space between groups of stars)

for (int i = 9; i >= 0; i--)
{
    k = 0;
    while (k <= i)
    {
        Console.Write("*");
        k++;
    }
    Console.WriteLine();
}
Console.WriteLine();

k = 0;
int d = 0; //Needed to decrease value of k for spaces before star symbols, without causing an infinite loop

for (int i = 9; i >= 0; i--)
{
    j = i;
    if(k > 0)
    {
        d = k;
        while (d > 0)
        {
            Console.Write(" ");
            d--;
        }
    }
    while (j >= 0)
    {
        Console.Write("*");
        j--;
    }
    k++;
    Console.WriteLine();
}
Console.WriteLine();


k = 9;
for (int i = 0; i <= 9; i++)
{
    j = i;
    if (k > 0)
    {
        d = k;
        while (d > 0)
        {
            Console.Write(" ");
            d--;
        }
    }
    while (j >= 0)
    {
        Console.Write("*");
        j--;
    }
    k--;
    Console.WriteLine();
}

