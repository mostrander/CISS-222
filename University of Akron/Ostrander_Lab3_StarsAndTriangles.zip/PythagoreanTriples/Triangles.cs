﻿// See https://aka.ms/new-console-template for more information
//This project is for summing the squares of two sides of a triangle and comparing it to the square of the third triangle side.
//All sides must be integers, and to be a pythagorean triple sides 1 and 2 must equal side 3 (hypotenuse).
//Triples are generated when a(sqaured) + b(squared) = c(sqaured)


double x = 0; // Used later to hold value of (a*a) + (b*b)
bool found = false; 
Console.WriteLine("The following are all possible pythagorean triples up to the number 500 for all sides.\n");

for(int a = 1; a <= 500; a++)
{
    for(int b = 1; b <= 500; b++)
    {
        for(int c = 1; c <= 500; c++)
        {
            x = Math.Pow(a,2) + Math.Pow(b,2);
            if(Math.Pow(c,2) == x)
            {
                Console.WriteLine($"({a},{b},{c})");
                found = true; //Combo that meets requirements has been found
            }
        }
    }
    if(found == true)
    {
        Console.WriteLine(); //Will separate the different combinations per side a value for easier reading.
        found = false; //Reset so new line is not generated EVERY time we go to a new a value, unless a combo is found
    }

}