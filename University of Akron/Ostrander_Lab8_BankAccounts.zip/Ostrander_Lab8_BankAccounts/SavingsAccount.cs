﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab8_BankAccounts
{
    internal class SavingsAccount : Account
    {
        //Enter the decimal % of rate. I.e., if it is 10%, then enter 0.1
        private decimal interestRate;

        //Initalizes account with default balance & internest rate
        public SavingsAccount() : base()
        {
            interestRate = defaultRate;
        }

        //Initializes account with entered balance, but default interest rate.
        public SavingsAccount(decimal initialBalance) : base(initialBalance)
        {
            interestRate = defaultRate;
        }

        //Initializes account with specified balance & specified interest rate
        public SavingsAccount(decimal initialBalance, decimal rate) 
            :base(initialBalance)
        {
            try
            {
                if(rate < 0)
                {
                    throw new Exception();
                }
                else
                {
                    interestRate = rate;
                }
            }
            catch
            {
                if(rate < 0)
                {
                    Console.WriteLine("Error: The interest rate cannot be below 0.\n");
                    interestRate = defaultRate;
                }
            }
        }

        public decimal CalculateInterest()
        {
            decimal earned = balance * interestRate;
            Credit(earned); //Add the earned interest to account
            return earned;
        }


        public override void Testing()
        {
            Console.WriteLine($"Balance is: {balance:C}\n" +
                $"Default rate is: {defaultRate}\n" +
                $"Default fee is: {defaultTransactionFee:C}\n" +
                $"Interest rate is set to: {interestRate}\n");
        }



    }
}
