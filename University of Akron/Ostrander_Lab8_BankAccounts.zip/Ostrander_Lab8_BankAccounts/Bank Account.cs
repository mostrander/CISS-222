﻿using Ostrander_Lab8_BankAccounts;
//Tests of the base class Account
Console.WriteLine("This application runs various tests by creating objects for the Account, SavingsAccount, and CheckingAccount classes.\n" +
    "It then outputs the values stored in each object.\n" +
    "There are additional tests regarding the debit & credit methods for savingsAccount3 and checking4 accounts.\n");

//Create default Account
Console.WriteLine("Testing the basic Account creation.");
Account basic = new Account();
basic.Testing();
Console.WriteLine();

//Create account with initial balance
Console.WriteLine("Testing the basic Account creation with specified negative balance.");
Account basicBalance = new Account(-21);
Console.WriteLine("Testing the basic Account creation with specified balance. Attempt 2 with acceptable input.");
Account basicBalance2 = new Account((decimal)253.74);
basicBalance2.Testing();


Console.WriteLine("Testing Savings Account creation 1: Default values.");
SavingsAccount savingsAccount = new SavingsAccount();
savingsAccount.Testing();
Console.WriteLine($"Interest earned on this account is: {savingsAccount.CalculateInterest():C}");
Console.WriteLine($"The new balance is: {savingsAccount.GetBalance():C}\n");

Console.WriteLine("Testing Savings Account creation 2: With specified balance only.");
SavingsAccount savingsAccount2 = new SavingsAccount((decimal)69.24);
savingsAccount2.Testing();
Console.WriteLine($"Interest earned on this account is: {savingsAccount2.CalculateInterest():C}");
Console.WriteLine($"The new balance is: {savingsAccount2.GetBalance():C}\n");


Console.WriteLine("Testing Savings Account creation 3: With specified balance & interest rate.");
SavingsAccount savingsAccount3 = new SavingsAccount((decimal)100, (decimal).35);
savingsAccount3.Testing();
Console.WriteLine($"Interest earned on this account is: {savingsAccount3.CalculateInterest():C}");
Console.WriteLine($"The new balance is: {savingsAccount3.GetBalance():C}\n");

Console.WriteLine("Now testing the Debit and Credit methods for savingsAccount3:");
savingsAccount3.Debit((decimal)67.19);
Console.WriteLine($"The new balance is: {savingsAccount3.GetBalance():C}\n");
savingsAccount3.Credit((decimal)13.33);
Console.WriteLine($"The new balance is: {savingsAccount3.GetBalance():C}\n");
Console.WriteLine($"Interest earned on this account is: {savingsAccount3.CalculateInterest():C}");
Console.WriteLine($"The new balance is: {savingsAccount3.GetBalance():C}\n");


Console.WriteLine("Testing Savings Account creation 4: With specified balance & failed interest rate.");
SavingsAccount savingsAccount4 = new SavingsAccount(65, (decimal)-3);
savingsAccount4.Testing();


Console.WriteLine("Testing Checking Account creation 1: Default values.");
CheckingAccount checking1 = new CheckingAccount();
checking1.Testing();

Console.WriteLine("Testing Checking Account creation 2: With specified negative balance only.");
CheckingAccount checking2 = new CheckingAccount(-325);
checking2.Testing();

Console.WriteLine("Testing Checking Account creation 3: With specified balance & transaction fee.");
CheckingAccount checking3 = new CheckingAccount(65, (decimal)6.32);
checking3.Testing();

Console.WriteLine("Testing Checking Account creation 4: With specified balance & failed transaction fee.");
CheckingAccount checking4 = new CheckingAccount(65, (decimal)-3);
checking4.Testing();


Console.WriteLine("\nNow, testing debit and credit methods for checking4 account.");
Console.WriteLine("Debit method: ");
checking3.Debit((decimal)64643);
Console.WriteLine($"The new balance is: {checking3.GetBalance():C}\n");
checking3.Debit((decimal)64);
Console.WriteLine($"The new balance is: {checking3.GetBalance():C}\n");

Console.WriteLine("Credit method: ");
checking3.Credit((decimal)-35.2);
Console.WriteLine($"The new balance is: {checking3.GetBalance():C}\n");
checking3.Credit((decimal)21.86);
Console.WriteLine($"The new balance is: {checking3.GetBalance():C}\n");
