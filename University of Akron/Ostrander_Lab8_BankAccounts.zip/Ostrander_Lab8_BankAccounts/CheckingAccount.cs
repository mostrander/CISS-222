﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab8_BankAccounts
{
    internal class CheckingAccount : Account
    {
        private decimal transactionFee; //Fee charged per transaction

        //Initializes account with default balance and fee rate for transactions.
        public CheckingAccount() : base()
        {
            transactionFee = defaultTransactionFee;
        }

        //Initializes account with specified balance and default fee rate for transactions
        public CheckingAccount(decimal initialBalance) : base(initialBalance)
        {
            transactionFee = defaultTransactionFee;
        }

        //Initializes account with specified balance & transaction fee
        public CheckingAccount(decimal initialBalance, decimal fee) : base(initialBalance)
        {
            try
            {
                if (fee < 0)
                {
                    throw new Exception();
                }
                else
                {
                    transactionFee = fee;
                }
            }
            catch
            {
                Console.WriteLine("Error: Transaction fee cannot be below 0.\n");
                transactionFee = defaultTransactionFee;
            }
        }

        public override decimal Credit(decimal deposit)
        {
            try
            {
                if (deposit < 0)
                {
                    throw new Exception();
                }
                else
                {
                    Console.WriteLine($"Depositing {deposit} to the account...");
                    balance = balance + deposit;
                    FeeCharged(); //Charge fee for successful transaction.
                }
            }
            catch
            {
                Console.WriteLine("Error: Unable to deposit negative dollar amount.\n");
            }

            return balance;
        }

        public override decimal Debit(decimal withdraw)
        {
            try
            {
                if (withdraw < 0 || withdraw > balance)
                {
                    throw new Exception();
                }
                else
                {
                    Console.WriteLine($"Withdrawing {withdraw} to the account...");
                    balance = balance - withdraw;
                    FeeCharged(); //Charge fee for successful transaction.
                }
            }
            catch
            {
                if (withdraw < 0)
                {
                    Console.WriteLine("Error: Unable to deposit negative dollar amount.\n");
                }
                if (withdraw > balance)
                {
                    Console.WriteLine($"Error: Debit amount ({withdraw:C}) exceeded account balance.\n");
                } 
            }

            return balance;
        }

        private void FeeCharged()
        {
            Console.WriteLine("Charging transaction fee...");
            balance = balance - transactionFee;
        }


        public override void Testing()
        {
            Console.WriteLine($"Balance is: {balance:C}\n" +
                $"Default rate is: {defaultRate}\n" +
                $"Default fee is: {defaultTransactionFee:C}\n" +
                $"Transaction fee is set to: {transactionFee:C}\n");
        }


    }
}
