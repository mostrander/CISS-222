﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ostrander_Lab8_BankAccounts
{
    internal class Account
    {
        protected decimal balance; //protected so inheritance can use same variable
        protected decimal defaultRate = (decimal)0.01; //Replace with bank default interest rate. For Savings Accounts.
        protected decimal defaultTransactionFee = (decimal)2.35; //Replace with bank default for fee charge. For Checking Accounts.

        //Default initalization of account with default balance of $0.00
        public Account()
        {
            balance = 0;
        }

        public Account(decimal initialBalance)
        {
            try
            {
                if (initialBalance < 0)
                {
                    throw new Exception();
                }
                else
                {
                    balance = initialBalance;
                }
            }
            catch
            {
                Console.WriteLine("Error: Unable to create account with a negative dollar amount.\n" +
                    "Initializing account with default values.\n");
            }
        }

        public virtual decimal Credit(decimal deposit)
        {
            try
            {
                if(deposit < 0)
                {
                    throw new Exception();
                }
                else
                {
                    Console.WriteLine($"Depositing {deposit:C} to the account...");
                    balance = balance + deposit;
                }
            }
            catch
            {
                Console.WriteLine("Error: Unable to deposit negative dollar amount.\n");
            }

            return balance;
        }

        public virtual decimal Debit(decimal withdraw)
        {
            try
            {
                if (withdraw < 0 || withdraw > balance)
                {
                    throw new Exception();
                }
                else
                {
                    Console.WriteLine($"Withdrawing {withdraw:C} to the account...");
                    balance = balance - withdraw;
                }
            }
            catch
            {
                if(withdraw < 0)
                {
                    Console.WriteLine("Error: Unable to deposit negative dollar amount.\n");
                }
                if(withdraw > balance)
                {
                    Console.WriteLine("Error: Debit amount exceeded account balance.\n");
                }
;
            }

            return balance;
        }

        public decimal GetBalance()
        {
            return balance;
        }


        public virtual void Testing()
        {
            Console.WriteLine($"Balance is: {balance:C}\n" +
                $"Default rate is: {defaultRate}\n" +
                $"Default fee is: {defaultTransactionFee:C}\n");
        }

    }
}
