# CISS222 Spring 2021 - Homework 5

## Purpose
The purpose of this assignment is to continue using arithmetic as well as equality operations in order to provide output based on user input.

## Objective
Write a console application that inputs five (5) integers from the user. Based on the input, determines and clearly displays the:

* Sum
* Average (mean) - this should be of type double
* Product
* Smallest number
* Largest numbers
* Count of negative integers input
* Count of positive integers input
* Count of zeros input

For example:

![](screenshot1.png)

## Additional Notes

* Similar to the previous homework assignment, you will need to implement the logic in the supplied class - in this case, `Arithmetic.cs`. The computation logic should not be in the `Main.cs` class.

## Expectations and Grading
1. (9 pts) Add user input and console output based on the above objectives.
1. (1 pt) Add comments to the Program.cs and Arithmetic.cs classes, as well as each of the eight (8) methods, and any logic that would not be obvious on first glance.

## Assignment Retrieval, Testing, and Submission
1. Pull down this repository from GitHub to your local machine and open the solution in Visual Studio.
1. There are unit tests provided in the solution to verify your logic is correct. These unit tests will be used for grading, and while they are not a substitute for manually testing your application, they can be useful in validating your arithmetic is correct. If you wish, you can add additional tests or test scenarios, but do not modify the existing tests. [How to run unit tests in Visual Studio](https://docs.microsoft.com/en-us/visualstudio/test/run-unit-tests-with-test-explorer?view=vs-2019)
1. You can check in your work, as well as push to GitHub, as infrequently or as often as you wish. However, you must ensure that your work is checked in and pushed, as that will be how your assignment is turned in. The code as of the due date and time will be the version that will be graded.
