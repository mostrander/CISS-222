﻿using System;

namespace Homework5
{
    public static class Arithmetic
    {
        public static int Sum(int numberOne, int numberTwo, int numberThree, int numberFour, int numberFive)
        {
            int result = numberOne + numberTwo + numberThree + numberFour + numberFive;
            return result;
        }

        public static double Average(int numberOne, int numberTwo, int numberThree, int numberFour, int numberFive)
        {
            //This really should produce a decimal value, so there should be a cast for dividing by 5. 
            double result = (numberOne + numberTwo + numberThree + numberFour + numberFive) / (double)5;
            return result;
        }

        public static int Product(int numberOne, int numberTwo, int numberThree, int numberFour, int numberFive)
        {
            int result = numberOne * numberTwo * numberThree * numberFour * numberFive;
            return result;
        }

        public static int SmallestNumber(int numberOne, int numberTwo, int numberThree, int numberFour, int numberFive)
        {
            int smallest = numberOne;

            //Created an array to store the variables so comparing variables through a loop is easier, 
            //eliminates need for multiple if statments
            int[] numbers = new int[5];

            numbers[0] = numberOne;
            numbers[1] = numberTwo;
            numbers[2] = numberThree;
            numbers[3] = numberFour;
            numbers[4] = numberFive;

            int i = 0;

            while (i < 5)
               {
                  if( numbers[i] < smallest)
                  {
                     smallest = numbers[i];
                  }

                  i++;
               }

               return smallest;
        }

        public static int LargestNumber(int numberOne, int numberTwo, int numberThree, int numberFour, int numberFive)
        {
            int largest = numberOne;

            int[] numbers = new int[5];

            numbers[0] = numberOne;
            numbers[1] = numberTwo;
            numbers[2] = numberThree;
            numbers[3] = numberFour;
            numbers[4] = numberFive;

            int i = 0;

            while (i < 5)
               {
                  if (largest < numbers[i])
                  {
                     largest = numbers[i];
                  }

                  i++;
               }

            return largest;
         }

        public static int CountOfPositiveIntegers(int numberOne, int numberTwo, int numberThree, int numberFour, int numberFive)
        {
            int positiveNumbers = 0;

            int[] numbers = new int[5];

            numbers[0] = numberOne;
            numbers[1] = numberTwo;
            numbers[2] = numberThree;
            numbers[3] = numberFour;
            numbers[4] = numberFive;

            int i = 0;

            while (i < 5)
               {
                  if (numbers[i] > 0)
                  {
                     positiveNumbers++;
                  }

                  i++;
               }

            return positiveNumbers;
         }

        public static int CountOfNegativeIntegers(int numberOne, int numberTwo, int numberThree, int numberFour, int numberFive)
        {
            int negativeNumbers = 0;

            int[] numbers = new int[5];

            numbers[0] = numberOne;
            numbers[1] = numberTwo;
            numbers[2] = numberThree;
            numbers[3] = numberFour;
            numbers[4] = numberFive;

            int i = 0;

            while (i < 5)
               {
                  if (numbers[i] < 0)
                  {
                     negativeNumbers++;
                  }

                  i++;
               }

            return negativeNumbers;
         }

        public static int CountOfZeroes(int numberOne, int numberTwo, int numberThree, int numberFour, int numberFive)
        {
            int zeros = 0;

            int[] numbers = new int[5];

            numbers[0] = numberOne;
            numbers[1] = numberTwo;
            numbers[2] = numberThree;
            numbers[3] = numberFour;
            numbers[4] = numberFive;

            int i = 0;

            while (i < 5)
               {
                  if (numbers[i] == 0)
                  {
                     zeros++;
                  }

                  i++;
               }

            return zeros;
         }
    }
}
