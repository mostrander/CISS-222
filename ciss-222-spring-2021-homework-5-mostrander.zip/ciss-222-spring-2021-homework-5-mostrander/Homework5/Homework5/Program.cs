﻿using System;

namespace Homework5
{
    class Program
    {
        static void Main(string[] args)
        {
         int numberOne = 0;
         int numberTwo = 0;
         int numberThree = 0;
         int numberFour = 0;
         int numberFive = 0;

         bool validInput = false;

         //Will loop through the prompt to input information until user produces correct input.
         while (validInput == false)
         {
            try
            {
               Console.WriteLine("Enter the first integer: ");
               numberOne = int.Parse(Console.ReadLine());

               Console.WriteLine("Enter the second integer: ");
               numberTwo = int.Parse(Console.ReadLine());

               Console.WriteLine("Enter the third integer: ");
               numberThree = int.Parse(Console.ReadLine());

               Console.WriteLine("Enter the fourth integer: ");
               numberFour = int.Parse(Console.ReadLine());

               Console.WriteLine("Enter the fifth integer: ");
               numberFive = int.Parse(Console.ReadLine());

               validInput = true;
            }
            catch (Exception e)
            {
               Console.WriteLine("Incorrect Value. You must enter a positive or negative whole number.");
            }
         }

         //I chose to have the method calls within the writeline statements to save memory, thus eliminating the need for
         //additional variables and unnecessary lines of code.

         Console.WriteLine("The sum of the integers provided is " + Arithmetic.Sum(numberOne, numberTwo, numberThree, numberFour, numberFive));
         Console.WriteLine("The average of the integers provided is " + Arithmetic.Average(numberOne, numberTwo, numberThree, numberFour, numberFive));
         Console.WriteLine("The product of the integers provided is " + Arithmetic.Product(numberOne, numberTwo, numberThree, numberFour, numberFive));
         Console.WriteLine("The smallest of the integers provided is " + Arithmetic.SmallestNumber(numberOne, numberTwo, numberThree, numberFour, numberFive));
         Console.WriteLine("The largest of the integers provided is " + Arithmetic.LargestNumber(numberOne, numberTwo, numberThree, numberFour, numberFive));
         Console.WriteLine("The count of positive integers provided is " + Arithmetic.CountOfPositiveIntegers(numberOne, numberTwo, numberThree, numberFour, numberFive));
         Console.WriteLine("The count of negative integers provided is " + Arithmetic.CountOfNegativeIntegers(numberOne, numberTwo, numberThree, numberFour, numberFive));
         Console.WriteLine("The count of zeroes is " + Arithmetic.CountOfZeroes(numberOne, numberTwo, numberThree, numberFour, numberFive));
      }
    }
}
