using Xunit;

namespace CISS222_Homework3.Tests
{
    public class BasicArithmeticTests
    {
        [Theory]
        [InlineData(1, 1, 2)]
        [InlineData(2, 2, 4)]
        [InlineData(10, 20, 30)]
        [InlineData(5, -5, 0)]
        public void SumTests(int firstNumber, int secondNumber, int expected)
        {
            Assert.Equal(BasicArithmetic.Sum(firstNumber, secondNumber), expected);
        }

        [Theory]
        [InlineData(1, 1, 0)]
        [InlineData(2, 1, 1)]
        [InlineData(25, 10, 15)]
        [InlineData(5, -5, 10)]
        [InlineData(-5, -5, 0)]
        public void DifferenceTests(int firstNumber, int secondNumber, int expected)
        {
            Assert.Equal(BasicArithmetic.Difference(firstNumber, secondNumber), expected);
        }

        [Theory]
        [InlineData(1, 1, 1)]
        [InlineData(1, 0, 0)]
        [InlineData(5, 2, 10)]
        [InlineData(5, -5, -25)]
        [InlineData(4, 5, 20)]
        public void ProductTests(int firstNumber, int secondNumber, int expected)
        {
            Assert.Equal(BasicArithmetic.Product(firstNumber, secondNumber), expected);
        }

        [Theory]
        [InlineData(1, 1, "1r0")]
        [InlineData(0, 1, "0r0")]
        [InlineData(6, 2, "3r0")]
        [InlineData(8, 3, "2r2")]
        [InlineData(10, 4, "2r2")]       
        [InlineData(17, 7, "2r3")]
        [InlineData(29, 7, "4r1")]
        [InlineData(346, 7, "49r3")]
        public void QuotientWithRemainderTests(int firstNumber, int secondNumber, string expected)
        {
            Assert.Equal(BasicArithmetic.QuotientWithRemainder(firstNumber, secondNumber), expected);
        }
    }
}
