# CISS222 Spring 2021 - Homework 4

## Purpose
The purpose of this assignment is to allow you to become familiar with basic program flow by implementing a program that will perform basic arithmetic operations on two integers entered in by a user. 

## Objective
Write a console application that asks the user to enter two integers, obtains them from the user and then clearly a series of mathematical operations. 

As a reminder, 5 / 3 would give a quotient of 1 and a remainder of 2.

## Expectations and Grading
1. (3 pts) Add user input and console output based on the following screenshots *(NOTE: you must use the example notation of the quotient and remainder)*:
   1. ![](Screenshot1.PNG)
   1. ![](Screenshot2.PNG)
1. (4 pts) In each of the provided methods in the static `BasicArithmetic` class, implement the required functionality.
1. (1 pt) Implement one (1) additional mathematical operation.
   1. Choose one of the following:
      1. [Power/Exponent](https://www.mathsisfun.com/exponent.html)
      1. [Midpoint between two numbers](https://sciencing.com/calculate-midpoint-between-two-numbers-2807.html)
   1. Perform the following tasks:
      1. Add an additional method to the `BasicArithmetic` class
      1. Implement the functionality
      1. Output the results to the screen
      1. (*Optional - not graded*) Following the pattern for the others, implement a test for this operation *(for an additional challenge, practice [TDD](https://www.guru99.com/test-driven-development.html) and write the test before you implement the functionality)*
1. (2 pts) Add comments to the Program.cs and BasicArithmetic.cs classes, as well as each of the five (5) methods, and any logic that would not be obvious on first glance.

## Assignment Retrieval, Testing, and Submission
1. Pull down this repository from GitHub to your local machine and open the solution in Visual Studio.
1. There are unit tests provided in the solution to verify your logic is correct. These unit tests will be used for grading, and while they are not a substitute for manually testing your application, they can be useful in validating your arithmetic is correct. If you wish, you can add additional tests or test scenarios, but do not modify the existing tests. [How to run unit tests in Visual Studio](https://docs.microsoft.com/en-us/visualstudio/test/run-unit-tests-with-test-explorer?view=vs-2019)
1. You can check in your work, as well as push to GitHub, as infrequently or as often as you wish. However, you must ensure that your work is checked in and pushed, as that will be how your assignment is turned in. The code as of the due date and time will be the version that will be graded.
