﻿using System;

namespace CISS222_Homework3
{
    class Program
    {
        public static void Main(string[] args)
        {
            //Goal of the program is to take user input for two integer variables and run multiple mathemtical equations with 
            //the variable. Then, return the results to the user.

            int firstNumber = 0;
            int secondNumber = 0;


            /* I included a string variable to take the user's initial input for the first number and used that in the 
             * if statement below, otherwise using Console.ReadLine() in the TryParse causes user to have to use return twice
             * to continue in the program. I tried other methods, but those caused second input to malfunction entirely.
             */

            Console.WriteLine("Enter in the first number:");
            string initialInput = Console.ReadLine();

            //Will continue to loop until two valid numbers are given; Prevents program from crashing.
            for (int i = 1; i <= 2;)
            {
               if (int.TryParse(initialInput, out int userInputOne) && i == 1)
               {
                  firstNumber = userInputOne;
                  Console.WriteLine("Enter in the second number:");
                  i++;
               }
               else if (int.TryParse(Console.ReadLine(), out int userInputTwo) && i == 2)
               {
                  secondNumber = userInputTwo;
                  i++;
               }
               else
               {
                  Console.WriteLine("You entered an invalid number, please try again.\n" + 
                                    "Please only enter whole numbers.");
               }
            }


            //I use only three result variables here because 3 of the 5 methods used return int values.
            //The quotientWithRemainder method returns a string, so it can not use the same result variable.
            var result = BasicArithmetic.Sum(firstNumber, secondNumber);
            Console.WriteLine($"The sum of {firstNumber} and {secondNumber} is {result}.");

            result = BasicArithmetic.Difference(firstNumber, secondNumber);
            Console.WriteLine($"The difference of {firstNumber} and {secondNumber} is {result}.");

            result = BasicArithmetic.Product(firstNumber, secondNumber);
            Console.WriteLine($"The product of {firstNumber} and {secondNumber} is {result}.");

            var resultQuotient = BasicArithmetic.QuotientWithRemainder(firstNumber, secondNumber);
            Console.WriteLine($"The quotient of {firstNumber} and {secondNumber} is {resultQuotient}.");

            var resultExponent = BasicArithmetic.Exponent(firstNumber, secondNumber);
            Console.WriteLine($"The power of {firstNumber} and {secondNumber} is {resultExponent}.");
      }
    }
}