﻿using System;

namespace CISS222_Homework3
{
    public static class BasicArithmetic
    {
      //These methods are used to perform mathematical functions based on user input from the main method. 
      //User provides integer values for firstNumber and secondNumber variables.

        public static int Sum(int firstNumber, int secondNumber)
        {
            //Adds the numbers together and returns results.
            int result = firstNumber + secondNumber;
            return result;
        }

        public static int Difference(int firstNumber, int secondNumber)
        {
            //Subtracts the numbers and returns result.
            int result = firstNumber - secondNumber;
            return result;
        }

        public static int Product(int firstNumber, int secondNumber)
        {
            //Just multiples the two numbers together and returns result.
            int result = firstNumber * secondNumber;
            return result;
        }

        public static string QuotientWithRemainder(int firstNumber, int secondNumber)
        {
            //Ensures that any decimal values are not lost by calculating the remainder (if any) and adding it to the result.
            //Integer devision truncates any decimal values, so for accuracy you must calculate remainder.
            int division = firstNumber / secondNumber;
            double remainder = firstNumber % secondNumber;

            string result = division + "r" + remainder;
            return result;
        }

         public static double Exponent (int firstNumber, int secondNumber)
         {
            //Takes the first number and raises it to the power of the second number.
            //firstNumber * firstNumber (for however many times secondNumber is, i.e. secondNumber = 5 so 5 times).
            double result = Math.Pow(firstNumber, secondNumber);
            return result;
         }
    }
}
